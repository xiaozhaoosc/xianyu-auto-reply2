-- 数据库备份文件
-- 数据库: xianyu_data
-- 备份时间(北京时间): 2026-06-12 20:47:58
-- 说明: 本文件由定时任务自动生成。普通表备份结构与数据，日志表仅备份结构

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;


-- ----------------------------
-- 表结构: fy_accounts
-- ----------------------------
DROP TABLE IF EXISTS `fy_accounts`;
CREATE TABLE `fy_accounts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `owner_id` bigint NOT NULL COMMENT '所属用户ID',
  `account_id` varchar(80) NOT NULL COMMENT '账号标识',
  `account_type` enum('TAOBAO','JD','MEITUAN') NOT NULL DEFAULT 'TAOBAO' COMMENT '账号类型：TAOBAO/JD/MEITUAN',
  `display_name` varchar(120) DEFAULT NULL COMMENT '显示名称',
  `cookie` text NOT NULL COMMENT '账号Cookie',
  `app_key` varchar(80) DEFAULT NULL COMMENT '淘宝开放平台AppKey',
  `app_secret` varchar(200) DEFAULT NULL COMMENT '淘宝开放平台AppSecret',
  `adzone_id` varchar(80) DEFAULT NULL COMMENT '淘宝推广位ID',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `last_login_at` datetime DEFAULT NULL COMMENT '最后登录时间',
  `disable_reason` varchar(255) DEFAULT NULL COMMENT '禁用原因',
  `created_at` datetime NOT NULL DEFAULT (now()),
  `updated_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `ix_fy_accounts_account_id` (`account_id`),
  KEY `idx_fy_account_type` (`account_type`),
  KEY `idx_fy_account_created` (`created_at`),
  KEY `idx_fy_account_owner` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 表数据: fy_accounts


-- ----------------------------
-- 表结构: fy_delete_rules
-- ----------------------------
DROP TABLE IF EXISTS `fy_delete_rules`;
CREATE TABLE `fy_delete_rules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `owner_id` bigint NOT NULL COMMENT '所属用户ID',
  `rule_name` varchar(120) NOT NULL COMMENT '规则名称',
  `account_id` varchar(80) NOT NULL COMMENT '闲鱼账号ID（xy_accounts.account_id）',
  `daily_count` int NOT NULL DEFAULT '5' COMMENT '每天删除数量',
  `min_publish_days` int NOT NULL DEFAULT '7' COMMENT '发布满多少天才能删除',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `last_run_at` datetime DEFAULT NULL COMMENT '最后执行时间',
  `last_run_date` date DEFAULT NULL COMMENT '最后执行日期（用于判断今天是否已完成）',
  `today_count` int NOT NULL DEFAULT '0' COMMENT '今天已删除数量',
  `total_deleted_count` int NOT NULL DEFAULT '0' COMMENT '累计删除数量',
  `created_at` datetime NOT NULL DEFAULT (now()),
  `updated_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_fy_delete_rules_owner_account` (`owner_id`,`account_id`),
  KEY `ix_fy_delete_rules_owner_id` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 表数据: fy_delete_rules


-- ----------------------------
-- 表结构: fy_materials
-- ----------------------------
DROP TABLE IF EXISTS `fy_materials`;
CREATE TABLE `fy_materials` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `owner_id` bigint NOT NULL COMMENT '所属用户ID',
  `account_id` varchar(80) DEFAULT NULL COMMENT '闲鱼账号ID（xy_accounts.account_id）',
  `rule_id` bigint DEFAULT NULL COMMENT '来源选品规则ID',
  `item_id` varchar(50) NOT NULL COMMENT '淘宝商品ID',
  `title` varchar(500) NOT NULL COMMENT '商品标题',
  `price` decimal(10,2) NOT NULL DEFAULT '0.10' COMMENT '售价（默认0.1）',
  `stock` int NOT NULL DEFAULT '999' COMMENT '库存',
  `description` text COMMENT '商品描述',
  `images` text COMMENT '商品图片URL列表（JSON数组）',
  `click_url` varchar(1000) DEFAULT NULL COMMENT '推广链接',
  `coupon_url` varchar(1000) DEFAULT NULL COMMENT '券二合一推广链接',
  `tpwd` varchar(200) DEFAULT NULL COMMENT '淘口令',
  `short_url` varchar(1000) DEFAULT NULL COMMENT '短连接',
  `original_price` varchar(20) DEFAULT NULL COMMENT '商品原价',
  `commission_rate` varchar(20) DEFAULT NULL COMMENT '佣金率',
  `commission_amount` varchar(20) DEFAULT NULL COMMENT '佣金金额',
  `promotion_price` varchar(20) DEFAULT NULL COMMENT '到手价',
  `coupon_info` varchar(255) DEFAULT NULL COMMENT '优惠券信息',
  `shop_title` varchar(200) DEFAULT NULL COMMENT '店铺名称',
  `volume` varchar(50) DEFAULT NULL COMMENT '月销量',
  `publish_status` varchar(20) NOT NULL DEFAULT 'unpublished' COMMENT '发布状态',
  `published` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已发布到闲鱼',
  `published_at` datetime DEFAULT NULL COMMENT '发布时间',
  `published_item_id` varchar(64) DEFAULT NULL COMMENT '发布后闲鱼商品ID',
  `publish_random_str` varchar(32) DEFAULT NULL COMMENT '发布随机字符',
  `created_at` datetime NOT NULL DEFAULT (now()),
  `updated_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `idx_fy_material_account` (`account_id`),
  KEY `idx_fy_material_owner` (`owner_id`),
  KEY `idx_fy_material_owner_account_publish_status` (`owner_id`,`account_id`,`publish_status`),
  KEY `idx_fy_material_rule` (`rule_id`),
  KEY `idx_fy_material_item` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 表数据: fy_materials


-- ----------------------------
-- 表结构: fy_product_rules
-- ----------------------------
DROP TABLE IF EXISTS `fy_product_rules`;
CREATE TABLE `fy_product_rules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `owner_id` bigint NOT NULL COMMENT '所属用户ID',
  `account_id` varchar(80) DEFAULT NULL COMMENT '闲鱼账号ID（xy_accounts.account_id）',
  `rule_name` varchar(120) NOT NULL COMMENT '规则名称',
  `cat` varchar(50) DEFAULT NULL COMMENT '商品类目ID',
  `cat_name` varchar(100) DEFAULT NULL COMMENT '商品类目名称（冗余存储便于展示）',
  `keyword` varchar(200) DEFAULT NULL COMMENT '商品关键词',
  `sort` varchar(50) NOT NULL DEFAULT 'default' COMMENT '排序规则',
  `daily_count` int NOT NULL DEFAULT '10' COMMENT '每天选品条数',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `last_run_at` datetime DEFAULT NULL COMMENT '最后执行时间',
  `last_run_date` date DEFAULT NULL COMMENT '最后执行日期（用于判断今天是否已完成）',
  `today_count` int NOT NULL DEFAULT '0' COMMENT '今天已选品数量',
  `total_selected_count` int NOT NULL DEFAULT '0' COMMENT '累计选品数量',
  `created_at` datetime NOT NULL DEFAULT (now()),
  `updated_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `ix_fy_product_rules_owner_id` (`owner_id`),
  KEY `ix_fy_product_rules_account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 表数据: fy_product_rules


-- ----------------------------
-- 表结构: fy_publish_rules
-- ----------------------------
DROP TABLE IF EXISTS `fy_publish_rules`;
CREATE TABLE `fy_publish_rules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `owner_id` bigint NOT NULL COMMENT '所属用户ID',
  `rule_name` varchar(120) NOT NULL COMMENT '规则名称',
  `account_id` varchar(80) NOT NULL COMMENT '闲鱼账号ID（xy_accounts.account_id）',
  `daily_count` int NOT NULL DEFAULT '5' COMMENT '每天发布数量',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `last_run_at` datetime DEFAULT NULL COMMENT '最后执行时间',
  `last_run_date` date DEFAULT NULL COMMENT '最后执行日期（用于判断今天是否已完成）',
  `today_count` int NOT NULL DEFAULT '0' COMMENT '今天已发布数量',
  `created_at` datetime NOT NULL DEFAULT (now()),
  `updated_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_fy_publish_rules_owner_account` (`owner_id`,`account_id`),
  KEY `ix_fy_publish_rules_owner_id` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 表数据: fy_publish_rules


-- ----------------------------
-- 表结构: xy_account_login_logs
-- ----------------------------
DROP TABLE IF EXISTS `xy_account_login_logs`;
CREATE TABLE `xy_account_login_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'æ—¥å¿—ID',
  `owner_id` bigint DEFAULT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `account_id` bigint DEFAULT NULL COMMENT 'å…³è”è´¦å·ID(xy_accounts.id)',
  `account_identifier` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¸šåŠ¡è´¦å·ID',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ç™»å½•ç”¨æˆ·åå¿«ç…§',
  `trigger_reason` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è§¦å‘ç™»å½•åŽŸå› ',
  `login_status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'failed' COMMENT 'ç™»å½•çŠ¶æ€',
  `failure_reason` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¤±è´¥åŽŸå› ',
  `error_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'è¯¦ç»†é”™è¯¯æ¶ˆæ¯',
  `updated_cookie_names` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æŽ¥å£ç»­æœŸæ›´æ–°çš„Cookieå­—æ®µå',
  `duration_ms` int DEFAULT NULL COMMENT 'ç™»å½•æµç¨‹è€—æ—¶(æ¯«ç§’)',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_all_owner_id` (`owner_id`),
  KEY `idx_all_account_id` (`account_id`),
  KEY `idx_all_login_status` (`login_status`),
  KEY `idx_all_identifier_status_created` (`account_identifier`,`login_status`,`created_at`),
  KEY `idx_all_owner_created` (`owner_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è´¦å·ç™»å½•æ—¥å¿—è¡¨';

-- 表 xy_account_login_logs 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_accounts
-- ----------------------------
DROP TABLE IF EXISTS `xy_accounts`;
CREATE TABLE `xy_accounts` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'è´¦å·ID',
  `owner_id` bigint NOT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·æ ‡è¯†',
  `display_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ˜¾ç¤ºåç§°',
  `unb` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'UNBæ ‡è¯†',
  `cookie` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Cookieä¿¡æ¯',
  `login_method` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ç™»å½•æ–¹å¼',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active' COMMENT 'è´¦å·çŠ¶æ€',
  `username` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ç™»å½•ç”¨æˆ·å',
  `login_password` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'ç™»å½•å¯†ç ',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¤‡æ³¨',
  `pause_duration` int DEFAULT '10' COMMENT 'æš‚åœæ—¶é•¿(åˆ†é’Ÿ)',
  `auto_confirm` tinyint(1) DEFAULT '0' COMMENT 'è‡ªåŠ¨ç¡®è®¤å‘è´§',
  `show_browser` tinyint(1) DEFAULT '0' COMMENT 'æ˜¾ç¤ºæµè§ˆå™¨',
  `metadata` json DEFAULT NULL COMMENT 'å…ƒæ•°æ®',
  `last_login_at` datetime DEFAULT NULL COMMENT 'æœ€åŽç™»å½•æ—¶é—´',
  `last_refresh_at` datetime DEFAULT NULL COMMENT 'æœ€åŽåˆ·æ–°æ—¶é—´',
  `proxy_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'none' COMMENT 'ä»£ç†ç±»åž‹',
  `proxy_host` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä»£ç†ä¸»æœº',
  `proxy_port` int DEFAULT NULL COMMENT 'ä»£ç†ç«¯å£',
  `proxy_user` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä»£ç†ç”¨æˆ·å',
  `proxy_pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä»£ç†å¯†ç ',
  `message_expire_time` int DEFAULT '3600' COMMENT 'ç›¸åŒæ¶ˆæ¯ç­‰å¾…æ—¶é—´(ç§’)',
  `reply_delay_seconds` int DEFAULT '0' COMMENT 'è‡ªåŠ¨å›žå¤å»¶è¿Ÿæ—¶é—´(ç§’)',
  `disable_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ç¦ç”¨åŽŸå› ',
  `scheduled_redelivery` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'å®šæ—¶è¡¥å‘è´§å¼€å…³',
  `scheduled_rate` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'å®šæ—¶è¡¥è¯„ä»·å¼€å…³',
  `auto_polish` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'å•†å“è‡ªåŠ¨æ“¦äº®å¼€å…³',
  `confirm_before_send` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'å‘è´§æˆåŠŸå†å‘å¡åˆ¸å¼€å…³',
  `send_before_confirm` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'å¡åˆ¸å‘é€æˆåŠŸå†ç¡®è®¤å‘è´§å¼€å…³',
  `auto_red_flower` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'è‡ªåŠ¨æ±‚å°çº¢èŠ±å¼€å…³',
  `delivery_disabled` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'ç¦æ­¢å‘è´§å¼€å…³',
  `delivery_disabled_reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ç¦æ­¢å‘è´§åŽŸå› ',
  `auto_close_order` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'ä¸»åŠ¨å…³é—­è®¢å•å¼€å…³',
  `delivery_only_card_after_close` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'å…³é—­è®¢å•åŽç»§ç»­å‘è´§ï¼ˆåªå‘å¡åˆ¸ï¼‰',
  `delivery_disabled_excluded_items` json DEFAULT NULL COMMENT 'ç¦æ­¢å‘è´§æŽ’é™¤å•†å“åˆ—è¡¨',
  `ai_reply_block_ordered_users` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'å·²ä¸‹å•ç”¨æˆ·ç¦æ­¢AIå›žå¤',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_unb` (`unb`),
  KEY `idx_account_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='é—²é±¼è´¦å·è¡¨';

-- 表数据: xy_accounts


-- ----------------------------
-- 表结构: xy_activation_logs
-- ----------------------------
DROP TABLE IF EXISTS `xy_activation_logs`;
CREATE TABLE `xy_activation_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `machine_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æœºå™¨ç ',
  `code_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ç±»åž‹',
  `generated_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ç”Ÿæˆçš„æ¿€æ´»ç /ç»­æœŸç ',
  `days` int NOT NULL COMMENT 'æœ‰æ•ˆå¤©æ•°',
  `ip_address` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è¯·æ±‚IPåœ°å€',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_machine_id` (`machine_id`),
  KEY `idx_code_type` (`code_type`),
  KEY `idx_machine_type_time` (`machine_id`,`code_type`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æ¿€æ´»ç ç”Ÿæˆæ—¥å¿—è¡¨';

-- 表 xy_activation_logs 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_advertisements
-- ----------------------------
DROP TABLE IF EXISTS `xy_advertisements`;
CREATE TABLE `xy_advertisements` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'å¹¿å‘ŠID',
  `user_id` bigint NOT NULL COMMENT 'ç”³è¯·ç”¨æˆ·ID',
  `title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å¹¿å‘Šæ ‡é¢˜',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å¹¿å‘Šæ­£æ–‡',
  `link` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¹¿å‘Šé“¾æŽ¥',
  `expire_date` date DEFAULT NULL COMMENT 'åˆ°æœŸæ—¥æœŸ',
  `image_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å›¾ç‰‡URL',
  `ad_type` enum('carousel','text') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'text' COMMENT 'å¹¿å‘Šç±»åž‹',
  `months` int DEFAULT NULL COMMENT 'è´­ä¹°æœˆæ•°',
  `total_amount` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¹¿å‘Šæ€»é‡‘é¢',
  `status` enum('unpaid','pending','approved') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'unpaid' COMMENT 'å®¡æ ¸çŠ¶æ€',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_ad_type` (`ad_type`),
  KEY `idx_expire_date` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å¹¿å‘Šè¡¨';

-- 表数据: xy_advertisements


-- ----------------------------
-- 表结构: xy_agent_orders
-- ----------------------------
DROP TABLE IF EXISTS `xy_agent_orders`;
CREATE TABLE `xy_agent_orders` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` bigint NOT NULL COMMENT 'ä¸‹å•ç”¨æˆ·ID',
  `order_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'é—²é±¼è®¢å•å·',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å•†å“ID',
  `card_id` bigint NOT NULL COMMENT 'ä½¿ç”¨çš„å¡åˆ¸ID',
  `dock_record_id` bigint NOT NULL COMMENT 'å¯¹æŽ¥è®°å½•ID',
  `dock_level` int NOT NULL COMMENT 'å¯¹æŽ¥å±‚çº§ï¼š1=ä¸€çº§ï¼Œ2=äºŒçº§',
  `sale_price` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å”®ä»·',
  `dock_price` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å¯¹æŽ¥ä»·æ ¼(æ‹¿è´§ä»·)',
  `card_price` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¡åˆ¸æˆæœ¬(è´§ä¸»å¯¹æŽ¥ä»·)',
  `level2_cost` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'äºŒçº§æ‹¿è´§ä»·',
  `profit` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0.00' COMMENT 'åˆ©æ¶¦',
  `fee_amount` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‰‹ç»­è´¹é‡‘é¢',
  `fee_payer` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‰‹ç»­è´¹æ‰¿æ‹…æ–¹',
  `upstream_user_id` bigint DEFAULT NULL COMMENT 'ä¸Šçº§ç”¨æˆ·ID',
  `upstream_dock_record_id` bigint DEFAULT NULL COMMENT 'ä¸Šçº§å¯¹æŽ¥è®°å½•ID',
  `owner_user_id` bigint DEFAULT NULL COMMENT 'è´§ä¸»ç”¨æˆ·ID',
  `delivery_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å‘è´§å†…å®¹',
  `buyer_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¹°å®¶ID',
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'delivered' COMMENT 'çŠ¶æ€',
  `settle_remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ç»“ç®—å¤‡æ³¨',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_dock_record_id` (`dock_record_id`),
  KEY `idx_upstream_user_id` (`upstream_user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_agent_order_created` (`created_at`),
  KEY `idx_ao_upstream_status` (`upstream_user_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ä»£ç†è®¢å•è¡¨';

-- 表数据: xy_agent_orders


-- ----------------------------
-- 表结构: xy_ai_chat_messages
-- ----------------------------
DROP TABLE IF EXISTS `xy_ai_chat_messages`;
CREATE TABLE `xy_ai_chat_messages` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'æ¶ˆæ¯ID',
  `chat_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'èŠå¤©ID',
  `cookie_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·æ ‡è¯†',
  `user_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ç”¨æˆ·ID',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“ID',
  `role` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è§’è‰²(user/assistant)',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ¶ˆæ¯å†…å®¹',
  `intent` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ„å›¾(price/tech/default)',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_chat_id` (`chat_id`),
  KEY `idx_cookie_id` (`cookie_id`),
  KEY `ix_ai_chat_messages_chat_cookie` (`chat_id`,`cookie_id`),
  KEY `ix_ai_chat_messages_intent` (`cookie_id`,`intent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='AIèŠå¤©æ¶ˆæ¯è¡¨';

-- 表数据: xy_ai_chat_messages


-- ----------------------------
-- 表结构: xy_announcements
-- ----------------------------
DROP TABLE IF EXISTS `xy_announcements`;
CREATE TABLE `xy_announcements` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'å…¬å‘ŠID',
  `title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å…¬å‘Šæ ‡é¢˜',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å…¬å‘Šå†…å®¹',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'æ˜¯å¦å·²åˆ é™¤',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å…¬å‘Šä¿¡æ¯è¡¨';

-- 表数据: xy_announcements


-- ----------------------------
-- 表结构: xy_auto_rate_configs
-- ----------------------------
DROP TABLE IF EXISTS `xy_auto_rate_configs`;
CREATE TABLE `xy_auto_rate_configs` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `enabled` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦å¯ç”¨è‡ªåŠ¨è¯„ä»·',
  `rate_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'text' COMMENT 'è¯„ä»·ç±»åž‹',
  `text_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å›ºå®šè¯„ä»·æ–‡å­—å†…å®¹',
  `api_url` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'APIåœ°å€',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è‡ªåŠ¨è¯„ä»·é…ç½®è¡¨';

-- 表数据: xy_auto_rate_configs


-- ----------------------------
-- 表结构: xy_auto_reply_message_logs
-- ----------------------------
DROP TABLE IF EXISTS `xy_auto_reply_message_logs`;
CREATE TABLE `xy_auto_reply_message_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `owner_id` bigint DEFAULT NULL COMMENT 'æ‰€å±žç³»ç»Ÿç”¨æˆ·ID',
  `owner_username` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‰€å±žç³»ç»Ÿç”¨æˆ·å',
  `account_pk` bigint DEFAULT NULL COMMENT 'è´¦å·ä¸»é”®ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'é—²é±¼è´¦å·ID',
  `account_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é—²é±¼è´¦å·æ˜¾ç¤ºåç§°',
  `chat_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'èŠå¤©ä¼šè¯ID',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“ID',
  `item_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“æ ‡é¢˜',
  `source_message_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æºæ¶ˆæ¯ID',
  `sender_user_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å‘é€æ–¹é—²é±¼ç”¨æˆ·ID',
  `sender_user_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å‘é€æ–¹æ˜µç§°',
  `source_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'æ”¶åˆ°çš„æ¶ˆæ¯å†…å®¹',
  `source_message_time` datetime DEFAULT NULL COMMENT 'æ”¶åˆ°æ¶ˆæ¯æ—¶é—´',
  `process_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'processing' COMMENT 'å¤„ç†çŠ¶æ€',
  `decision_reason` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'processing' COMMENT 'å†³ç­–åŽŸå› ',
  `reply_strategy` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none' COMMENT 'å›žå¤ç­–ç•¥',
  `reply_mode` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none' COMMENT 'å›žå¤æ¨¡å¼',
  `matched_keyword` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å‘½ä¸­çš„å…³é”®è¯',
  `matched_rule_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å‘½ä¸­çš„è§„åˆ™ç±»åž‹',
  `default_reply_scope` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é»˜è®¤å›žå¤ä½œç”¨åŸŸ',
  `default_reply_once` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'é»˜è®¤å›žå¤æ˜¯å¦ä»…å›žå¤ä¸€æ¬¡',
  `ai_model_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'AIæ¨¡åž‹åç§°',
  `ai_provider_name` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'AIæœåŠ¡å•†åç§°',
  `reply_text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å›žå¤æ–‡æœ¬å†…å®¹',
  `reply_image_url` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å›žå¤å›¾ç‰‡URL',
  `reply_segments` json DEFAULT NULL COMMENT 'æ‹†åˆ†åŽçš„å›žå¤åˆ†æ®µ',
  `error_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'é”™è¯¯ä¿¡æ¯',
  `send_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unknown' COMMENT 'å‘é€çŠ¶æ€',
  `send_fail_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å‘é€å¤±è´¥åŽŸå› ',
  `raw_message_json` json DEFAULT NULL COMMENT 'åŽŸå§‹æ¶ˆæ¯JSON',
  `context_snapshot` json DEFAULT NULL COMMENT 'ä¸Šä¸‹æ–‡å¿«ç…§',
  `send_result_json` json DEFAULT NULL COMMENT 'å‘é€ç»“æžœå¿«ç…§',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_account_pk` (`account_pk`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_chat_id` (`chat_id`),
  KEY `idx_item_id` (`item_id`),
  KEY `idx_source_message_id` (`source_message_id`),
  KEY `idx_sender_user_id` (`sender_user_id`),
  KEY `idx_process_status` (`process_status`),
  KEY `idx_decision_reason` (`decision_reason`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_arml_account_created` (`account_id`,`created_at`),
  KEY `idx_arml_account_status_created` (`account_id`,`process_status`,`created_at`),
  KEY `idx_arml_owner_created` (`owner_id`,`created_at`),
  KEY `idx_arml_owner_status_created` (`owner_id`,`process_status`,`created_at`),
  KEY `idx_arml_status_created` (`process_status`,`created_at`),
  KEY `idx_arml_status_strategy_created` (`process_status`,`reply_strategy`,`created_at`),
  KEY `idx_arml_strategy_created` (`reply_strategy`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è‡ªåŠ¨å›žå¤æ¶ˆæ¯æ—¥å¿—è¡¨';

-- 表 xy_auto_reply_message_logs 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_card_item_relations
-- ----------------------------
DROP TABLE IF EXISTS `xy_card_item_relations`;
CREATE TABLE `xy_card_item_relations` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` bigint NOT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `card_id` bigint NOT NULL COMMENT 'å¡åˆ¸ID',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å•†å“ID',
  `source` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'own' COMMENT 'å¡åˆ¸æ¥æº',
  `dock_record_id` bigint NOT NULL DEFAULT '0' COMMENT 'å¯¹æŽ¥è®°å½•ID',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_card_item_dock` (`card_id`,`item_id`,`dock_record_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_card_id` (`card_id`),
  KEY `idx_item_id` (`item_id`),
  KEY `idx_cir_user_item` (`user_id`,`item_id`),
  KEY `idx_cir_item_card` (`item_id`,`card_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å¡åˆ¸å•†å“å…³è”è¡¨';

-- 表数据: xy_card_item_relations


-- ----------------------------
-- 表结构: xy_cards
-- ----------------------------
DROP TABLE IF EXISTS `xy_cards`;
CREATE TABLE `xy_cards` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'å¡åˆ¸ID',
  `user_id` bigint NOT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å…³è”å•†å“ID',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å¡åˆ¸åç§°',
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å¡åˆ¸ç±»åž‹(api/text/data/image)',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å¡åˆ¸æè¿°',
  `enabled` tinyint(1) DEFAULT '1' COMMENT 'æ˜¯å¦å¯ç”¨',
  `delay_seconds` int DEFAULT '0' COMMENT 'å»¶è¿Ÿç§’æ•°',
  `delivery_count` int DEFAULT '0' COMMENT 'å‘è´§æ¬¡æ•°',
  `price` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¯¹æŽ¥ä»·æ ¼',
  `is_dockable` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦å¯å¯¹æŽ¥',
  `fee_payer` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‰‹ç»­è´¹æ”¯ä»˜æ–¹å¼',
  `min_price` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æœ€ä½Žå”®ä»·',
  `dock_visibility` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¯¹æŽ¥å¯è§æ€§',
  `is_multi_spec` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦å¤šè§„æ ¼',
  `spec_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è§„æ ¼åç§°',
  `spec_value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è§„æ ¼å€¼',
  `api_config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'APIé…ç½®(JSON)',
  `text_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `data_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `image_url` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å›¾ç‰‡URL',
  `image_urls` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å¤šå›¾ç‰‡URLåˆ—è¡¨(JSON)',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_item_id` (`item_id`),
  KEY `idx_card_user_item` (`user_id`,`item_id`),
  KEY `idx_cards_dockable_enabled` (`is_dockable`,`enabled`),
  KEY `idx_cards_user_id_desc` (`user_id`,`id`),
  KEY `idx_cards_user_enabled` (`user_id`,`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å¡åˆ¸è¡¨';

-- 表数据: xy_cards


-- ----------------------------
-- 表结构: xy_catalog_items
-- ----------------------------
DROP TABLE IF EXISTS `xy_catalog_items`;
CREATE TABLE `xy_catalog_items` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'å•†å“ID',
  `owner_id` bigint NOT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `account_id` bigint NOT NULL COMMENT 'å…³è”è´¦å·ID',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å•†å“æ ‡è¯†',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“æ ‡é¢˜',
  `price` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“ä»·æ ¼',
  `ai_prompt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å•†å“AIæç¤ºè¯',
  `is_polished` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦æ“¦äº®',
  `metadata` json DEFAULT NULL COMMENT 'å•†å“å…ƒæ•°æ®',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cat_account_item` (`account_id`,`item_id`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_item_id` (`item_id`),
  KEY `idx_cat_account_item` (`account_id`,`item_id`),
  KEY `idx_cat_owner_created` (`owner_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å•†å“ç›®å½•è¡¨';

-- 表数据: xy_catalog_items


-- ----------------------------
-- 表结构: xy_chat_quick_phrases
-- ----------------------------
DROP TABLE IF EXISTS `xy_chat_quick_phrases`;
CREATE TABLE `xy_chat_quick_phrases` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `owner_id` bigint NOT NULL COMMENT 'å½’å±žç”¨æˆ·',
  `title` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŸ­è¯­æ ‡é¢˜',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŸ­è¯­å†…å®¹',
  `sort_order` int NOT NULL DEFAULT '0' COMMENT 'æŽ’åºå€¼',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `ix_xy_chat_quick_phrases_owner_id` (`owner_id`),
  KEY `idx_chat_quick_phrase_owner_sort` (`owner_id`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='åœ¨çº¿èŠå¤©å¿«æ·çŸ­è¯­';

-- 表数据: xy_chat_quick_phrases


-- ----------------------------
-- 表结构: xy_confirm_receipt_messages
-- ----------------------------
DROP TABLE IF EXISTS `xy_confirm_receipt_messages`;
CREATE TABLE `xy_confirm_receipt_messages` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `enabled` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦å¯ç”¨',
  `message_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'æ¶ˆæ¯æ–‡æœ¬å†…å®¹',
  `message_image` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ¶ˆæ¯å›¾ç‰‡URL',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç¡®è®¤æ”¶è´§æ¶ˆæ¯é…ç½®è¡¨';

-- 表数据: xy_confirm_receipt_messages


-- ----------------------------
-- 表结构: xy_cookie_refresh_schedules
-- ----------------------------
DROP TABLE IF EXISTS `xy_cookie_refresh_schedules`;
CREATE TABLE `xy_cookie_refresh_schedules` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `expire_at` datetime NOT NULL COMMENT 'å½“å‰Cookieç»­æœŸåˆ°æœŸæ—¶é—´',
  `last_refresh_at` datetime DEFAULT NULL COMMENT 'æœ€è¿‘ä¸€æ¬¡ç»­æœŸæˆåŠŸæ—¶é—´',
  `last_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æœ€è¿‘ä¸€æ¬¡çŠ¶æ€',
  `last_error_message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æœ€è¿‘ä¸€æ¬¡é”™è¯¯ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_account_id` (`account_id`),
  KEY `idx_expire_at` (`expire_at`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Cookieç»­æœŸè®¡åˆ’è¡¨';

-- 表数据: xy_cookie_refresh_schedules


-- ----------------------------
-- 表结构: xy_db_backup_log
-- ----------------------------
DROP TABLE IF EXISTS `xy_db_backup_log`;
CREATE TABLE `xy_db_backup_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŠ¶æ€',
  `file_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¤‡ä»½æ–‡ä»¶å',
  `file_path` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¤‡ä»½æ–‡ä»¶ç»å¯¹è·¯å¾„',
  `file_size` bigint DEFAULT NULL COMMENT 'å¤‡ä»½æ–‡ä»¶å¤§å°(å­—èŠ‚)',
  `table_count` int DEFAULT NULL COMMENT 'å¤‡ä»½çš„æ•°æ®è¡¨æ•°é‡',
  `total_rows` bigint DEFAULT NULL COMMENT 'å¤‡ä»½çš„æ•°æ®æ€»è¡Œæ•°',
  `duration_ms` int DEFAULT NULL COMMENT 'å¤‡ä»½è€—æ—¶(æ¯«ç§’)',
  `error_message` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æ•°æ®åº“å¤‡ä»½æ—¥å¿—è¡¨';

-- 表 xy_db_backup_log 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_default_replies
-- ----------------------------
DROP TABLE IF EXISTS `xy_default_replies`;
CREATE TABLE `xy_default_replies` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'å›žå¤ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·æ ‡è¯†',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“ID',
  `enabled` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦å¯ç”¨',
  `reply_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'text' COMMENT 'å›žå¤ç±»åž‹',
  `reply_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å›žå¤å†…å®¹',
  `reply_image` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å›žå¤å›¾ç‰‡URL',
  `api_url` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'APIåœ°å€',
  `api_timeout` int DEFAULT '80' COMMENT 'APIè¯·æ±‚è¶…æ—¶æ—¶é—´(ç§’)',
  `reply_once` tinyint(1) DEFAULT '0' COMMENT 'åªå›žå¤ä¸€æ¬¡',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_account_item` (`account_id`,`item_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_item_id` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='é»˜è®¤å›žå¤è¡¨';

-- 表数据: xy_default_replies


-- ----------------------------
-- 表结构: xy_default_reply_records
-- ----------------------------
DROP TABLE IF EXISTS `xy_default_reply_records`;
CREATE TABLE `xy_default_reply_records` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'è®°å½•ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·æ ‡è¯†',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“ID',
  `user_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è¢«å›žå¤ç”¨æˆ·ID',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_account_item_user` (`account_id`,`item_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='é»˜è®¤å›žå¤è®°å½•è¡¨';

-- 表数据: xy_default_reply_records


-- ----------------------------
-- 表结构: xy_delivery_block_rules
-- ----------------------------
DROP TABLE IF EXISTS `xy_delivery_block_rules`;
CREATE TABLE `xy_delivery_block_rules` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `account_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `rule_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è§„åˆ™ç¼–ç ',
  `enabled` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'è§„åˆ™å¼€å…³',
  `priority` int NOT NULL DEFAULT '0' COMMENT 'æ‰§è¡Œä¼˜å…ˆçº§',
  `block_reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ç¦æ­¢å‘è´§åŽŸå› ',
  `auto_close_order` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'å‘½ä¸­åŽä¸»åŠ¨å…³é—­è®¢å•',
  `only_card_after_close` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'å…³é—­è®¢å•åŽç»§ç»­å‘è´§(åªå‘å¡åˆ¸)',
  `excluded_item_ids` json DEFAULT NULL COMMENT 'æŽ’é™¤å•†å“åˆ—è¡¨',
  `config` json DEFAULT NULL COMMENT 'è§„åˆ™ä¸“å±žå‚æ•°',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_account_rule` (`account_id`,`rule_code`),
  KEY `idx_account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç¦æ­¢å‘è´§è§„åˆ™é…ç½®è¡¨';

-- 表数据: xy_delivery_block_rules


-- ----------------------------
-- 表结构: xy_dock_code_bindings
-- ----------------------------
DROP TABLE IF EXISTS `xy_dock_code_bindings`;
CREATE TABLE `xy_dock_code_bindings` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` bigint NOT NULL COMMENT 'ç»‘å®šç”¨æˆ·ID(åˆ†é”€å•†)',
  `dock_code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å¯¹æŽ¥ç ',
  `target_user_id` bigint NOT NULL COMMENT 'å¯¹æŽ¥ç æ‹¥æœ‰è€…ç”¨æˆ·ID(ä¾›åº”å•†)',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'ç»‘å®šæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_target` (`user_id`,`target_user_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_target_user_id` (`target_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å¯¹æŽ¥ç ç»‘å®šè¡¨';

-- 表数据: xy_dock_code_bindings


-- ----------------------------
-- 表结构: xy_dock_records
-- ----------------------------
DROP TABLE IF EXISTS `xy_dock_records`;
CREATE TABLE `xy_dock_records` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·ID',
  `card_id` bigint NOT NULL COMMENT 'æ¥æºå¡åˆ¸ID',
  `dock_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å¯¹æŽ¥åç§°',
  `markup_amount` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0.00' COMMENT 'åŠ ä»·é‡‘é¢',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å¤‡æ³¨',
  `delivery_count` int NOT NULL DEFAULT '0' COMMENT 'å‘è´§æ¬¡æ•°',
  `status` tinyint(1) DEFAULT '1' COMMENT 'å¯¹æŽ¥çŠ¶æ€ï¼š1å¯ç”¨ 0åœç”¨',
  `disable_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ç¦ç”¨åŽŸå› ',
  `level` int NOT NULL DEFAULT '1' COMMENT 'åˆ†é”€å±‚çº§ï¼š1=ä¸€çº§ï¼Œ2=äºŒçº§',
  `parent_dock_id` bigint DEFAULT NULL COMMENT 'ä¸Šçº§å¯¹æŽ¥è®°å½•ID',
  `source_user_id` bigint DEFAULT NULL COMMENT 'ä¸Šçº§åˆ†é”€å•†ç”¨æˆ·ID',
  `allow_sub_dock` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦å…è®¸ä¸‹çº§å¯¹æŽ¥',
  `sub_dock_price` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ç»™ä¸‹çº§çš„å¯¹æŽ¥ä»·æ ¼',
  `sub_dock_visibility` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¸‹çº§å¯¹æŽ¥å¯è§æ€§',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_card_id` (`card_id`),
  KEY `idx_parent_dock_id` (`parent_dock_id`),
  KEY `idx_dock_user_level` (`user_id`,`level`),
  KEY `idx_dock_source_level` (`source_user_id`,`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å¯¹æŽ¥è®°å½•è¡¨';

-- 表数据: xy_dock_records


-- ----------------------------
-- 表结构: xy_feedback_messages
-- ----------------------------
DROP TABLE IF EXISTS `xy_feedback_messages`;
CREATE TABLE `xy_feedback_messages` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'æ¶ˆæ¯ID',
  `feedback_id` bigint NOT NULL COMMENT 'å…³è”åé¦ˆID',
  `user_id` bigint NOT NULL COMMENT 'å‘é€è€…ç”¨æˆ·ID',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ¶ˆæ¯å†…å®¹',
  `is_admin` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦ä¸ºç®¡ç†å‘˜æ¶ˆæ¯',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_feedback_id` (`feedback_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æ„è§åé¦ˆæ¶ˆæ¯è¡¨';

-- 表数据: xy_feedback_messages


-- ----------------------------
-- 表结构: xy_feedbacks
-- ----------------------------
DROP TABLE IF EXISTS `xy_feedbacks`;
CREATE TABLE `xy_feedbacks` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'åé¦ˆID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·ID',
  `cookie_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å…³è”è´¦å·ID',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ ‡é¢˜',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å†…å®¹',
  `feedback_type` enum('FEATURE','BUG','OTHER') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'OTHER' COMMENT 'åé¦ˆç±»åž‹',
  `images` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å›¾ç‰‡URL(JSONæ•°ç»„)',
  `is_resolved` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦å·²è§£å†³',
  `resolved_at` datetime DEFAULT NULL COMMENT 'è§£å†³æ—¶é—´',
  `admin_reply` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'ç®¡ç†å‘˜å›žå¤',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_is_resolved` (`is_resolved`),
  KEY `idx_feedback_type` (`feedback_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æ„è§åé¦ˆè¡¨';

-- 表数据: xy_feedbacks


-- ----------------------------
-- 表结构: xy_fund_flows
-- ----------------------------
DROP TABLE IF EXISTS `xy_fund_flows`;
CREATE TABLE `xy_fund_flows` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·ID',
  `type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æµæ°´ç±»åž‹ï¼šincome/expense',
  `amount` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å‘ç”Ÿé¢',
  `balance_before` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å‘ç”Ÿå‰ä½™é¢',
  `balance_after` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å‘ç”ŸåŽä½™é¢',
  `order_id` bigint DEFAULT NULL COMMENT 'å…³è”è®¢å•ID',
  `dock_record_id` bigint DEFAULT NULL COMMENT 'å…³è”å¯¹æŽ¥è®°å½•ID',
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æµæ°´æè¿°',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'å‘ç”Ÿæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_dock_record_id` (`dock_record_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_ff_user_id_desc` (`user_id`,`id`),
  KEY `idx_ff_user_type_id_desc` (`user_id`,`type`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='èµ„é‡‘æµæ°´è¡¨';

-- 表数据: xy_fund_flows


-- ----------------------------
-- 表结构: xy_goofish_crawl_items
-- ----------------------------
DROP TABLE IF EXISTS `xy_goofish_crawl_items`;
CREATE TABLE `xy_goofish_crawl_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` bigint NOT NULL,
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `price` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seller_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `main_image` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `publish_time` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `want_count` int DEFAULT NULL,
  `view_count` int DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `detail_error` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `raw_json` json DEFAULT NULL,
  `fetched_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_job_item` (`job_id`,`item_id`),
  KEY `idx_job_id` (`job_id`),
  KEY `idx_fetched_at` (`fetched_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 表数据: xy_goofish_crawl_items


-- ----------------------------
-- 表结构: xy_goofish_crawl_jobs
-- ----------------------------
DROP TABLE IF EXISTS `xy_goofish_crawl_jobs`;
CREATE TABLE `xy_goofish_crawl_jobs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `owner_id` bigint NOT NULL,
  `cookie_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keyword` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `interval_seconds` int NOT NULL DEFAULT '900',
  `start_page` int NOT NULL DEFAULT '1',
  `pages` int NOT NULL DEFAULT '1',
  `page_size` int NOT NULL DEFAULT '20',
  `fetch_detail` tinyint(1) DEFAULT '1',
  `detail_limit` int NOT NULL DEFAULT '20',
  `enabled` tinyint(1) DEFAULT '1',
  `last_run_at` datetime DEFAULT NULL,
  `last_error` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_cookie_id` (`cookie_id`),
  KEY `idx_enabled` (`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 表数据: xy_goofish_crawl_jobs


-- ----------------------------
-- 表结构: xy_keyword_rules
-- ----------------------------
DROP TABLE IF EXISTS `xy_keyword_rules`;
CREATE TABLE `xy_keyword_rules` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'è§„åˆ™ID',
  `owner_id` bigint NOT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `account_id` bigint DEFAULT NULL COMMENT 'å…³è”è´¦å·ID',
  `keyword` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å…³é”®è¯',
  `reply_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å›žå¤å†…å®¹',
  `reply_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å›žå¤ç±»åž‹(text/image)',
  `image_url` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å›¾ç‰‡URL',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“ID',
  `priority` int DEFAULT '100' COMMENT 'ä¼˜å…ˆçº§',
  `is_active` tinyint(1) DEFAULT '1' COMMENT 'æ˜¯å¦å¯ç”¨',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_keyword` (`keyword`),
  KEY `idx_kw_account_item` (`account_id`,`item_id`),
  KEY `idx_kw_account_active` (`account_id`,`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å…³é”®è¯è§„åˆ™è¡¨';

-- 表数据: xy_keyword_rules


-- ----------------------------
-- 表结构: xy_message_filters
-- ----------------------------
DROP TABLE IF EXISTS `xy_message_filters`;
CREATE TABLE `xy_message_filters` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'è§„åˆ™ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·æ ‡è¯†',
  `keyword` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è¿‡æ»¤å…³é”®è¯',
  `filter_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è¿‡æ»¤ç±»åž‹',
  `enabled` tinyint(1) DEFAULT '1' COMMENT 'æ˜¯å¦å¯ç”¨',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_account_keyword_type` (`account_id`,`keyword`,`filter_type`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_keyword` (`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æ¶ˆæ¯è¿‡æ»¤è§„åˆ™è¡¨';

-- 表数据: xy_message_filters


-- ----------------------------
-- 表结构: xy_message_notifications
-- ----------------------------
DROP TABLE IF EXISTS `xy_message_notifications`;
CREATE TABLE `xy_message_notifications` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'é€šçŸ¥ID',
  `owner_id` bigint NOT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `account_pk` bigint NOT NULL COMMENT 'å…³è”è´¦å·ID',
  `account_identifier` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·æ ‡è¯†',
  `channel_id` bigint NOT NULL COMMENT 'æ¸ é“ID',
  `enabled` tinyint(1) DEFAULT '1' COMMENT 'æ˜¯å¦å¯ç”¨',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_account_pk` (`account_pk`),
  KEY `idx_channel_id` (`channel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æ¶ˆæ¯é€šçŸ¥è¡¨';

-- 表数据: xy_message_notifications


-- ----------------------------
-- 表结构: xy_notification_channels
-- ----------------------------
DROP TABLE IF EXISTS `xy_notification_channels`;
CREATE TABLE `xy_notification_channels` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'æ¸ é“ID',
  `owner_id` bigint NOT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ¸ é“åç§°',
  `channel_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ¸ é“ç±»åž‹',
  `config` json DEFAULT NULL COMMENT 'æ¸ é“é…ç½®',
  `enabled` tinyint(1) DEFAULT '1' COMMENT 'æ˜¯å¦å¯ç”¨',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_channel_type` (`channel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='é€šçŸ¥æ¸ é“è¡¨';

-- 表数据: xy_notification_channels


-- ----------------------------
-- 表结构: xy_orders
-- ----------------------------
DROP TABLE IF EXISTS `xy_orders`;
CREATE TABLE `xy_orders` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'è®¢å•ID',
  `owner_id` bigint NOT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `order_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•çŠ¶æ€',
  `buyer_nick` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¹°å®¶æ˜µç§°',
  `buyer_fish_nick` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¹°å®¶é—²é±¼æ˜µç§°',
  `buyer_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¹°å®¶ID',
  `chat_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'èŠå¤©ä¼šè¯ID',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“ID',
  `spec_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è§„æ ¼åç§°',
  `spec_value` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è§„æ ¼å€¼',
  `quantity` int DEFAULT '1' COMMENT 'æ•°é‡',
  `amount` decimal(12,2) DEFAULT NULL COMMENT 'é‡‘é¢',
  `currency` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'CNY' COMMENT 'è´§å¸',
  `account_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è´¦å·æ ‡è¯†',
  `account_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è´¦å·åç§°',
  `is_bargain` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦å°åˆ€',
  `receiver_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§äººå§“å',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§äººæ‰‹æœºå·',
  `receiver_address` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§åœ°å€',
  `is_rated` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦å·²è¯„ä»·',
  `is_red_flower` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦å·²æ±‚å°çº¢èŠ±',
  `delivery_method` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å‘è´§æ–¹å¼',
  `delivery_content` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å‘è´§å†…å®¹',
  `delivery_fail_reason` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å‘è´§å¤±è´¥åŽŸå› ',
  `item_snapshot` json DEFAULT NULL COMMENT 'å•†å“å¿«ç…§',
  `metadata` json DEFAULT NULL COMMENT 'å…ƒæ•°æ®',
  `source` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ•°æ®æ¥æº',
  `placed_at` datetime DEFAULT NULL COMMENT 'ä¸‹å•æ—¶é—´',
  `synced_at` datetime DEFAULT NULL COMMENT 'åŒæ­¥æ—¶é—´',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_account_no` (`account_id`,`order_no`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_order_created_at` (`created_at`),
  KEY `idx_order_placed_status` (`placed_at`,`status`),
  KEY `idx_order_created_status` (`created_at`,`status`),
  KEY `idx_order_owner_placed` (`owner_id`,`placed_at`),
  KEY `idx_order_owner_created` (`owner_id`,`created_at`),
  KEY `idx_order_owner_account_placed` (`owner_id`,`account_id`,`placed_at`),
  KEY `idx_order_owner_account_buyer_created` (`owner_id`,`account_id`,`buyer_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•è¡¨';

-- 表数据: xy_orders


-- ----------------------------
-- 表结构: xy_personal_blacklist
-- ----------------------------
DROP TABLE IF EXISTS `xy_personal_blacklist`;
CREATE TABLE `xy_personal_blacklist` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `owner_id` bigint NOT NULL COMMENT 'ç”¨æˆ·ID',
  `account_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è´¦å·ID',
  `buyer_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ä¹°å®¶ID',
  `buyer_nick` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¹°å®¶æ˜µç§°',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“ID',
  `reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‹‰é»‘åŽŸå› ',
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'æ˜¯å¦å¯ç”¨',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_pb_owner_id` (`owner_id`),
  KEY `idx_pb_owner_buyer` (`owner_id`,`buyer_id`),
  KEY `idx_pb_owner_account` (`owner_id`,`account_id`),
  KEY `idx_pb_owner_created` (`owner_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ä¸ªäººé»‘åå•è¡¨';

-- 表数据: xy_personal_blacklist


-- ----------------------------
-- 表结构: xy_platform_blacklist
-- ----------------------------
DROP TABLE IF EXISTS `xy_platform_blacklist`;
CREATE TABLE `xy_platform_blacklist` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `owner_id` bigint NOT NULL COMMENT 'æ‹‰é»‘ç”¨æˆ·(æœ¬ç³»ç»Ÿç”¨æˆ·ID)',
  `buyer_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ä¹°å®¶ID',
  `buyer_nick` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¹°å®¶æ˜µç§°',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_plb_owner_id` (`owner_id`),
  KEY `idx_plb_owner_buyer` (`owner_id`,`buyer_id`),
  KEY `idx_plb_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='é—²é±¼é»‘åå•è¡¨';

-- 表数据: xy_platform_blacklist


-- ----------------------------
-- 表结构: xy_product_materials
-- ----------------------------
DROP TABLE IF EXISTS `xy_product_materials`;
CREATE TABLE `xy_product_materials` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` bigint NOT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å•†å“æ ‡é¢˜',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å•†å“æè¿°',
  `price` decimal(12,2) NOT NULL COMMENT 'ä»·æ ¼',
  `original_price` decimal(12,2) DEFAULT NULL COMMENT 'åŽŸä»·(åˆ’çº¿ä»·)',
  `category` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“åˆ†ç±»',
  `images` json DEFAULT NULL COMMENT 'å›¾ç‰‡URLåˆ—è¡¨(æœ€å¤š9å¼ )',
  `delivery_method` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'express' COMMENT 'å‘è´§æ–¹å¼',
  `postage` decimal(8,2) DEFAULT '0.00' COMMENT 'é‚®è´¹',
  `address` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å®è´æ‰€åœ¨åœ°',
  `brand` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å“ç‰Œ',
  `condition` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'å…¨æ–°' COMMENT 'æˆè‰²',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¤‡æ³¨',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_pm_user_created` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å•†å“ç´ æåº“è¡¨';

-- 表数据: xy_product_materials


-- ----------------------------
-- 表结构: xy_publish_addresses
-- ----------------------------
DROP TABLE IF EXISTS `xy_publish_addresses`;
CREATE TABLE `xy_publish_addresses` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'åœ°å€åç§°',
  `search_keyword` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'åœ°å€æœç´¢å…³é”®è¯',
  `expected_text` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æœŸæœ›å‘½ä¸­çš„å€™é€‰æ–‡æœ¬',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é™å®šä½¿ç”¨çš„é—²é±¼è´¦å·ID',
  `weight` int NOT NULL DEFAULT '1' COMMENT 'éšæœºæƒé‡',
  `sort_order` int NOT NULL DEFAULT '100' COMMENT 'æŽ’åºå€¼',
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'æ˜¯å¦å¯ç”¨',
  `use_count` int NOT NULL DEFAULT '0' COMMENT 'ä½¿ç”¨æ¬¡æ•°',
  `last_used_at` datetime DEFAULT NULL COMMENT 'æœ€åŽä½¿ç”¨æ—¶é—´',
  `created_by` bigint DEFAULT NULL COMMENT 'åˆ›å»ºäººç”¨æˆ·ID',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¤‡æ³¨',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_pa_enabled_account` (`is_enabled`,`account_id`),
  KEY `idx_pa_sort_created` (`sort_order`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=311 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å•†å“å‘å¸ƒéšæœºåœ°å€æ± è¡¨';

-- 表数据: xy_publish_addresses
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (156, '北京市朝阳区', '北京市朝阳区', NULL, NULL, 1, 1, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (157, '北京市海淀区', '北京市海淀区', NULL, NULL, 1, 2, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (158, '北京市丰台区', '北京市丰台区', NULL, NULL, 1, 3, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (159, '北京市通州区', '北京市通州区', NULL, NULL, 1, 4, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (160, '北京市大兴区', '北京市大兴区', NULL, NULL, 1, 5, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (161, '天津市和平区', '天津市和平区', NULL, NULL, 1, 6, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (162, '天津市河西区', '天津市河西区', NULL, NULL, 1, 7, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (163, '天津市南开区', '天津市南开区', NULL, NULL, 1, 8, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (164, '天津市西青区', '天津市西青区', NULL, NULL, 1, 9, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (165, '天津市滨海新区', '天津市滨海新区', NULL, NULL, 1, 10, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (166, '河北省石家庄市长安区', '河北省石家庄市长安区', NULL, NULL, 1, 11, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (167, '河北省唐山市路北区', '河北省唐山市路北区', NULL, NULL, 1, 12, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (168, '河北省保定市莲池区', '河北省保定市莲池区', NULL, NULL, 1, 13, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (169, '河北省廊坊市广阳区', '河北省廊坊市广阳区', NULL, NULL, 1, 14, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (170, '河北省沧州市运河区', '河北省沧州市运河区', NULL, NULL, 1, 15, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (171, '山西省太原市小店区', '山西省太原市小店区', NULL, NULL, 1, 16, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (172, '山西省大同市平城区', '山西省大同市平城区', NULL, NULL, 1, 17, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (173, '山西省晋中市榆次区', '山西省晋中市榆次区', NULL, NULL, 1, 18, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (174, '山西省运城市盐湖区', '山西省运城市盐湖区', NULL, NULL, 1, 19, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (175, '山西省临汾市尧都区', '山西省临汾市尧都区', NULL, NULL, 1, 20, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (176, '内蒙古自治区呼和浩特市赛罕区', '内蒙古自治区呼和浩特市赛罕区', NULL, NULL, 1, 21, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (177, '内蒙古自治区包头市昆都仑区', '内蒙古自治区包头市昆都仑区', NULL, NULL, 1, 22, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (178, '内蒙古自治区鄂尔多斯市东胜区', '内蒙古自治区鄂尔多斯市东胜区', NULL, NULL, 1, 23, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (179, '内蒙古自治区赤峰市红山区', '内蒙古自治区赤峰市红山区', NULL, NULL, 1, 24, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (180, '内蒙古自治区呼伦贝尔市海拉尔区', '内蒙古自治区呼伦贝尔市海拉尔区', NULL, NULL, 1, 25, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (181, '辽宁省沈阳市和平区', '辽宁省沈阳市和平区', NULL, NULL, 1, 26, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (182, '辽宁省大连市中山区', '辽宁省大连市中山区', NULL, NULL, 1, 27, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (183, '辽宁省鞍山市铁东区', '辽宁省鞍山市铁东区', NULL, NULL, 1, 28, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (184, '辽宁省锦州市太和区', '辽宁省锦州市太和区', NULL, NULL, 1, 29, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (185, '辽宁省营口市站前区', '辽宁省营口市站前区', NULL, NULL, 1, 30, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (186, '吉林省长春市南关区', '吉林省长春市南关区', NULL, NULL, 1, 31, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (187, '吉林省吉林市船营区', '吉林省吉林市船营区', NULL, NULL, 1, 32, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (188, '吉林省四平市铁西区', '吉林省四平市铁西区', NULL, NULL, 1, 33, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (189, '吉林省延边州延吉市', '吉林省延边州延吉市', NULL, NULL, 1, 34, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (190, '吉林省通化市东昌区', '吉林省通化市东昌区', NULL, NULL, 1, 35, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (191, '黑龙江省哈尔滨市南岗区', '黑龙江省哈尔滨市南岗区', NULL, NULL, 1, 36, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (192, '黑龙江省齐齐哈尔市龙沙区', '黑龙江省齐齐哈尔市龙沙区', NULL, NULL, 1, 37, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (193, '黑龙江省牡丹江市东安区', '黑龙江省牡丹江市东安区', NULL, NULL, 1, 38, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (194, '黑龙江省大庆市萨尔图区', '黑龙江省大庆市萨尔图区', NULL, NULL, 1, 39, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (195, '黑龙江省佳木斯市向阳区', '黑龙江省佳木斯市向阳区', NULL, NULL, 1, 40, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (196, '上海市浦东新区', '上海市浦东新区', NULL, NULL, 1, 41, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (197, '上海市闵行区', '上海市闵行区', NULL, NULL, 1, 42, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (198, '上海市徐汇区', '上海市徐汇区', NULL, NULL, 1, 43, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (199, '上海市宝山区', '上海市宝山区', NULL, NULL, 1, 44, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (200, '上海市松江区', '上海市松江区', NULL, NULL, 1, 45, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (201, '江苏省南京市建邺区', '江苏省南京市建邺区', NULL, NULL, 1, 46, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (202, '江苏省苏州市工业园区', '江苏省苏州市工业园区', NULL, NULL, 1, 47, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (203, '江苏省无锡市滨湖区', '江苏省无锡市滨湖区', NULL, NULL, 1, 48, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (204, '江苏省徐州市云龙区', '江苏省徐州市云龙区', NULL, NULL, 1, 49, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (205, '江苏省南通市崇川区', '江苏省南通市崇川区', NULL, NULL, 1, 50, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (206, '浙江省杭州市西湖区', '浙江省杭州市西湖区', NULL, NULL, 1, 51, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (207, '浙江省宁波市鄞州区', '浙江省宁波市鄞州区', NULL, NULL, 1, 52, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (208, '浙江省温州市鹿城区', '浙江省温州市鹿城区', NULL, NULL, 1, 53, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (209, '浙江省嘉兴市南湖区', '浙江省嘉兴市南湖区', NULL, NULL, 1, 54, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (210, '浙江省金华市义乌市', '浙江省金华市义乌市', NULL, NULL, 1, 55, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (211, '安徽省合肥市蜀山区', '安徽省合肥市蜀山区', NULL, NULL, 1, 56, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (212, '安徽省芜湖市镜湖区', '安徽省芜湖市镜湖区', NULL, NULL, 1, 57, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (213, '安徽省蚌埠市蚌山区', '安徽省蚌埠市蚌山区', NULL, NULL, 1, 58, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (214, '安徽省阜阳市颍州区', '安徽省阜阳市颍州区', NULL, NULL, 1, 59, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (215, '安徽省安庆市迎江区', '安徽省安庆市迎江区', NULL, NULL, 1, 60, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (216, '福建省福州市鼓楼区', '福建省福州市鼓楼区', NULL, NULL, 1, 61, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (217, '福建省厦门市思明区', '福建省厦门市思明区', NULL, NULL, 1, 62, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (218, '福建省泉州市丰泽区', '福建省泉州市丰泽区', NULL, NULL, 1, 63, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (219, '福建省漳州市芗城区', '福建省漳州市芗城区', NULL, NULL, 1, 64, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (220, '福建省莆田市城厢区', '福建省莆田市城厢区', NULL, NULL, 1, 65, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (221, '江西省南昌市红谷滩区', '江西省南昌市红谷滩区', NULL, NULL, 1, 66, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (222, '江西省赣州市章贡区', '江西省赣州市章贡区', NULL, NULL, 1, 67, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (223, '江西省九江市濂溪区', '江西省九江市濂溪区', NULL, NULL, 1, 68, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (224, '江西省上饶市信州区', '江西省上饶市信州区', NULL, NULL, 1, 69, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (225, '江西省宜春市袁州区', '江西省宜春市袁州区', NULL, NULL, 1, 70, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (226, '山东省济南市历下区', '山东省济南市历下区', NULL, NULL, 1, 71, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (227, '山东省青岛市市南区', '山东省青岛市市南区', NULL, NULL, 1, 72, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (228, '山东省烟台市芝罘区', '山东省烟台市芝罘区', NULL, NULL, 1, 73, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (229, '山东省潍坊市奎文区', '山东省潍坊市奎文区', NULL, NULL, 1, 74, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (230, '山东省临沂市兰山区', '山东省临沂市兰山区', NULL, NULL, 1, 75, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (231, '河南省郑州市金水区', '河南省郑州市金水区', NULL, NULL, 1, 76, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (232, '河南省洛阳市洛龙区', '河南省洛阳市洛龙区', NULL, NULL, 1, 77, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (233, '河南省南阳市宛城区', '河南省南阳市宛城区', NULL, NULL, 1, 78, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (234, '河南省新乡市红旗区', '河南省新乡市红旗区', NULL, NULL, 1, 79, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (235, '河南省商丘市睢阳区', '河南省商丘市睢阳区', NULL, NULL, 1, 80, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (236, '湖北省武汉市武昌区', '湖北省武汉市武昌区', NULL, NULL, 1, 81, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (237, '湖北省宜昌市西陵区', '湖北省宜昌市西陵区', NULL, NULL, 1, 82, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (238, '湖北省襄阳市樊城区', '湖北省襄阳市樊城区', NULL, NULL, 1, 83, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (239, '湖北省荆州市沙市区', '湖北省荆州市沙市区', NULL, NULL, 1, 84, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (240, '湖北省黄石市黄石港区', '湖北省黄石市黄石港区', NULL, NULL, 1, 85, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (241, '湖南省长沙市岳麓区', '湖南省长沙市岳麓区', NULL, NULL, 1, 86, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (242, '湖南省株洲市天元区', '湖南省株洲市天元区', NULL, NULL, 1, 87, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (243, '湖南省湘潭市岳塘区', '湖南省湘潭市岳塘区', NULL, NULL, 1, 88, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (244, '湖南省岳阳市岳阳楼区', '湖南省岳阳市岳阳楼区', NULL, NULL, 1, 89, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (245, '湖南省常德市武陵区', '湖南省常德市武陵区', NULL, NULL, 1, 90, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (246, '广东省广州市天河区', '广东省广州市天河区', NULL, NULL, 1, 91, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (247, '广东省深圳市南山区', '广东省深圳市南山区', NULL, NULL, 1, 92, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (248, '广东省佛山市南海区', '广东省佛山市南海区', NULL, NULL, 1, 93, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (249, '广东省东莞市南城街道', '广东省东莞市南城街道', NULL, NULL, 1, 94, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (250, '广东省珠海市香洲区', '广东省珠海市香洲区', NULL, NULL, 1, 95, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (251, '广西壮族自治区南宁市青秀区', '广西壮族自治区南宁市青秀区', NULL, NULL, 1, 96, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (252, '广西壮族自治区柳州市城中区', '广西壮族自治区柳州市城中区', NULL, NULL, 1, 97, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (253, '广西壮族自治区桂林市秀峰区', '广西壮族自治区桂林市秀峰区', NULL, NULL, 1, 98, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (254, '广西壮族自治区北海市海城区', '广西壮族自治区北海市海城区', NULL, NULL, 1, 99, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (255, '广西壮族自治区玉林市玉州区', '广西壮族自治区玉林市玉州区', NULL, NULL, 1, 100, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (256, '海南省海口市龙华区', '海南省海口市龙华区', NULL, NULL, 1, 101, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (257, '海南省三亚市吉阳区', '海南省三亚市吉阳区', NULL, NULL, 1, 102, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (258, '海南省儋州市那大镇', '海南省儋州市那大镇', NULL, NULL, 1, 103, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (259, '海南省琼海市嘉积镇', '海南省琼海市嘉积镇', NULL, NULL, 1, 104, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (260, '海南省文昌市文城镇', '海南省文昌市文城镇', NULL, NULL, 1, 105, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (261, '重庆市渝中区', '重庆市渝中区', NULL, NULL, 1, 106, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (262, '重庆市江北区', '重庆市江北区', NULL, NULL, 1, 107, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (263, '重庆市南岸区', '重庆市南岸区', NULL, NULL, 1, 108, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (264, '重庆市渝北区', '重庆市渝北区', NULL, NULL, 1, 109, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (265, '重庆市九龙坡区', '重庆市九龙坡区', NULL, NULL, 1, 110, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (266, '四川省成都市武侯区', '四川省成都市武侯区', NULL, NULL, 1, 111, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (267, '四川省绵阳市涪城区', '四川省绵阳市涪城区', NULL, NULL, 1, 112, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (268, '四川省德阳市旌阳区', '四川省德阳市旌阳区', NULL, NULL, 1, 113, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (269, '四川省乐山市市中区', '四川省乐山市市中区', NULL, NULL, 1, 114, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (270, '四川省南充市顺庆区', '四川省南充市顺庆区', NULL, NULL, 1, 115, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (271, '贵州省贵阳市观山湖区', '贵州省贵阳市观山湖区', NULL, NULL, 1, 116, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (272, '贵州省遵义市汇川区', '贵州省遵义市汇川区', NULL, NULL, 1, 117, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (273, '贵州省六盘水市钟山区', '贵州省六盘水市钟山区', NULL, NULL, 1, 118, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (274, '贵州省毕节市七星关区', '贵州省毕节市七星关区', NULL, NULL, 1, 119, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (275, '贵州省安顺市西秀区', '贵州省安顺市西秀区', NULL, NULL, 1, 120, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (276, '云南省昆明市五华区', '云南省昆明市五华区', NULL, NULL, 1, 121, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (277, '云南省曲靖市麒麟区', '云南省曲靖市麒麟区', NULL, NULL, 1, 122, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (278, '云南省玉溪市红塔区', '云南省玉溪市红塔区', NULL, NULL, 1, 123, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (279, '云南省大理州大理市', '云南省大理州大理市', NULL, NULL, 1, 124, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (280, '云南省西双版纳州景洪市', '云南省西双版纳州景洪市', NULL, NULL, 1, 125, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (281, '西藏自治区拉萨市城关区', '西藏自治区拉萨市城关区', NULL, NULL, 1, 126, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (282, '西藏自治区日喀则市桑珠孜区', '西藏自治区日喀则市桑珠孜区', NULL, NULL, 1, 127, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (283, '西藏自治区林芝市巴宜区', '西藏自治区林芝市巴宜区', NULL, NULL, 1, 128, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (284, '西藏自治区昌都市卡若区', '西藏自治区昌都市卡若区', NULL, NULL, 1, 129, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (285, '西藏自治区山南市乃东区', '西藏自治区山南市乃东区', NULL, NULL, 1, 130, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (286, '陕西省西安市雁塔区', '陕西省西安市雁塔区', NULL, NULL, 1, 131, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (287, '陕西省咸阳市秦都区', '陕西省咸阳市秦都区', NULL, NULL, 1, 132, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (288, '陕西省宝鸡市金台区', '陕西省宝鸡市金台区', NULL, NULL, 1, 133, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (289, '陕西省榆林市榆阳区', '陕西省榆林市榆阳区', NULL, NULL, 1, 134, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (290, '陕西省渭南市临渭区', '陕西省渭南市临渭区', NULL, NULL, 1, 135, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (291, '甘肃省兰州市城关区', '甘肃省兰州市城关区', NULL, NULL, 1, 136, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (292, '甘肃省天水市秦州区', '甘肃省天水市秦州区', NULL, NULL, 1, 137, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (293, '甘肃省酒泉市肃州区', '甘肃省酒泉市肃州区', NULL, NULL, 1, 138, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (294, '甘肃省庆阳市西峰区', '甘肃省庆阳市西峰区', NULL, NULL, 1, 139, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (295, '甘肃省张掖市甘州区', '甘肃省张掖市甘州区', NULL, NULL, 1, 140, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (296, '青海省西宁市城西区', '青海省西宁市城西区', NULL, NULL, 1, 141, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (297, '青海省海东市乐都区', '青海省海东市乐都区', NULL, NULL, 1, 142, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (298, '青海省海西州格尔木市', '青海省海西州格尔木市', NULL, NULL, 1, 143, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (299, '青海省海南州共和县', '青海省海南州共和县', NULL, NULL, 1, 144, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (300, '青海省玉树州玉树市', '青海省玉树州玉树市', NULL, NULL, 1, 145, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (301, '宁夏回族自治区银川市金凤区', '宁夏回族自治区银川市金凤区', NULL, NULL, 1, 146, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (302, '宁夏回族自治区石嘴山市大武口区', '宁夏回族自治区石嘴山市大武口区', NULL, NULL, 1, 147, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (303, '宁夏回族自治区吴忠市利通区', '宁夏回族自治区吴忠市利通区', NULL, NULL, 1, 148, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (304, '宁夏回族自治区固原市原州区', '宁夏回族自治区固原市原州区', NULL, NULL, 1, 149, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (305, '宁夏回族自治区中卫市沙坡头区', '宁夏回族自治区中卫市沙坡头区', NULL, NULL, 1, 150, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (306, '新疆维吾尔自治区乌鲁木齐市水磨沟区', '新疆维吾尔自治区乌鲁木齐市水磨沟区', NULL, NULL, 1, 151, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (307, '新疆维吾尔自治区克拉玛依市克拉玛依区', '新疆维吾尔自治区克拉玛依市克拉玛依区', NULL, NULL, 1, 152, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (308, '新疆维吾尔自治区喀什地区喀什市', '新疆维吾尔自治区喀什地区喀什市', NULL, NULL, 1, 153, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (309, '新疆维吾尔自治区伊犁州伊宁市', '新疆维吾尔自治区伊犁州伊宁市', NULL, NULL, 1, 154, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (310, '新疆维吾尔自治区巴音郭楞州库尔勒市', '新疆维吾尔自治区巴音郭楞州库尔勒市', NULL, NULL, 1, 155, 1, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-12 11:38:03');


-- ----------------------------
-- 表结构: xy_publish_logs
-- ----------------------------
DROP TABLE IF EXISTS `xy_publish_logs`;
CREATE TABLE `xy_publish_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` bigint NOT NULL COMMENT 'æ“ä½œç”¨æˆ·ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'é—²é±¼è´¦å·ID',
  `title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å•†å“æ ‡é¢˜',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å•†å“æè¿°',
  `price` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å‘å¸ƒä»·æ ¼',
  `material_id` bigint DEFAULT NULL COMMENT 'å…³è”çš„ç´ æID',
  `batch_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‰¹æ¬¡ID',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending' COMMENT 'çŠ¶æ€',
  `item_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å‘å¸ƒæˆåŠŸåŽçš„å•†å“é“¾æŽ¥',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å‘å¸ƒæˆåŠŸåŽçš„å•†å“ID',
  `error_message` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¤±è´¥åŽŸå› ',
  `resolved_address_id` bigint DEFAULT NULL COMMENT 'æœ¬æ¬¡å‘å¸ƒå‘½ä¸­çš„åœ°å€æ± ID',
  `resolved_address_text` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æœ¬æ¬¡å‘å¸ƒå®žé™…ä½¿ç”¨çš„åœ°å€æœç´¢è¯',
  `address_source` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'åœ°å€æ¥æº',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_batch_id` (`batch_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_publish_user_created` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å•†å“å‘å¸ƒæ—¥å¿—è¡¨';

-- 表 xy_publish_logs 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_recharge_orders
-- ----------------------------
DROP TABLE IF EXISTS `xy_recharge_orders`;
CREATE TABLE `xy_recharge_orders` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `order_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å……å€¼è®¢å•å·',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·ID',
  `amount` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å……å€¼é‡‘é¢',
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending' COMMENT 'è®¢å•çŠ¶æ€',
  `trade_no` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¯ä»˜å®äº¤æ˜“å·',
  `qr_code` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¯ä»˜äºŒç»´ç å†…å®¹',
  `paid_at` datetime DEFAULT NULL COMMENT 'æ”¯ä»˜æ—¶é—´',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å……å€¼è®¢å•è¡¨';

-- 表数据: xy_recharge_orders


-- ----------------------------
-- 表结构: xy_risk_control_logs
-- ----------------------------
DROP TABLE IF EXISTS `xy_risk_control_logs`;
CREATE TABLE `xy_risk_control_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'æ—¥å¿—ID',
  `owner_id` bigint DEFAULT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `account_id` bigint DEFAULT NULL COMMENT 'å…³è”è´¦å·ID',
  `account_identifier` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è´¦å·æ ‡è¯†',
  `event_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'slider_captcha' COMMENT 'äº‹ä»¶ç±»åž‹',
  `event_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'äº‹ä»¶æè¿°',
  `processing_result` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å¤„ç†ç»“æžœ',
  `processing_status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'processing' COMMENT 'å¤„ç†çŠ¶æ€',
  `captcha_engine` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'éªŒè¯å¼•æ“Ž',
  `error_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_event_type` (`event_type`),
  KEY `idx_rcl_account_status` (`account_id`,`processing_status`),
  KEY `idx_rcl_identifier_status_created` (`account_identifier`,`processing_status`,`created_at`),
  KEY `idx_rcl_owner_created` (`owner_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='é£ŽæŽ§æ—¥å¿—è¡¨';

-- 表 xy_risk_control_logs 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_scheduled_api_cookie_renew_log
-- ----------------------------
DROP TABLE IF EXISTS `xy_scheduled_api_cookie_renew_log`;
CREATE TABLE `xy_scheduled_api_cookie_renew_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `batch_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ‰¹æ¬¡ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `status` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŠ¶æ€',
  `updated_cookie_count` int NOT NULL DEFAULT '0' COMMENT 'æ›´æ–°çš„Cookieå­—æ®µæ•°é‡',
  `updated_cookie_names` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'æ›´æ–°çš„Cookieå­—æ®µååˆ—è¡¨',
  `response_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'æŽ¥å£è¿”å›žå†…å®¹',
  `error_message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_batch_id` (`batch_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æŽ¥å£ç»­æœŸCookiesæ—¥å¿—è¡¨';

-- 表 xy_scheduled_api_cookie_renew_log 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_scheduled_close_notice_log
-- ----------------------------
DROP TABLE IF EXISTS `xy_scheduled_close_notice_log`;
CREATE TABLE `xy_scheduled_close_notice_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `batch_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ‰¹æ¬¡ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŠ¶æ€',
  `error_message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_batch_id` (`batch_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å…³é—­é€šçŸ¥æ—¥å¿—è¡¨';

-- 表 xy_scheduled_close_notice_log 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_scheduled_cookies_refresh_log
-- ----------------------------
DROP TABLE IF EXISTS `xy_scheduled_cookies_refresh_log`;
CREATE TABLE `xy_scheduled_cookies_refresh_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `batch_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ‰¹æ¬¡ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŠ¶æ€',
  `updated_cookie_count` int NOT NULL DEFAULT '0' COMMENT 'å¢žé‡æ›´æ–°çš„Cookieå­—æ®µæ•°é‡',
  `next_expire_at` datetime DEFAULT NULL COMMENT 'ä¸‹æ¬¡åˆ°æœŸæ—¶é—´',
  `error_message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_batch_id` (`batch_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='COOKIESåˆ·æ–°æ—¥å¿—è¡¨';

-- 表 xy_scheduled_cookies_refresh_log 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_scheduled_login_renew_log
-- ----------------------------
DROP TABLE IF EXISTS `xy_scheduled_login_renew_log`;
CREATE TABLE `xy_scheduled_login_renew_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `batch_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ‰¹æ¬¡ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŠ¶æ€',
  `error_message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_batch_id` (`batch_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç™»å½•ç»­æœŸæ—¥å¿—è¡¨';

-- 表 xy_scheduled_login_renew_log 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_scheduled_polish_log
-- ----------------------------
DROP TABLE IF EXISTS `xy_scheduled_polish_log`;
CREATE TABLE `xy_scheduled_polish_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `batch_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ‰¹æ¬¡ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å•†å“ID',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŠ¶æ€',
  `error_message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_batch_id` (`batch_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_spol_created_batch` (`created_at`,`batch_id`),
  KEY `idx_spol_batch_created_status` (`batch_id`,`created_at`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æ“¦äº®æ—¥å¿—è¡¨';

-- 表 xy_scheduled_polish_log 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_scheduled_rate_log
-- ----------------------------
DROP TABLE IF EXISTS `xy_scheduled_rate_log`;
CREATE TABLE `xy_scheduled_rate_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `batch_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ‰¹æ¬¡ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `order_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŠ¶æ€',
  `error_message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_batch_id` (`batch_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_srate_created_batch` (`created_at`,`batch_id`),
  KEY `idx_srate_batch_created_status` (`batch_id`,`created_at`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è¡¥è¯„ä»·æ—¥å¿—è¡¨';

-- 表 xy_scheduled_rate_log 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_scheduled_red_flower_log
-- ----------------------------
DROP TABLE IF EXISTS `xy_scheduled_red_flower_log`;
CREATE TABLE `xy_scheduled_red_flower_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `batch_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ‰¹æ¬¡ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `order_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŠ¶æ€',
  `error_message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_batch_id` (`batch_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_srf_created_batch` (`created_at`,`batch_id`),
  KEY `idx_srf_batch_created_status` (`batch_id`,`created_at`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æ±‚å°çº¢èŠ±æ—¥å¿—è¡¨';

-- 表 xy_scheduled_red_flower_log 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_scheduled_redelivery_log
-- ----------------------------
DROP TABLE IF EXISTS `xy_scheduled_redelivery_log`;
CREATE TABLE `xy_scheduled_redelivery_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `batch_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ‰¹æ¬¡ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `order_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŠ¶æ€',
  `error_message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_batch_id` (`batch_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_srl_created_batch` (`created_at`,`batch_id`),
  KEY `idx_srl_batch_created_status` (`batch_id`,`created_at`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è¡¥å‘è´§æ—¥å¿—è¡¨';

-- 表 xy_scheduled_redelivery_log 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_scheduled_tasks
-- ----------------------------
DROP TABLE IF EXISTS `xy_scheduled_tasks`;
CREATE TABLE `xy_scheduled_tasks` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `task_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ä»»åŠ¡ä»£ç ',
  `task_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ä»»åŠ¡åç§°',
  `interval_seconds` int NOT NULL DEFAULT '60' COMMENT 'æ‰§è¡Œé—´éš”(ç§’)',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'æ˜¯å¦å¯ç”¨',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'ä»»åŠ¡æè¿°',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_task_code` (`task_code`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å®šæ—¶ä»»åŠ¡é…ç½®è¡¨';

-- 表数据: xy_scheduled_tasks
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (15, 'redelivery', '补发货任务', 5, 1, '定时补发货任务', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (16, 'rate', '补评价任务', 20, 1, '定时补评价任务', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (17, 'polish', '擦亮任务', 60, 1, '定时擦亮商品任务', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (18, 'day_switch', '平台日切换任务', 60, 1, '定时执行平台日切换任务', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (19, 'cleanup_browser_data', '清理被禁用账号浏览器数据任务', 600, 0, '定时清理被禁用账号的浏览器数据', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (20, 'fetch_orders', '获取闲鱼订单任务', 600, 1, '定时获取闲鱼订单数据', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (21, 'fetch_pending_orders', '获取待发货订单任务', 60, 1, '定时获取待发货订单并同步收货人姓名/手机号/地址等信息', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (22, 'fetch_items', '获取闲鱼商品任务', 1200, 1, '定时获取所有启用账号的闲鱼在售商品并入库（新增或更新）', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (23, 'login_renew', '登录续期任务', 600, 0, '定时执行闲鱼账号登录续期', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (24, 'cookies_refresh', 'COOKIES续期任务', 600, 0, '定时执行闲鱼账号浏览器COOKIES续期', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (25, 'api_cookie_renew', '接口续期Cookies任务', 3600, 1, '定时通过 hasLogin.do 接口为启用账号续期Cookies并同步Set-Cookie', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (26, 'close_notice', '关闭账号消息通知任务', 600, 0, '定时关闭账号消息通知', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (27, 'red_flower', '求小红花任务', 300, 1, '定时自动求小红花', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (28, 'db_backup', '数据库备份任务', 3600, 1, '定时备份数据库所有表结构与数据到文件', '2026-06-12 11:38:03', '2026-06-12 11:38:03');


-- ----------------------------
-- 表结构: xy_settlement_records
-- ----------------------------
DROP TABLE IF EXISTS `xy_settlement_records`;
CREATE TABLE `xy_settlement_records` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·ID',
  `alipay_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ”¯ä»˜å®ID',
  `payment_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶æ¬¾æ–¹å¼',
  `payment_qrcode` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶æ¬¾ç å›¾ç‰‡è·¯å¾„',
  `amount` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æçŽ°é‡‘é¢',
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending_review' COMMENT 'çŠ¶æ€',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å¤‡æ³¨',
  `reject_reason` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‹’ç»åŽŸå› ',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_sr_user_created_id` (`user_id`,`created_at`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç»“ç®—è®°å½•è¡¨';

-- 表数据: xy_settlement_records


-- ----------------------------
-- 表结构: xy_shared_scan_sessions
-- ----------------------------
DROP TABLE IF EXISTS `xy_shared_scan_sessions`;
CREATE TABLE `xy_shared_scan_sessions` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `session_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ä¼šè¯å”¯ä¸€ID(UUID)',
  `owner_id` bigint NOT NULL COMMENT 'åˆ›å»ºè€…ç”¨æˆ·ID',
  `owner_username` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'åˆ›å»ºè€…ç”¨æˆ·å',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active' COMMENT 'ä¼šè¯çŠ¶æ€',
  `expires_at` datetime NOT NULL COMMENT 'è¿‡æœŸæ—¶é—´(é»˜è®¤72å°æ—¶)',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_id` (`session_id`),
  KEY `idx_session_id` (`session_id`),
  KEY `idx_owner_id` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å…±äº«æ‰«ç ç™»å½•ä¼šè¯è¡¨';

-- 表数据: xy_shared_scan_sessions


-- ----------------------------
-- 表结构: xy_shared_scan_workers
-- ----------------------------
DROP TABLE IF EXISTS `xy_shared_scan_workers`;
CREATE TABLE `xy_shared_scan_workers` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `shared_session_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å…³è”çš„å…±äº«ä¼šè¯ID',
  `sub_session_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å…¼èŒå­ä¼šè¯å”¯ä¸€ID(UUID)',
  `xianyu_session_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å…³è”çš„é—²é±¼QRç™»å½•ä¼šè¯ID',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'qrcode_ready' COMMENT 'çŠ¶æ€',
  `qr_code_url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'äºŒç»´ç å›¾ç‰‡base64 data URL',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‰«ç æˆåŠŸåŽçš„é—²é±¼è´¦å·ID(unb)',
  `cookie_saved` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Cookieæ˜¯å¦å·²ä¿å­˜',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sub_session_id` (`sub_session_id`),
  KEY `idx_shared_session_id` (`shared_session_id`),
  KEY `idx_sub_session_id` (`sub_session_id`),
  KEY `idx_account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å…±äº«æ‰«ç å…¼èŒå·¥ä½œè€…è¡¨';

-- 表数据: xy_shared_scan_workers


-- ----------------------------
-- 表结构: xy_system_settings
-- ----------------------------
DROP TABLE IF EXISTS `xy_system_settings`;
CREATE TABLE `xy_system_settings` (
  `key` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¾ç½®é”®',
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¾ç½®å€¼',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'è®¾ç½®æè¿°',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç³»ç»Ÿè®¾ç½®è¡¨';

-- 表数据: xy_system_settings
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('account.face_verify_timeout_disable', 'true', '人脸验证超时是否自动禁用账号', '2026-06-12 12:35:18');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('auth.footer_ad_html', '© 2026 划算云服务器 ·<a href="http://www.hsykj.com" target="_BLANK">www.hsykj.com</a>', '登录页和注册页底部广告 HTML', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('disclaimer.agree_button_text', '同意并继续', '免责声明同意按钮文案', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('disclaimer.checkbox_text', '我已阅读并同意以上免责声明', '免责声明勾选提示文案', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('disclaimer.content', '数据存储说明\n1. 本系统在运行过程中，为保障服务正常运行，会存储用户账号密码、登录 Cookie、商品信息、卡券信息等业务数据。\n2. 上述数据仅用于系统功能运行、自动化处理和业务管理，不作为其他用途。\n3. 请您自行确认服务器环境、账号权限和数据保管措施的安全性。\n\n用户须知\n1. 用户应确保使用本系统的行为符合相关平台规则和法律法规。\n2. 因用户自身违规操作、账号共享、密码泄露、服务器安全问题导致的损失，由用户自行承担。\n3. 建议用户定期备份重要数据，因系统故障、第三方平台变更、不可抗力等导致的异常或损失，本系统不承担责任。\n4. 本系统依赖第三方平台接口和网络环境，无法保证服务始终连续、稳定、无中断。\n\n隐私与风险提示\n1. 请勿在未充分评估风险的情况下接入生产环境或敏感账号。\n2. 使用本系统即表示您已充分理解并接受相关风险，并愿意自行承担相应责任。', '系统免责声明正文', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('disclaimer.disagree_button_text', '不同意', '免责声明不同意按钮文案', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('disclaimer.title', '免责声明', '系统免责声明标题', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('log.retention_days', '7', '日志保留天数（所有模块生效，修改后重启服务生效）', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('login.system_description', '自动回复、智能客服、订单管理、数据分析，一站式解决闲鱼运营难题', '登录页系统描述', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('login.system_name', '闲鱼管理系统', '登录页系统名称', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('login.system_title', '高效专业的\n闲鱼自动化管理平台', '登录页系统标题', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('proxy.api_url', '', '代理 API 的 URL（可能较长，用于配置外部代理服务）', '2026-06-12 12:35:18');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('proxy.enabled', 'false', '是否启用代理（true/false）', '2026-06-12 12:35:18');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('security.jwt_secret_key', 'f44e01dfba71c904a3e248eda1c119d0087fe927265ca2580786da9e123cd86f', '系统 JWT 密钥（由数据库统一托管，自动生成，请勿泄露）', '2026-06-12 11:38:04');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('show_default_login_info', 'true', '登录页是否展示默认账号密码提示', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('theme.color_preset', 'ocean', '系统主题颜色预设', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('theme.effect', 'solid', '系统主题效果（solid-纯色，gradient-炫彩）', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('theme.font_family', 'system', '系统主题字体预设', '2026-06-12 12:35:18');


-- ----------------------------
-- 表结构: xy_token_cache
-- ----------------------------
DROP TABLE IF EXISTS `xy_token_cache`;
CREATE TABLE `xy_token_cache` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ç”¨æˆ·ID(myid)',
  `token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'IM Token',
  `device_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¾å¤‡ID',
  `expire_at` datetime NOT NULL COMMENT 'è¿‡æœŸæ—¶é—´',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tokenç¼“å­˜è¡¨';

-- 表数据: xy_token_cache


-- ----------------------------
-- 表结构: xy_user_settings
-- ----------------------------
DROP TABLE IF EXISTS `xy_user_settings`;
CREATE TABLE `xy_user_settings` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'è®¾ç½®ID',
  `user_id` int NOT NULL COMMENT 'ç”¨æˆ·ID',
  `key` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¾ç½®é”®',
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¾ç½®å€¼',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'è®¾ç½®æè¿°',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_key` (`user_id`,`key`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç”¨æˆ·è®¾ç½®è¡¨';

-- 表数据: xy_user_settings


-- ----------------------------
-- 表结构: xy_users
-- ----------------------------
DROP TABLE IF EXISTS `xy_users`;
CREATE TABLE `xy_users` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ç”¨æˆ·ID',
  `external_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¤–éƒ¨ID',
  `username` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ç”¨æˆ·å',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'é‚®ç®±',
  `phone` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‰‹æœºå·',
  `password_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å¯†ç å“ˆå¸Œ',
  `status` enum('ACTIVE','INACTIVE','SUSPENDED','DELETED') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ACTIVE' COMMENT 'ç”¨æˆ·çŠ¶æ€',
  `role` enum('ADMIN','OPERATOR','MEMBER') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'MEMBER' COMMENT 'ç”¨æˆ·è§’è‰²',
  `account_limit` int DEFAULT NULL COMMENT 'å¯æ·»åŠ è´¦å·æ•°é‡',
  `last_login_at` datetime DEFAULT NULL COMMENT 'æœ€åŽç™»å½•æ—¶é—´',
  `login_fail_count` int DEFAULT '0' COMMENT 'ç™»å½•å¤±è´¥æ¬¡æ•°',
  `login_locked_until` datetime DEFAULT NULL COMMENT 'ç™»å½•é”å®šæˆªæ­¢æ—¶é—´',
  `dock_code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¯¹æŽ¥ç ',
  `secret_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'åˆ†é”€ç§˜é’¥',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `dock_code` (`dock_code`),
  UNIQUE KEY `secret_key` (`secret_key`),
  KEY `idx_external_id` (`external_id`),
  KEY `idx_username` (`username`),
  KEY `idx_email` (`email`),
  KEY `idx_user_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç”¨æˆ·è¡¨';

-- 表数据: xy_users
INSERT INTO `xy_users` (`id`, `external_id`, `username`, `email`, `phone`, `password_hash`, `status`, `role`, `account_limit`, `last_login_at`, `login_fail_count`, `login_locked_until`, `dock_code`, `secret_key`, `created_at`, `updated_at`) VALUES (2, NULL, 'admin', 'admin@example.com', NULL, '$pbkdf2-sha256$29000$05pTqrV27j1H6N3b2/v/3w$ZOG2AbJByPzzCBHHA8MPdvCAnGqsPBsbrfVqGMK9GM8', 'ACTIVE', 'ADMIN', NULL, NULL, 0, NULL, NULL, 'UmkYCfXzro9Qwwk8PLdedw1TSVrmU8Z8', '2026-06-12 11:38:03', '2026-06-12 11:38:03');


SET FOREIGN_KEY_CHECKS=1;
