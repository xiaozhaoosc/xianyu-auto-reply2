-- 数据库备份文件
-- 数据库: xianyu_data
-- 备份时间(北京时间): 2026-06-14 00:25:10
-- 说明: 本文件由定时任务自动生成。普通表备份结构与数据，日志表仅备份结构

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;


-- ----------------------------
-- 表结构: fy_accounts
-- ----------------------------
DROP TABLE IF EXISTS `fy_accounts`;
CREATE TABLE `fy_accounts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `owner_id` bigint NOT NULL COMMENT '所属用户ID',
  `account_id` varchar(80) NOT NULL COMMENT '账号标识',
  `account_type` enum('TAOBAO','JD','MEITUAN') NOT NULL DEFAULT 'TAOBAO' COMMENT '账号类型：TAOBAO/JD/MEITUAN',
  `display_name` varchar(120) DEFAULT NULL COMMENT '显示名称',
  `cookie` text NOT NULL COMMENT '账号Cookie',
  `app_key` varchar(80) DEFAULT NULL COMMENT '淘宝开放平台AppKey',
  `app_secret` varchar(200) DEFAULT NULL COMMENT '淘宝开放平台AppSecret',
  `adzone_id` varchar(80) DEFAULT NULL COMMENT '淘宝推广位ID',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `last_login_at` datetime DEFAULT NULL COMMENT '最后登录时间',
  `disable_reason` varchar(255) DEFAULT NULL COMMENT '禁用原因',
  `created_at` datetime NOT NULL DEFAULT (now()),
  `updated_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `ix_fy_accounts_account_id` (`account_id`),
  KEY `idx_fy_account_type` (`account_type`),
  KEY `idx_fy_account_created` (`created_at`),
  KEY `idx_fy_account_owner` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 表数据: fy_accounts


-- ----------------------------
-- 表结构: fy_delete_rules
-- ----------------------------
DROP TABLE IF EXISTS `fy_delete_rules`;
CREATE TABLE `fy_delete_rules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `owner_id` bigint NOT NULL COMMENT '所属用户ID',
  `rule_name` varchar(120) NOT NULL COMMENT '规则名称',
  `account_id` varchar(80) NOT NULL COMMENT '闲鱼账号ID（xy_accounts.account_id）',
  `daily_count` int NOT NULL DEFAULT '5' COMMENT '每天删除数量',
  `min_publish_days` int NOT NULL DEFAULT '7' COMMENT '发布满多少天才能删除',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `last_run_at` datetime DEFAULT NULL COMMENT '最后执行时间',
  `last_run_date` date DEFAULT NULL COMMENT '最后执行日期（用于判断今天是否已完成）',
  `today_count` int NOT NULL DEFAULT '0' COMMENT '今天已删除数量',
  `total_deleted_count` int NOT NULL DEFAULT '0' COMMENT '累计删除数量',
  `created_at` datetime NOT NULL DEFAULT (now()),
  `updated_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_fy_delete_rules_owner_account` (`owner_id`,`account_id`),
  KEY `ix_fy_delete_rules_owner_id` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 表数据: fy_delete_rules


-- ----------------------------
-- 表结构: fy_materials
-- ----------------------------
DROP TABLE IF EXISTS `fy_materials`;
CREATE TABLE `fy_materials` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `owner_id` bigint NOT NULL COMMENT '所属用户ID',
  `account_id` varchar(80) DEFAULT NULL COMMENT '闲鱼账号ID（xy_accounts.account_id）',
  `rule_id` bigint DEFAULT NULL COMMENT '来源选品规则ID',
  `item_id` varchar(50) NOT NULL COMMENT '淘宝商品ID',
  `title` varchar(500) NOT NULL COMMENT '商品标题',
  `price` decimal(10,2) NOT NULL DEFAULT '0.10' COMMENT '售价（默认0.1）',
  `stock` int NOT NULL DEFAULT '999' COMMENT '库存',
  `description` text COMMENT '商品描述',
  `images` text COMMENT '商品图片URL列表（JSON数组）',
  `click_url` varchar(1000) DEFAULT NULL COMMENT '推广链接',
  `coupon_url` varchar(1000) DEFAULT NULL COMMENT '券二合一推广链接',
  `tpwd` varchar(200) DEFAULT NULL COMMENT '淘口令',
  `short_url` varchar(1000) DEFAULT NULL COMMENT '短连接',
  `original_price` varchar(20) DEFAULT NULL COMMENT '商品原价',
  `commission_rate` varchar(20) DEFAULT NULL COMMENT '佣金率',
  `commission_amount` varchar(20) DEFAULT NULL COMMENT '佣金金额',
  `promotion_price` varchar(20) DEFAULT NULL COMMENT '到手价',
  `coupon_info` varchar(255) DEFAULT NULL COMMENT '优惠券信息',
  `shop_title` varchar(200) DEFAULT NULL COMMENT '店铺名称',
  `volume` varchar(50) DEFAULT NULL COMMENT '月销量',
  `publish_status` varchar(20) NOT NULL DEFAULT 'unpublished' COMMENT '发布状态',
  `published` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已发布到闲鱼',
  `published_at` datetime DEFAULT NULL COMMENT '发布时间',
  `published_item_id` varchar(64) DEFAULT NULL COMMENT '发布后闲鱼商品ID',
  `publish_random_str` varchar(32) DEFAULT NULL COMMENT '发布随机字符',
  `created_at` datetime NOT NULL DEFAULT (now()),
  `updated_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `idx_fy_material_account` (`account_id`),
  KEY `idx_fy_material_owner` (`owner_id`),
  KEY `idx_fy_material_owner_account_publish_status` (`owner_id`,`account_id`,`publish_status`),
  KEY `idx_fy_material_rule` (`rule_id`),
  KEY `idx_fy_material_item` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 表数据: fy_materials


-- ----------------------------
-- 表结构: fy_product_rules
-- ----------------------------
DROP TABLE IF EXISTS `fy_product_rules`;
CREATE TABLE `fy_product_rules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `owner_id` bigint NOT NULL COMMENT '所属用户ID',
  `account_id` varchar(80) DEFAULT NULL COMMENT '闲鱼账号ID（xy_accounts.account_id）',
  `rule_name` varchar(120) NOT NULL COMMENT '规则名称',
  `cat` varchar(50) DEFAULT NULL COMMENT '商品类目ID',
  `cat_name` varchar(100) DEFAULT NULL COMMENT '商品类目名称（冗余存储便于展示）',
  `keyword` varchar(200) DEFAULT NULL COMMENT '商品关键词',
  `sort` varchar(50) NOT NULL DEFAULT 'default' COMMENT '排序规则',
  `daily_count` int NOT NULL DEFAULT '10' COMMENT '每天选品条数',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `last_run_at` datetime DEFAULT NULL COMMENT '最后执行时间',
  `last_run_date` date DEFAULT NULL COMMENT '最后执行日期（用于判断今天是否已完成）',
  `today_count` int NOT NULL DEFAULT '0' COMMENT '今天已选品数量',
  `total_selected_count` int NOT NULL DEFAULT '0' COMMENT '累计选品数量',
  `created_at` datetime NOT NULL DEFAULT (now()),
  `updated_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `ix_fy_product_rules_owner_id` (`owner_id`),
  KEY `ix_fy_product_rules_account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 表数据: fy_product_rules


-- ----------------------------
-- 表结构: fy_publish_rules
-- ----------------------------
DROP TABLE IF EXISTS `fy_publish_rules`;
CREATE TABLE `fy_publish_rules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `owner_id` bigint NOT NULL COMMENT '所属用户ID',
  `rule_name` varchar(120) NOT NULL COMMENT '规则名称',
  `account_id` varchar(80) NOT NULL COMMENT '闲鱼账号ID（xy_accounts.account_id）',
  `daily_count` int NOT NULL DEFAULT '5' COMMENT '每天发布数量',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `last_run_at` datetime DEFAULT NULL COMMENT '最后执行时间',
  `last_run_date` date DEFAULT NULL COMMENT '最后执行日期（用于判断今天是否已完成）',
  `today_count` int NOT NULL DEFAULT '0' COMMENT '今天已发布数量',
  `created_at` datetime NOT NULL DEFAULT (now()),
  `updated_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_fy_publish_rules_owner_account` (`owner_id`,`account_id`),
  KEY `ix_fy_publish_rules_owner_id` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 表数据: fy_publish_rules


-- ----------------------------
-- 表结构: xy_account_login_logs
-- ----------------------------
DROP TABLE IF EXISTS `xy_account_login_logs`;
CREATE TABLE `xy_account_login_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'æ—¥å¿—ID',
  `owner_id` bigint DEFAULT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `account_id` bigint DEFAULT NULL COMMENT 'å…³è”è´¦å·ID(xy_accounts.id)',
  `account_identifier` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¸šåŠ¡è´¦å·ID',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ç™»å½•ç”¨æˆ·åå¿«ç…§',
  `trigger_reason` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è§¦å‘ç™»å½•åŽŸå› ',
  `login_status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'failed' COMMENT 'ç™»å½•çŠ¶æ€',
  `failure_reason` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¤±è´¥åŽŸå› ',
  `error_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'è¯¦ç»†é”™è¯¯æ¶ˆæ¯',
  `updated_cookie_names` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æŽ¥å£ç»­æœŸæ›´æ–°çš„Cookieå­—æ®µå',
  `duration_ms` int DEFAULT NULL COMMENT 'ç™»å½•æµç¨‹è€—æ—¶(æ¯«ç§’)',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_all_owner_id` (`owner_id`),
  KEY `idx_all_account_id` (`account_id`),
  KEY `idx_all_login_status` (`login_status`),
  KEY `idx_all_identifier_status_created` (`account_identifier`,`login_status`,`created_at`),
  KEY `idx_all_owner_created` (`owner_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è´¦å·ç™»å½•æ—¥å¿—è¡¨';

-- 表 xy_account_login_logs 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_accounts
-- ----------------------------
DROP TABLE IF EXISTS `xy_accounts`;
CREATE TABLE `xy_accounts` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'è´¦å·ID',
  `owner_id` bigint NOT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·æ ‡è¯†',
  `display_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ˜¾ç¤ºåç§°',
  `unb` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'UNBæ ‡è¯†',
  `cookie` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Cookieä¿¡æ¯',
  `login_method` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ç™»å½•æ–¹å¼',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active' COMMENT 'è´¦å·çŠ¶æ€',
  `username` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ç™»å½•ç”¨æˆ·å',
  `login_password` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'ç™»å½•å¯†ç ',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¤‡æ³¨',
  `pause_duration` int DEFAULT '10' COMMENT 'æš‚åœæ—¶é•¿(åˆ†é’Ÿ)',
  `auto_confirm` tinyint(1) DEFAULT '0' COMMENT 'è‡ªåŠ¨ç¡®è®¤å‘è´§',
  `show_browser` tinyint(1) DEFAULT '0' COMMENT 'æ˜¾ç¤ºæµè§ˆå™¨',
  `metadata` json DEFAULT NULL COMMENT 'å…ƒæ•°æ®',
  `last_login_at` datetime DEFAULT NULL COMMENT 'æœ€åŽç™»å½•æ—¶é—´',
  `last_refresh_at` datetime DEFAULT NULL COMMENT 'æœ€åŽåˆ·æ–°æ—¶é—´',
  `proxy_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'none' COMMENT 'ä»£ç†ç±»åž‹',
  `proxy_host` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä»£ç†ä¸»æœº',
  `proxy_port` int DEFAULT NULL COMMENT 'ä»£ç†ç«¯å£',
  `proxy_user` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä»£ç†ç”¨æˆ·å',
  `proxy_pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä»£ç†å¯†ç ',
  `message_expire_time` int DEFAULT '3600' COMMENT 'ç›¸åŒæ¶ˆæ¯ç­‰å¾…æ—¶é—´(ç§’)',
  `reply_delay_seconds` int DEFAULT '0' COMMENT 'è‡ªåŠ¨å›žå¤å»¶è¿Ÿæ—¶é—´(ç§’)',
  `disable_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ç¦ç”¨åŽŸå› ',
  `scheduled_redelivery` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'å®šæ—¶è¡¥å‘è´§å¼€å…³',
  `scheduled_rate` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'å®šæ—¶è¡¥è¯„ä»·å¼€å…³',
  `auto_polish` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'å•†å“è‡ªåŠ¨æ“¦äº®å¼€å…³',
  `confirm_before_send` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'å‘è´§æˆåŠŸå†å‘å¡åˆ¸å¼€å…³',
  `send_before_confirm` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'å¡åˆ¸å‘é€æˆåŠŸå†ç¡®è®¤å‘è´§å¼€å…³',
  `auto_red_flower` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'è‡ªåŠ¨æ±‚å°çº¢èŠ±å¼€å…³',
  `delivery_disabled` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'ç¦æ­¢å‘è´§å¼€å…³',
  `delivery_disabled_reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ç¦æ­¢å‘è´§åŽŸå› ',
  `auto_close_order` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'ä¸»åŠ¨å…³é—­è®¢å•å¼€å…³',
  `delivery_only_card_after_close` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'å…³é—­è®¢å•åŽç»§ç»­å‘è´§ï¼ˆåªå‘å¡åˆ¸ï¼‰',
  `delivery_disabled_excluded_items` json DEFAULT NULL COMMENT 'ç¦æ­¢å‘è´§æŽ’é™¤å•†å“åˆ—è¡¨',
  `ai_reply_block_ordered_users` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'å·²ä¸‹å•ç”¨æˆ·ç¦æ­¢AIå›žå¤',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_unb` (`unb`),
  KEY `idx_account_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='é—²é±¼è´¦å·è¡¨';

-- 表数据: xy_accounts
INSERT INTO `xy_accounts` (`id`, `owner_id`, `account_id`, `display_name`, `unb`, `cookie`, `login_method`, `status`, `username`, `login_password`, `remark`, `pause_duration`, `auto_confirm`, `show_browser`, `metadata`, `last_login_at`, `last_refresh_at`, `proxy_type`, `proxy_host`, `proxy_port`, `proxy_user`, `proxy_pass`, `message_expire_time`, `reply_delay_seconds`, `disable_reason`, `scheduled_redelivery`, `scheduled_rate`, `auto_polish`, `confirm_before_send`, `send_before_confirm`, `auto_red_flower`, `delivery_disabled`, `delivery_disabled_reason`, `auto_close_order`, `delivery_only_card_after_close`, `delivery_disabled_excluded_items`, `ai_reply_block_ordered_users`, `created_at`, `updated_at`) VALUES (2, 2, '783149128', 't***1', '783149128', 'cookie2=20d63e2204028883b9e81f0da9bff6fe; _samesite_flag_=true; _tb_token_=eb30befe46835; sgcookie=E100esn1h%2F6ODBHH6HPn0a%2Fv2Zuje3pBaZpnv8TSmqEqEWj0bNXgY7FWqdgTLXtHa36602Xt%2FVHzAUhPA1VnQj5YQ9Brj8UEFuvcxkrigizED9acvHWgnO7p1qvuQE%2FLMvTz; csg=06da6f01; sdkSilent=1781453674519; tfstk=gTiiQ4f3bVz_f61eqsr6-i0CnDLpClZb8jIYMoF28WPC61It3scmTbHOXmH4ijcLOAIvCABsRbHPXcL_Diq_coRJw3KJBAZb0iKSqKNsLvw2pR7H5K1_coRJ9wI453qj6PJY4rkeK-eAgil43yrUO-j4QjPa86yuFoPqgjzU88ylb-ya_6SUO-r4gjr2KvPQnoPqgoJnLA1G07mqADR57scAXvJmbR4gaAPZBAneaP7sQWjV0D03J7-YtiSqxRMqGuKNqEFrP5U8wX-djoDUnfFKa3S3Yz0SH-cMjGrt82i_XDdlFPc0tzoL-UWnZlc0zczh3iHuj5E3L0JAPWn36jog8LIukko8zlupRCUYj8cqffXc0bkKecaImQfUGVe7Y8H6jMqrQ-SzOw7yZhsbLKnFlZaadJVRT3BVTo7vMy9HKaT_7Jw9wpvhlZaadJVJKpb51PyQBQC..', 'qr_scan', 'disabled', '', '', 'p40pro', 10, 1, 1, NULL, '2026-06-12 15:02:40', '2026-06-14 00:06:43', 'none', NULL, NULL, NULL, NULL, 3600, 0, 'Cookie缺少必需的unb字段', 1, 0, 1, 0, 1, 0, 0, NULL, 0, 0, NULL, 0, '2026-06-12 13:31:26', '2026-06-13 16:23:34');
INSERT INTO `xy_accounts` (`id`, `owner_id`, `account_id`, `display_name`, `unb`, `cookie`, `login_method`, `status`, `username`, `login_password`, `remark`, `pause_duration`, `auto_confirm`, `show_browser`, `metadata`, `last_login_at`, `last_refresh_at`, `proxy_type`, `proxy_host`, `proxy_port`, `proxy_user`, `proxy_pass`, `message_expire_time`, `reply_delay_seconds`, `disable_reason`, `scheduled_redelivery`, `scheduled_rate`, `auto_polish`, `confirm_before_send`, `send_before_confirm`, `auto_red_flower`, `delivery_disabled`, `delivery_disabled_reason`, `auto_close_order`, `delivery_only_card_after_close`, `delivery_disabled_excluded_items`, `ai_reply_block_ordered_users`, `created_at`, `updated_at`) VALUES (3, 2, '2221611389164', 'xy871818344345', '2221611389164', 'cookie2=14b6add097bf91c1403986dce43a6692; XSRF-TOKEN=80dbbf4e-03b9-4cee-be9a-d9b2c50ba2aa; _samesite_flag_=true; sgcookie=E100ReTGgeMrzkuDj8bEaz4S%2Ft43R7lWFgn1Ss0ur18aygndkjmfPXBiMORfSPhV7GSSod2DDW1vAHXpmGfUBqjcMTQltvtMtqNuG0gKxLkXF5nZuuowzlTHvjgHMr1NpwRv; tracknick=xy871818344345; csg=9d568a68; t=71d851db33adeede15581b505cadfe57; _tb_token_=f5eeebda9153b; unb=2221611389164; havana_lgc2_77=eyJoaWQiOjIyMjE2MTEzODkxNjQsInNnIjoiMjBjNTZlZDBmZWY2MGU4OGZlODNlNjYyOWI3NTA0MzQiLCJzaXRlIjo3NywidG9rZW4iOiIxaVpBM2c5RWc5UG1Gd2ZmUDc5dUljUSJ9; _hvn_lgc_=77; havana_lgc_exp=1783955759775; mtop_partitioned_detect=1; _m_h5_tk=d465972e1948d0f83fe362f43b4c408b_1781371681782; _m_h5_tk_enc=59bc597595c19e57a7c4cfcc7f4f310d; x5secdata=xg2cccae56ab5636c4ja74b9a6618e9418fd83c02b6fe997c6d71781363943a-717315356a829576438abaac3en2221611389164a33b84c8ce72f0d9a63ecdcfe93b730f153c__bx__h5api.m.goofish.com:443/h5/mtop.taobao.idlemessage.pc.login.token/1.0; x5sectag=548484; x5sec=7b22733b32223a2263333663333264333135366535363335222c22617365727665723b33223a22307c434f667074644547454a716d6b5066352f2f2f2f2f77456f6841517739716e4a69774d3d227d', 'qr_scan', 'disabled', NULL, NULL, 'p30pro', 10, 0, 0, NULL, '2026-06-13 15:16:03', NULL, 'socks5', '127.0.0.1', 7897, NULL, NULL, 3600, 0, '手动禁用', 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, NULL, 0, '2026-06-13 15:16:03', '2026-06-13 16:17:43');


-- ----------------------------
-- 表结构: xy_activation_logs
-- ----------------------------
DROP TABLE IF EXISTS `xy_activation_logs`;
CREATE TABLE `xy_activation_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `machine_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æœºå™¨ç ',
  `code_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ç±»åž‹',
  `generated_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ç”Ÿæˆçš„æ¿€æ´»ç /ç»­æœŸç ',
  `days` int NOT NULL COMMENT 'æœ‰æ•ˆå¤©æ•°',
  `ip_address` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è¯·æ±‚IPåœ°å€',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_machine_id` (`machine_id`),
  KEY `idx_code_type` (`code_type`),
  KEY `idx_machine_type_time` (`machine_id`,`code_type`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æ¿€æ´»ç ç”Ÿæˆæ—¥å¿—è¡¨';

-- 表 xy_activation_logs 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_advertisements
-- ----------------------------
DROP TABLE IF EXISTS `xy_advertisements`;
CREATE TABLE `xy_advertisements` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'å¹¿å‘ŠID',
  `user_id` bigint NOT NULL COMMENT 'ç”³è¯·ç”¨æˆ·ID',
  `title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å¹¿å‘Šæ ‡é¢˜',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å¹¿å‘Šæ­£æ–‡',
  `link` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¹¿å‘Šé“¾æŽ¥',
  `expire_date` date DEFAULT NULL COMMENT 'åˆ°æœŸæ—¥æœŸ',
  `image_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å›¾ç‰‡URL',
  `ad_type` enum('carousel','text') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'text' COMMENT 'å¹¿å‘Šç±»åž‹',
  `months` int DEFAULT NULL COMMENT 'è´­ä¹°æœˆæ•°',
  `total_amount` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¹¿å‘Šæ€»é‡‘é¢',
  `status` enum('unpaid','pending','approved') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'unpaid' COMMENT 'å®¡æ ¸çŠ¶æ€',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_ad_type` (`ad_type`),
  KEY `idx_expire_date` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å¹¿å‘Šè¡¨';

-- 表数据: xy_advertisements


-- ----------------------------
-- 表结构: xy_agent_orders
-- ----------------------------
DROP TABLE IF EXISTS `xy_agent_orders`;
CREATE TABLE `xy_agent_orders` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` bigint NOT NULL COMMENT 'ä¸‹å•ç”¨æˆ·ID',
  `order_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'é—²é±¼è®¢å•å·',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å•†å“ID',
  `card_id` bigint NOT NULL COMMENT 'ä½¿ç”¨çš„å¡åˆ¸ID',
  `dock_record_id` bigint NOT NULL COMMENT 'å¯¹æŽ¥è®°å½•ID',
  `dock_level` int NOT NULL COMMENT 'å¯¹æŽ¥å±‚çº§ï¼š1=ä¸€çº§ï¼Œ2=äºŒçº§',
  `sale_price` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å”®ä»·',
  `dock_price` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å¯¹æŽ¥ä»·æ ¼(æ‹¿è´§ä»·)',
  `card_price` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¡åˆ¸æˆæœ¬(è´§ä¸»å¯¹æŽ¥ä»·)',
  `level2_cost` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'äºŒçº§æ‹¿è´§ä»·',
  `profit` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0.00' COMMENT 'åˆ©æ¶¦',
  `fee_amount` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‰‹ç»­è´¹é‡‘é¢',
  `fee_payer` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‰‹ç»­è´¹æ‰¿æ‹…æ–¹',
  `upstream_user_id` bigint DEFAULT NULL COMMENT 'ä¸Šçº§ç”¨æˆ·ID',
  `upstream_dock_record_id` bigint DEFAULT NULL COMMENT 'ä¸Šçº§å¯¹æŽ¥è®°å½•ID',
  `owner_user_id` bigint DEFAULT NULL COMMENT 'è´§ä¸»ç”¨æˆ·ID',
  `delivery_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å‘è´§å†…å®¹',
  `buyer_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¹°å®¶ID',
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'delivered' COMMENT 'çŠ¶æ€',
  `settle_remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ç»“ç®—å¤‡æ³¨',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_dock_record_id` (`dock_record_id`),
  KEY `idx_upstream_user_id` (`upstream_user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_agent_order_created` (`created_at`),
  KEY `idx_ao_upstream_status` (`upstream_user_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ä»£ç†è®¢å•è¡¨';

-- 表数据: xy_agent_orders


-- ----------------------------
-- 表结构: xy_ai_chat_messages
-- ----------------------------
DROP TABLE IF EXISTS `xy_ai_chat_messages`;
CREATE TABLE `xy_ai_chat_messages` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'æ¶ˆæ¯ID',
  `chat_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'èŠå¤©ID',
  `cookie_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·æ ‡è¯†',
  `user_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ç”¨æˆ·ID',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“ID',
  `role` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è§’è‰²(user/assistant)',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ¶ˆæ¯å†…å®¹',
  `intent` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ„å›¾(price/tech/default)',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_chat_id` (`chat_id`),
  KEY `idx_cookie_id` (`cookie_id`),
  KEY `ix_ai_chat_messages_chat_cookie` (`chat_id`,`cookie_id`),
  KEY `ix_ai_chat_messages_intent` (`cookie_id`,`intent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='AIèŠå¤©æ¶ˆæ¯è¡¨';

-- 表数据: xy_ai_chat_messages


-- ----------------------------
-- 表结构: xy_announcements
-- ----------------------------
DROP TABLE IF EXISTS `xy_announcements`;
CREATE TABLE `xy_announcements` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'å…¬å‘ŠID',
  `title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å…¬å‘Šæ ‡é¢˜',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å…¬å‘Šå†…å®¹',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'æ˜¯å¦å·²åˆ é™¤',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å…¬å‘Šä¿¡æ¯è¡¨';

-- 表数据: xy_announcements


-- ----------------------------
-- 表结构: xy_auto_rate_configs
-- ----------------------------
DROP TABLE IF EXISTS `xy_auto_rate_configs`;
CREATE TABLE `xy_auto_rate_configs` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `enabled` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦å¯ç”¨è‡ªåŠ¨è¯„ä»·',
  `rate_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'text' COMMENT 'è¯„ä»·ç±»åž‹',
  `text_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å›ºå®šè¯„ä»·æ–‡å­—å†…å®¹',
  `api_url` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'APIåœ°å€',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è‡ªåŠ¨è¯„ä»·é…ç½®è¡¨';

-- 表数据: xy_auto_rate_configs


-- ----------------------------
-- 表结构: xy_auto_reply_message_logs
-- ----------------------------
DROP TABLE IF EXISTS `xy_auto_reply_message_logs`;
CREATE TABLE `xy_auto_reply_message_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `owner_id` bigint DEFAULT NULL COMMENT 'æ‰€å±žç³»ç»Ÿç”¨æˆ·ID',
  `owner_username` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‰€å±žç³»ç»Ÿç”¨æˆ·å',
  `account_pk` bigint DEFAULT NULL COMMENT 'è´¦å·ä¸»é”®ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'é—²é±¼è´¦å·ID',
  `account_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é—²é±¼è´¦å·æ˜¾ç¤ºåç§°',
  `chat_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'èŠå¤©ä¼šè¯ID',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“ID',
  `item_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“æ ‡é¢˜',
  `source_message_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æºæ¶ˆæ¯ID',
  `sender_user_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å‘é€æ–¹é—²é±¼ç”¨æˆ·ID',
  `sender_user_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å‘é€æ–¹æ˜µç§°',
  `source_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'æ”¶åˆ°çš„æ¶ˆæ¯å†…å®¹',
  `source_message_time` datetime DEFAULT NULL COMMENT 'æ”¶åˆ°æ¶ˆæ¯æ—¶é—´',
  `process_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'processing' COMMENT 'å¤„ç†çŠ¶æ€',
  `decision_reason` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'processing' COMMENT 'å†³ç­–åŽŸå› ',
  `reply_strategy` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none' COMMENT 'å›žå¤ç­–ç•¥',
  `reply_mode` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none' COMMENT 'å›žå¤æ¨¡å¼',
  `matched_keyword` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å‘½ä¸­çš„å…³é”®è¯',
  `matched_rule_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å‘½ä¸­çš„è§„åˆ™ç±»åž‹',
  `default_reply_scope` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é»˜è®¤å›žå¤ä½œç”¨åŸŸ',
  `default_reply_once` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'é»˜è®¤å›žå¤æ˜¯å¦ä»…å›žå¤ä¸€æ¬¡',
  `ai_model_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'AIæ¨¡åž‹åç§°',
  `ai_provider_name` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'AIæœåŠ¡å•†åç§°',
  `reply_text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å›žå¤æ–‡æœ¬å†…å®¹',
  `reply_image_url` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å›žå¤å›¾ç‰‡URL',
  `reply_segments` json DEFAULT NULL COMMENT 'æ‹†åˆ†åŽçš„å›žå¤åˆ†æ®µ',
  `error_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'é”™è¯¯ä¿¡æ¯',
  `send_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unknown' COMMENT 'å‘é€çŠ¶æ€',
  `send_fail_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å‘é€å¤±è´¥åŽŸå› ',
  `raw_message_json` json DEFAULT NULL COMMENT 'åŽŸå§‹æ¶ˆæ¯JSON',
  `context_snapshot` json DEFAULT NULL COMMENT 'ä¸Šä¸‹æ–‡å¿«ç…§',
  `send_result_json` json DEFAULT NULL COMMENT 'å‘é€ç»“æžœå¿«ç…§',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_account_pk` (`account_pk`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_chat_id` (`chat_id`),
  KEY `idx_item_id` (`item_id`),
  KEY `idx_source_message_id` (`source_message_id`),
  KEY `idx_sender_user_id` (`sender_user_id`),
  KEY `idx_process_status` (`process_status`),
  KEY `idx_decision_reason` (`decision_reason`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_arml_account_created` (`account_id`,`created_at`),
  KEY `idx_arml_account_status_created` (`account_id`,`process_status`,`created_at`),
  KEY `idx_arml_owner_created` (`owner_id`,`created_at`),
  KEY `idx_arml_owner_status_created` (`owner_id`,`process_status`,`created_at`),
  KEY `idx_arml_status_created` (`process_status`,`created_at`),
  KEY `idx_arml_status_strategy_created` (`process_status`,`reply_strategy`,`created_at`),
  KEY `idx_arml_strategy_created` (`reply_strategy`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è‡ªåŠ¨å›žå¤æ¶ˆæ¯æ—¥å¿—è¡¨';

-- 表 xy_auto_reply_message_logs 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_card_item_relations
-- ----------------------------
DROP TABLE IF EXISTS `xy_card_item_relations`;
CREATE TABLE `xy_card_item_relations` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` bigint NOT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `card_id` bigint NOT NULL COMMENT 'å¡åˆ¸ID',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å•†å“ID',
  `source` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'own' COMMENT 'å¡åˆ¸æ¥æº',
  `dock_record_id` bigint NOT NULL DEFAULT '0' COMMENT 'å¯¹æŽ¥è®°å½•ID',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_card_item_dock` (`card_id`,`item_id`,`dock_record_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_card_id` (`card_id`),
  KEY `idx_item_id` (`item_id`),
  KEY `idx_cir_user_item` (`user_id`,`item_id`),
  KEY `idx_cir_item_card` (`item_id`,`card_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å¡åˆ¸å•†å“å…³è”è¡¨';

-- 表数据: xy_card_item_relations
INSERT INTO `xy_card_item_relations` (`id`, `user_id`, `card_id`, `item_id`, `source`, `dock_record_id`, `created_at`, `updated_at`) VALUES (1, 2, 1, '1059707364746', 'own', 0, '2026-06-12 15:51:32', '2026-06-12 15:51:32');


-- ----------------------------
-- 表结构: xy_cards
-- ----------------------------
DROP TABLE IF EXISTS `xy_cards`;
CREATE TABLE `xy_cards` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'å¡åˆ¸ID',
  `user_id` bigint NOT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å…³è”å•†å“ID',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å¡åˆ¸åç§°',
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å¡åˆ¸ç±»åž‹(api/text/data/image)',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å¡åˆ¸æè¿°',
  `enabled` tinyint(1) DEFAULT '1' COMMENT 'æ˜¯å¦å¯ç”¨',
  `delay_seconds` int DEFAULT '0' COMMENT 'å»¶è¿Ÿç§’æ•°',
  `delivery_count` int DEFAULT '0' COMMENT 'å‘è´§æ¬¡æ•°',
  `price` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¯¹æŽ¥ä»·æ ¼',
  `is_dockable` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦å¯å¯¹æŽ¥',
  `fee_payer` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‰‹ç»­è´¹æ”¯ä»˜æ–¹å¼',
  `min_price` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æœ€ä½Žå”®ä»·',
  `dock_visibility` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¯¹æŽ¥å¯è§æ€§',
  `is_multi_spec` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦å¤šè§„æ ¼',
  `spec_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è§„æ ¼åç§°',
  `spec_value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è§„æ ¼å€¼',
  `api_config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'APIé…ç½®(JSON)',
  `text_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `data_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `image_url` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å›¾ç‰‡URL',
  `image_urls` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å¤šå›¾ç‰‡URLåˆ—è¡¨(JSON)',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_item_id` (`item_id`),
  KEY `idx_card_user_item` (`user_id`,`item_id`),
  KEY `idx_cards_dockable_enabled` (`is_dockable`,`enabled`),
  KEY `idx_cards_user_id_desc` (`user_id`,`id`),
  KEY `idx_cards_user_enabled` (`user_id`,`enabled`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å¡åˆ¸è¡¨';

-- 表数据: xy_cards
INSERT INTO `xy_cards` (`id`, `user_id`, `item_id`, `name`, `type`, `description`, `enabled`, `delay_seconds`, `delivery_count`, `price`, `is_dockable`, `fee_payer`, `min_price`, `dock_visibility`, `is_multi_spec`, `spec_name`, `spec_value`, `api_config`, `text_content`, `data_content`, `image_url`, `image_urls`, `created_at`, `updated_at`) VALUES (1, 2, NULL, '2023 广州国际车展', 'text', NULL, 1, 0, 1, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, '我用夸克网盘给你分享了「2023 广州国际车展」，点击链接或复制整段内容，打开「夸克APP」即可获取。\n/~f5df3Z1cx1~:/\n链接：https://pan.quark.cn/s/5219bc54049e?pwd=TnJU\n提取码：TnJU', NULL, NULL, NULL, '2026-06-12 15:41:38', '2026-06-13 09:48:35');
INSERT INTO `xy_cards` (`id`, `user_id`, `item_id`, `name`, `type`, `description`, `enabled`, `delay_seconds`, `delivery_count`, `price`, `is_dockable`, `fee_payer`, `min_price`, `dock_visibility`, `is_multi_spec`, `spec_name`, `spec_value`, `api_config`, `text_content`, `data_content`, `image_url`, `image_urls`, `created_at`, `updated_at`) VALUES (2, 2, NULL, '星露谷', 'text', NULL, 1, 0, 0, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, '我用夸克网盘给你分享了「星露谷」，点击链接或复制整段内容，打开「夸克APP」即可获取。\n/~b6fd3Z2Zk9~:/\n链接：https://pan.quark.cn/s/02baa6efcca1?pwd=9XzN\n提取码：9XzN', NULL, NULL, NULL, '2026-06-13 14:54:01', '2026-06-13 14:54:01');


-- ----------------------------
-- 表结构: xy_catalog_items
-- ----------------------------
DROP TABLE IF EXISTS `xy_catalog_items`;
CREATE TABLE `xy_catalog_items` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'å•†å“ID',
  `owner_id` bigint NOT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `account_id` bigint NOT NULL COMMENT 'å…³è”è´¦å·ID',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å•†å“æ ‡è¯†',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“æ ‡é¢˜',
  `price` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“ä»·æ ¼',
  `ai_prompt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å•†å“AIæç¤ºè¯',
  `is_polished` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦æ“¦äº®',
  `metadata` json DEFAULT NULL COMMENT 'å•†å“å…ƒæ•°æ®',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cat_account_item` (`account_id`,`item_id`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_item_id` (`item_id`),
  KEY `idx_cat_account_item` (`account_id`,`item_id`),
  KEY `idx_cat_owner_created` (`owner_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å•†å“ç›®å½•è¡¨';

-- 表数据: xy_catalog_items
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (1, 2, 2, '1053254968789', '戏曲合集，包含多种地方戏曲，如越剧、京剧、豫剧等，经典唱段应', '¥0.59', NULL, 1, '{"detail": "{\\"id\\": \\"1053254968789\\", \\"title\\": \\"戏曲合集，包含多种地方戏曲，如越剧、京剧、豫剧等，经典唱段应\\", \\"price\\": \\"0.59\\", \\"price_text\\": \\"¥0.59\\", \\"category_id\\": 200922010, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1053254968789&flutter=true&needNotPreGet=true&hitNativeGroupItemV5=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 700, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i2/783149128/O1CN01EukMv42HIgQgY7zxI_!!4611686018427381832-0-xy_item.jpg\\", \\"width\\": 948}, \\"detail_params\\": {\\"picWidth\\": \\"948\\", \\"itemId\\": \\"1053254968789\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i2/783149128/O1CN01EukMv42HIgQgY7zxI_!!4611686018427381832-0-xy_item.jpg\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":700,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/783149128/O1CN01EukMv42HIgQgY7zxI_!!4611686018427381832-0-xy_item.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":948},{\\\\\\"heightSize\\\\\\":716,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/783149128/O1CN013XBDqf2HIgQgYTu3M_!!4611686018427381832-0-xy_item.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":768}]\\", \\"picHeight\\": \\"700\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"0.59\\", \\"title\\": \\"戏曲合集，包含多种地方戏曲，如越剧、京剧、豫剧等，经典唱段应\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_1047\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"2人小刀价\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"1人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r3\\": {\\"tagList\\": [{\\"data\\": {\\"color\\": \\"#FF4444\\", \\"size\\": \\"12\\", \\"labelId\\": \\"1047\\", \\"borderPaddingLeft\\": \\"2\\", \\"lineHeight\\": \\"1.5\\", \\"type\\": \\"text\\", \\"content\\": \\"2人小刀价\\", \\"marginLeft\\": \\"2\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"2人小刀价\\"}, \\"arg1\\": \\"46_tag_r3_1047\\"}}, {\\"data\\": {\\"color\\": \\"#999999\\", \\"size\\": \\"11\\", \\"labelId\\": \\"9\\", \\"isStrikeThrough\\": \\"false\\", \\"lineHeight\\": \\"1.5\\", \\"bold\\": \\"false\\", \\"type\\": \\"text\\", \\"content\\": \\"1人想要\\", \\"marginLeft\\": \\"2\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"1人想要\\"}, \\"arg1\\": \\"46_tag_r3_9\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"false\\"}}, \\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_1047\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"2人小刀价\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"1人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "200922010", "description": ""}', '2026-06-12 13:31:51', '2026-06-14 00:06:43');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (2, 2, 2, '1050068076391', 'F清扬电路零基础课+强化课资料包（网课 基础和强化最全讲义）', '¥5.60', NULL, 1, '{"detail": "{\\"id\\": \\"1050068076391\\", \\"title\\": \\"F清扬电路零基础课+强化课资料包（网课 基础和强化最全讲义）\\", \\"price\\": \\"5.60\\", \\"price_text\\": \\"¥5.60\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1050068076391&flutter=true&needNotPreGet=true&hitNativeGroupItemV5=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1920, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01etcIkV1BsxvTiz7xG_!!4611686018427385794-53-xy_item.heic\\", \\"width\\": 1156}, \\"detail_params\\": {\\"picWidth\\": \\"1156\\", \\"itemId\\": \\"1050068076391\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01etcIkV1BsxvTiz7xG_!!4611686018427385794-53-xy_item.heic\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01etcIkV1BsxvTiz7xG_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1156},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/2221269080002/O1CN01MAxAFc1BsxvOQxowE_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1172},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN015ZyuhE1BsxvTekTPP_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1120},{\\\\\\"heightSize\\\\\\":1912,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01NA5bSp1BsxvT156m0_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1264},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01rwmwUx1BsxvT6y5qj_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1152},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN01HQhLcn1BsxvOQvwV3_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1148}]\\", \\"picHeight\\": \\"1920\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"5.60\\", \\"title\\": \\"F清扬电路零基础课+强化课资料包（网课 基础和强化最全讲义）\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r2_1291\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"热销第1名\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_1047\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"2人小刀价\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"17人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r2\\": {\\"tagList\\": [{\\"data\\": {\\"color\\": \\"#FF7900\\", \\"size\\": \\"12\\", \\"labelId\\": \\"1291\\", \\"lineHeight\\": \\"1.33\\", \\"type\\": \\"gradientImageText\\", \\"content\\": \\"热销第1名\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"热销第1名\\"}, \\"arg1\\": \\"46_tag_r2_1291\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"false\\"}}, \\"r3\\": {\\"tagList\\": [{\\"data\\": {\\"color\\": \\"#FF4444\\", \\"size\\": \\"12\\", \\"labelId\\": \\"1047\\", \\"borderPaddingLeft\\": \\"2\\", \\"lineHeight\\": \\"1.5\\", \\"type\\": \\"text\\", \\"content\\": \\"2人小刀价\\", \\"marginLeft\\": \\"2\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"2人小刀价\\"}, \\"arg1\\": \\"46_tag_r3_1047\\"}}, {\\"data\\": {\\"color\\": \\"#999999\\", \\"size\\": \\"11\\", \\"labelId\\": \\"9\\", \\"isStrikeThrough\\": \\"false\\", \\"lineHeight\\": \\"1.5\\", \\"bold\\": \\"false\\", \\"type\\": \\"text\\", \\"content\\": \\"17人想要\\", \\"marginLeft\\": \\"2\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"17人想要\\"}, \\"arg1\\": \\"46_tag_r3_9\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"false\\"}}, \\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r2_1291\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"热销第1名\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_1047\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"2人小刀价\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"17人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-12 13:31:51', '2026-06-14 00:06:43');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (3, 2, 2, '1048216690627', '26考研逻辑、写作救命班资料合集', '¥4', NULL, 1, '{"detail": "{\\"id\\": \\"1048216690627\\", \\"title\\": \\"26考研逻辑、写作救命班资料合集\\", \\"price\\": \\"4\\", \\"price_text\\": \\"¥4\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1048216690627&flutter=true&needNotPreGet=true&hitNativeGroupItemV5=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 520, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/783149128/O1CN01eMw54y2HIgQcVScsA_!!4611686018427381832-0-xy_item.jpg\\", \\"width\\": 1344}, \\"detail_params\\": {\\"picWidth\\": \\"1344\\", \\"itemId\\": \\"1048216690627\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/783149128/O1CN01eMw54y2HIgQcVScsA_!!4611686018427381832-0-xy_item.jpg\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":520,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/783149128/O1CN01eMw54y2HIgQcVScsA_!!4611686018427381832-0-xy_item.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1344},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/783149128/O1CN01ZdjzyP2HIgQcgN3si_!!4611686018427381832-0-xy_item.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":872},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/783149128/O1CN01ZSBLMm2HIgQcbyXMz_!!4611686018427381832-0-xy_item.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":872},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/783149128/O1CN01LUhWE62HIgQcnWThh_!!4611686018427381832-0-xy_item.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":872},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/783149128/O1CN01jLFqTY2HIgQcWbmrs_!!4611686018427381832-0-xy_item.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":872},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/783149128/O1CN01AML6fj2HIgQe8ILoe_!!4611686018427381832-0-xy_item.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":872}]\\", \\"picHeight\\": \\"520\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"4\\", \\"title\\": \\"26考研逻辑、写作救命班资料合集\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r2_1291\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"热销第2名\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_1047\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"2人小刀价\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"11人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r2\\": {\\"tagList\\": [{\\"data\\": {\\"color\\": \\"#FF7900\\", \\"size\\": \\"12\\", \\"labelId\\": \\"1291\\", \\"lineHeight\\": \\"1.33\\", \\"type\\": \\"gradientImageText\\", \\"content\\": \\"热销第2名\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"热销第2名\\"}, \\"arg1\\": \\"46_tag_r2_1291\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"false\\"}}, \\"r3\\": {\\"tagList\\": [{\\"data\\": {\\"color\\": \\"#FF4444\\", \\"size\\": \\"12\\", \\"labelId\\": \\"1047\\", \\"borderPaddingLeft\\": \\"2\\", \\"lineHeight\\": \\"1.5\\", \\"type\\": \\"text\\", \\"content\\": \\"2人小刀价\\", \\"marginLeft\\": \\"2\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"2人小刀价\\"}, \\"arg1\\": \\"46_tag_r3_1047\\"}}, {\\"data\\": {\\"color\\": \\"#999999\\", \\"size\\": \\"11\\", \\"labelId\\": \\"9\\", \\"isStrikeThrough\\": \\"false\\", \\"lineHeight\\": \\"1.5\\", \\"bold\\": \\"false\\", \\"type\\": \\"text\\", \\"content\\": \\"11人想要\\", \\"marginLeft\\": \\"2\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"11人想要\\"}, \\"arg1\\": \\"46_tag_r3_9\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"false\\"}}, \\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r2_1291\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"热销第2名\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_1047\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"2人小刀价\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"11人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-12 13:31:51', '2026-06-14 00:06:43');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (4, 2, 2, '1052357413302', '情侣飞行棋游戏，各种版本都有，电子版的哦！30个飞行棋游戏，', '¥1', NULL, 1, '{"detail": "{\\"id\\": \\"1052357413302\\", \\"title\\": \\"情侣飞行棋游戏，各种版本都有，电子版的哦！30个飞行棋游戏，\\", \\"price\\": \\"1\\", \\"price_text\\": \\"¥1\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1052357413302&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1780, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i3/2219641367657/O1CN01ixI18z26Qxn2bjWWy_!!4611686018427382889-0-xy_item.jpg\\", \\"width\\": 1260}, \\"detail_params\\": {\\"picWidth\\": \\"1260\\", \\"itemId\\": \\"1052357413302\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i3/2219641367657/O1CN01ixI18z26Qxn2bjWWy_!!4611686018427382889-0-xy_item.jpg\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1780,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/2219641367657/O1CN01ixI18z26Qxn2bjWWy_!!4611686018427382889-0-xy_item.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1260},{\\\\\\"heightSize\\\\\\":1260,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/2219641367657/O1CN01DvWbEV26Qxn2sEXQj_!!4611686018427382889-0-xy_item.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1260}]\\", \\"picHeight\\": \\"1780\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"1\\", \\"title\\": \\"情侣飞行棋游戏，各种版本都有，电子版的哦！30个飞行棋游戏，\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-12 13:31:51', '2026-06-14 00:06:43');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (5, 2, 2, '1051383570430', '【秒发货】央视力荐342部儿童必看纪录片合集，总大小3.55', '¥1.68', NULL, 1, '{"detail": "{\\"id\\": \\"1051383570430\\", \\"title\\": \\"【秒发货】央视力荐342部儿童必看纪录片合集，总大小3.55\\", \\"price\\": \\"1.68\\", \\"price_text\\": \\"¥1.68\\", \\"category_id\\": 200922010, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1051383570430&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1608, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/872070032/O1CN01hMRTkk1C6hn3OZpQY_!!4611686018427386768-53-xy_item.heic\\", \\"width\\": 1280}, \\"detail_params\\": {\\"picWidth\\": \\"1280\\", \\"itemId\\": \\"1051383570430\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/872070032/O1CN01hMRTkk1C6hn3OZpQY_!!4611686018427386768-53-xy_item.heic\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1608,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/872070032/O1CN01hMRTkk1C6hn3OZpQY_!!4611686018427386768-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1280},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/872070032/O1CN01PUBsPT1C6hn7z9czy_!!4611686018427386768-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":880},{\\\\\\"heightSize\\\\\\":1268,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/872070032/O1CN017Mju3K1C6hn8t49Ea_!!4611686018427386768-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1280},{\\\\\\"heightSize\\\\\\":1088,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/872070032/O1CN01bWJuQ41C6hn8QPPch_!!4611686018427386768-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1272},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/872070032/O1CN01aGpEJQ1C6hn7j8AJN_!!4611686018427386768-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1072}]\\", \\"picHeight\\": \\"1608\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"1.68\\", \\"title\\": \\"【秒发货】央视力荐342部儿童必看纪录片合集，总大小3.55\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "200922010", "description": ""}', '2026-06-12 13:31:51', '2026-06-14 00:06:43');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (6, 2, 2, '1050074176106', '2026公共英语三级PETS3全套备考资料真题词汇口语听力作', '¥0.88', NULL, 1, '{"detail": "{\\"id\\": \\"1050074176106\\", \\"title\\": \\"2026公共英语三级PETS3全套备考资料真题词汇口语听力作\\", \\"price\\": \\"0.88\\", \\"price_text\\": \\"¥0.88\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1050074176106&flutter=true&needNotPreGet=true&hitNativeGroupItemV5=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1888, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN01EPCNLV1Bsxv6EarsK_!!4611686018427385794-53-xy_item.heic\\", \\"width\\": 1260}, \\"detail_params\\": {\\"picWidth\\": \\"1260\\", \\"itemId\\": \\"1050074176106\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN01EPCNLV1Bsxv6EarsK_!!4611686018427385794-53-xy_item.heic\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1888,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN01EPCNLV1Bsxv6EarsK_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1260},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN01sknTwX1Bsxv5rlf3p_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1260},{\\\\\\"heightSize\\\\\\":1216,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN01cIz5wh1Bsxv7b5UCo_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1260}]\\", \\"picHeight\\": \\"1888\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"0.88\\", \\"title\\": \\"2026公共英语三级PETS3全套备考资料真题词汇口语听力作\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_1047\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"2人小刀价\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"2人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r3\\": {\\"tagList\\": [{\\"data\\": {\\"color\\": \\"#FF4444\\", \\"size\\": \\"12\\", \\"labelId\\": \\"1047\\", \\"borderPaddingLeft\\": \\"2\\", \\"lineHeight\\": \\"1.5\\", \\"type\\": \\"text\\", \\"content\\": \\"2人小刀价\\", \\"marginLeft\\": \\"2\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"2人小刀价\\"}, \\"arg1\\": \\"46_tag_r3_1047\\"}}, {\\"data\\": {\\"color\\": \\"#999999\\", \\"size\\": \\"11\\", \\"labelId\\": \\"9\\", \\"isStrikeThrough\\": \\"false\\", \\"lineHeight\\": \\"1.5\\", \\"bold\\": \\"false\\", \\"type\\": \\"text\\", \\"content\\": \\"2人想要\\", \\"marginLeft\\": \\"2\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"2人想要\\"}, \\"arg1\\": \\"46_tag_r3_9\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"false\\"}}, \\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_1047\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"2人小刀价\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"2人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-12 13:31:51', '2026-06-14 00:06:43');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (7, 2, 2, '1048551235483', '外企10年(英语口语)1000页+PDF文档！60套职场口语', '¥1', NULL, 1, '{"detail": "{\\"id\\": \\"1048551235483\\", \\"title\\": \\"外企10年(英语口语)1000页+PDF文档！60套职场口语\\", \\"price\\": \\"1\\", \\"price_text\\": \\"¥1\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1048551235483&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 745, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i2/O1CN01Sh8gRO1yNk2sQntjz_!!4611686018427385831-0-fleamarket.jpg\\", \\"width\\": 799}, \\"detail_params\\": {\\"picWidth\\": \\"799\\", \\"itemId\\": \\"1048551235483\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i2/O1CN01Sh8gRO1yNk2sQntjz_!!4611686018427385831-0-fleamarket.jpg\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":745,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01Sh8gRO1yNk2sQntjz_!!4611686018427385831-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":799},{\\\\\\"heightSize\\\\\\":1082,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01XUCiCr1yNk2slCx15_!!4611686018427385831-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1082},{\\\\\\"heightSize\\\\\\":682,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN01bXU0fu1yNk2rgSowi_!!4611686018427385831-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":531},{\\\\\\"heightSize\\\\\\":1200,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/O1CN01pWAkRV1yNk2ruGwPq_!!4611686018427385831-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":555},{\\\\\\"heightSize\\\\\\":1200,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN01x0l6iF1yNk2sLCiPs_!!4611686018427385831-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":695}]\\", \\"picHeight\\": \\"745\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"1\\", \\"title\\": \\"外企10年(英语口语)1000页+PDF文档！60套职场口语\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_41\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"¥19.89\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r3\\": {\\"tagList\\": [{\\"data\\": {\\"color\\": \\"#999999\\", \\"size\\": \\"12\\", \\"labelId\\": \\"41\\", \\"isStrikeThrough\\": \\"true\\", \\"lineHeight\\": \\"1.3\\", \\"bold\\": \\"false\\", \\"type\\": \\"text\\", \\"content\\": \\"¥19.89\\", \\"marginLeft\\": \\"4\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"¥19.89\\"}, \\"arg1\\": \\"46_tag_r3_41\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"false\\"}}, \\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_41\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"¥19.89\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-12 13:31:51', '2026-06-14 00:06:43');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (8, 2, 2, '1047472375083', '南中教研，南中地理教研2026，最新26届南中地一轮精品课，', '¥7.65', NULL, 1, '{"detail": "{\\"id\\": \\"1047472375083\\", \\"title\\": \\"南中教研，南中地理教研2026，最新26届南中地一轮精品课，\\", \\"price\\": \\"7.65\\", \\"price_text\\": \\"¥7.65\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1047472375083&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1920, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN016T4Q481Bsxu52aJNc_!!4611686018427385794-0-xy_item.jpg\\", \\"width\\": 1040}, \\"detail_params\\": {\\"picWidth\\": \\"1040\\", \\"itemId\\": \\"1047472375083\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN016T4Q481Bsxu52aJNc_!!4611686018427385794-0-xy_item.jpg\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN016T4Q481Bsxu52aJNc_!!4611686018427385794-0-xy_item.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1040},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN01TSX3Aa1Bsxu5qPKM6_!!4611686018427385794-0-xy_item.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":992},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN018d2hNV1Bsxu4C2MjB_!!4611686018427385794-0-xy_item.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":980},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01TaqkKF1Bsxu4yWnEN_!!4611686018427385794-0-xy_item.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":984},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01ykRFyT1Bsxu48NWdN_!!4611686018427385794-0-xy_item.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":964},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/2221269080002/O1CN01SG1yT21Bsxu4yaHVC_!!4611686018427385794-0-xy_item.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":964},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN01EVvgKZ1Bsxu5P56Fz_!!4611686018427385794-0-xy_item.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1220}]\\", \\"picHeight\\": \\"1920\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"7.65\\", \\"title\\": \\"南中教研，南中地理教研2026，最新26届南中地一轮精品课，\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"2人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r3\\": {\\"tagList\\": [{\\"data\\": {\\"color\\": \\"#999999\\", \\"size\\": \\"11\\", \\"labelId\\": \\"9\\", \\"isStrikeThrough\\": \\"false\\", \\"lineHeight\\": \\"1.5\\", \\"bold\\": \\"false\\", \\"type\\": \\"text\\", \\"content\\": \\"2人想要\\", \\"marginLeft\\": \\"2\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"2人想要\\"}, \\"arg1\\": \\"46_tag_r3_9\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"false\\"}}, \\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"2人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-12 13:31:51', '2026-06-14 00:06:43');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (9, 2, 2, '1049185697403', '八下道法课件持续更新！内容丰富，适合初中道法学习，电子版资料', '¥4.44', NULL, 1, '{"detail": "{\\"id\\": \\"1049185697403\\", \\"title\\": \\"八下道法课件持续更新！内容丰富，适合初中道法学习，电子版资料\\", \\"price\\": \\"4.44\\", \\"price_text\\": \\"¥4.44\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1049185697403&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1920, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN01nppyUi1BsxuxPNFDy_!!4611686018427385794-53-xy_item.heic\\", \\"width\\": 1020}, \\"detail_params\\": {\\"picWidth\\": \\"1020\\", \\"itemId\\": \\"1049185697403\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN01nppyUi1BsxuxPNFDy_!!4611686018427385794-53-xy_item.heic\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN01nppyUi1BsxuxPNFDy_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1020}]\\", \\"picHeight\\": \\"1920\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"4.44\\", \\"title\\": \\"八下道法课件持续更新！内容丰富，适合初中道法学习，电子版资料\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-12 13:31:51', '2026-06-14 00:06:43');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (10, 2, 2, '1050078572384', '电气考研电力系统分析课程，赵老师电力系统分析，1～46讲电力', '¥2.29', NULL, 1, '{"detail": "{\\"id\\": \\"1050078572384\\", \\"title\\": \\"电气考研电力系统分析课程，赵老师电力系统分析，1～46讲电力\\", \\"price\\": \\"2.29\\", \\"price_text\\": \\"¥2.29\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1050078572384&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1672, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN01gWk3Le1BsxuyYWELY_!!4611686018427385794-53-xy_item.heic\\", \\"width\\": 1260}, \\"detail_params\\": {\\"picWidth\\": \\"1260\\", \\"itemId\\": \\"1050078572384\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN01gWk3Le1BsxuyYWELY_!!4611686018427385794-53-xy_item.heic\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1672,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN01gWk3Le1BsxuyYWELY_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1260}]\\", \\"picHeight\\": \\"1672\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"2.29\\", \\"title\\": \\"电气考研电力系统分析课程，赵老师电力系统分析，1～46讲电力\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"4人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r3\\": {\\"tagList\\": [{\\"data\\": {\\"color\\": \\"#999999\\", \\"size\\": \\"11\\", \\"labelId\\": \\"9\\", \\"isStrikeThrough\\": \\"false\\", \\"lineHeight\\": \\"1.5\\", \\"bold\\": \\"false\\", \\"type\\": \\"text\\", \\"content\\": \\"4人想要\\", \\"marginLeft\\": \\"2\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"4人想要\\"}, \\"arg1\\": \\"46_tag_r3_9\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"false\\"}}, \\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"4人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-12 13:31:51', '2026-06-14 00:06:43');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (11, 2, 2, '1049182697727', '出英语考编电子版资料 包含答案！', '¥2.70', NULL, 1, '{"detail": "{\\"id\\": \\"1049182697727\\", \\"title\\": \\"出英语考编电子版资料 包含答案！\\", \\"price\\": \\"2.70\\", \\"price_text\\": \\"¥2.70\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1049182697727&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1796, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01nd5sSJ1BsxuzIbZBQ_!!4611686018427385794-53-xy_item.heic\\", \\"width\\": 1260}, \\"detail_params\\": {\\"picWidth\\": \\"1260\\", \\"itemId\\": \\"1049182697727\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01nd5sSJ1BsxuzIbZBQ_!!4611686018427385794-53-xy_item.heic\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1796,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01nd5sSJ1BsxuzIbZBQ_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1260}]\\", \\"picHeight\\": \\"1796\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"2.70\\", \\"title\\": \\"出英语考编电子版资料 包含答案！\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-12 13:31:51', '2026-06-14 00:06:43');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (12, 2, 2, '1048220418392', '秒发货！2026春 新版八年级下 人教版 英语课件17套', '¥3.70', NULL, 1, '{"detail": "{\\"id\\": \\"1048220418392\\", \\"title\\": \\"秒发货！2026春 新版八年级下 人教版 英语课件17套\\", \\"price\\": \\"3.70\\", \\"price_text\\": \\"¥3.70\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1048220418392&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1920, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN019LlljL1Bsxv0RXILj_!!4611686018427385794-53-xy_item.heic\\", \\"width\\": 1136}, \\"detail_params\\": {\\"picWidth\\": \\"1136\\", \\"itemId\\": \\"1048220418392\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN019LlljL1Bsxv0RXILj_!!4611686018427385794-53-xy_item.heic\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN019LlljL1Bsxv0RXILj_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1136},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN01urVB3L1Bsxv1G4mCS_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":964},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN01HLYT3K1Bsxv0oDFlV_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1088},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/2221269080002/O1CN01waUsOD1Bsxv17c52o_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1156},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN01SEM4OR1Bsxv0JYFcm_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":912},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN01pWmDgo1Bsxv12O3IF_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":916},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN01zp1AiW1Bsxv0RW9fX_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":968},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN01r9zcZG1Bsxv0hBP6P_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":964},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN01Vye4xk1Bsxv19eGNg_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":968}]\\", \\"picHeight\\": \\"1920\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"3.70\\", \\"title\\": \\"秒发货！2026春 新版八年级下 人教版 英语课件17套\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"3人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r3\\": {\\"tagList\\": [{\\"data\\": {\\"color\\": \\"#999999\\", \\"size\\": \\"11\\", \\"labelId\\": \\"9\\", \\"isStrikeThrough\\": \\"false\\", \\"lineHeight\\": \\"1.5\\", \\"bold\\": \\"false\\", \\"type\\": \\"text\\", \\"content\\": \\"3人想要\\", \\"marginLeft\\": \\"2\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"3人想要\\"}, \\"arg1\\": \\"46_tag_r3_9\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"false\\"}}, \\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"3人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-12 13:31:51', '2026-06-14 00:06:43');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (13, 2, 2, '1049180733768', '维克多2025年新高中词汇PDF电子版，2025年5月印刷版', '¥1.87', NULL, 1, '{"detail": "{\\"id\\": \\"1049180733768\\", \\"title\\": \\"维克多2025年新高中词汇PDF电子版，2025年5月印刷版\\", \\"price\\": \\"1.87\\", \\"price_text\\": \\"¥1.87\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1049180733768&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1920, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN01nIwU0t1Bsxv217xep_!!4611686018427385794-53-xy_item.heic\\", \\"width\\": 912}, \\"detail_params\\": {\\"picWidth\\": \\"912\\", \\"itemId\\": \\"1049180733768\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN01nIwU0t1Bsxv217xep_!!4611686018427385794-53-xy_item.heic\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN01nIwU0t1Bsxv217xep_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":912},{\\\\\\"heightSize\\\\\\":1724,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN01Pj4Rsf1Bsxv1YCt3J_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1260},{\\\\\\"heightSize\\\\\\":1752,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/2221269080002/O1CN01ZiHnsK1Bsxv39TElF_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1260}]\\", \\"picHeight\\": \\"1920\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"1.87\\", \\"title\\": \\"维克多2025年新高中词汇PDF电子版，2025年5月印刷版\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-12 13:31:51', '2026-06-14 00:06:43');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (14, 2, 2, '1049177205631', '秒发货！2026生地会考时事热点押题PDF+25年会考真题适', '¥2', NULL, 1, '{"detail": "{\\"id\\": \\"1049177205631\\", \\"title\\": \\"秒发货！2026生地会考时事热点押题PDF+25年会考真题适\\", \\"price\\": \\"2\\", \\"price_text\\": \\"¥2\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1049177205631&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1664, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01NRR9aG1BsxvETMdw6_!!4611686018427385794-53-xy_item.heic\\", \\"width\\": 1260}, \\"detail_params\\": {\\"picWidth\\": \\"1260\\", \\"itemId\\": \\"1049177205631\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01NRR9aG1BsxvETMdw6_!!4611686018427385794-53-xy_item.heic\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1664,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01NRR9aG1BsxvETMdw6_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1260},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN01vrbqiu1BsxvFbI9Gc_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1068},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/2221269080002/O1CN01GboWUQ1BsxvETNRpy_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":960},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/2221269080002/O1CN01QW9g1a1BsxvDrmAhB_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":956},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01U0q5vs1BsxvEfYsnp_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":952},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN01ohtl0F1BsxvFbLZOJ_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":960},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN01KqEKqm1BsxvEDNz1h_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":976}]\\", \\"picHeight\\": \\"1664\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"2\\", \\"title\\": \\"秒发货！2026生地会考时事热点押题PDF+25年会考真题适\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"1人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r3\\": {\\"tagList\\": [{\\"data\\": {\\"color\\": \\"#999999\\", \\"size\\": \\"11\\", \\"labelId\\": \\"9\\", \\"isStrikeThrough\\": \\"false\\", \\"lineHeight\\": \\"1.5\\", \\"bold\\": \\"false\\", \\"type\\": \\"text\\", \\"content\\": \\"1人想要\\", \\"marginLeft\\": \\"2\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"1人想要\\"}, \\"arg1\\": \\"46_tag_r3_9\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"false\\"}}, \\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"1人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-12 13:31:51', '2026-06-14 00:06:43');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (15, 2, 2, '1047461435909', '【中考文言文复习专题PPT合集】打包带走！内容超全，适合初中', '¥1.87', NULL, 1, '{"detail": "{\\"id\\": \\"1047461435909\\", \\"title\\": \\"【中考文言文复习专题PPT合集】打包带走！内容超全，适合初中\\", \\"price\\": \\"1.87\\", \\"price_text\\": \\"¥1.87\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1047461435909&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1920, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01Rn664Q1BsxvGYc7hD_!!4611686018427385794-53-xy_item.heic\\", \\"width\\": 1068}, \\"detail_params\\": {\\"picWidth\\": \\"1068\\", \\"itemId\\": \\"1047461435909\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01Rn664Q1BsxvGYc7hD_!!4611686018427385794-53-xy_item.heic\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01Rn664Q1BsxvGYc7hD_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1068},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN01wg2Jqc1BsxvGYYu4o_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":976},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/2221269080002/O1CN012iB8Rb1BsxvGPofJ1_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1048},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN01g8OQSc1BsxvGc9KtH_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1056},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN01eqfv4S1BsxvHqYMmg_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1052},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01wGoqbR1BsxvGPm7JX_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":976},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/2221269080002/O1CN010pGUUb1BsxvGcZUef_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":964},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01wL6mM31BsxvGI8NSi_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":964},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/2221269080002/O1CN01PJSZ371BsxvGvTQQq_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":956}]\\", \\"picHeight\\": \\"1920\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"1.87\\", \\"title\\": \\"【中考文言文复习专题PPT合集】打包带走！内容超全，适合初中\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-12 13:31:51', '2026-06-14 00:02:06');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (16, 2, 2, '1049174001274', '2026内科规培结业资料电子版打包价', '¥1.70', NULL, 1, '{"detail": "{\\"id\\": \\"1049174001274\\", \\"title\\": \\"2026内科规培结业资料电子版打包价\\", \\"price\\": \\"1.70\\", \\"price_text\\": \\"¥1.70\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1049174001274&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1920, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN0130Fg961BsxvNB7KWo_!!4611686018427385794-53-xy_item.heic\\", \\"width\\": 1052}, \\"detail_params\\": {\\"picWidth\\": \\"1052\\", \\"itemId\\": \\"1049174001274\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN0130Fg961BsxvNB7KWo_!!4611686018427385794-53-xy_item.heic\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN0130Fg961BsxvNB7KWo_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1052}]\\", \\"picHeight\\": \\"1920\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"1.70\\", \\"title\\": \\"2026内科规培结业资料电子版打包价\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-12 13:31:51', '2026-06-14 00:06:43');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (17, 2, 2, '1048211350399', '辅导员模拟卷105套（2025+2026多家机构合集[闪亮]', '¥2', NULL, 1, '{"detail": "{\\"id\\": \\"1048211350399\\", \\"title\\": \\"辅导员模拟卷105套（2025+2026多家机构合集[闪亮]\\", \\"price\\": \\"2\\", \\"price_text\\": \\"¥2\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1048211350399&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 792, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01SlHLtA1BsxvaBjE5K_!!4611686018427385794-53-xy_item.heic\\", \\"width\\": 1260}, \\"detail_params\\": {\\"picWidth\\": \\"1260\\", \\"itemId\\": \\"1048211350399\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01SlHLtA1BsxvaBjE5K_!!4611686018427385794-53-xy_item.heic\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":792,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/2221269080002/O1CN01SlHLtA1BsxvaBjE5K_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1260},{\\\\\\"heightSize\\\\\\":660,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/2221269080002/O1CN01i4aEcP1BsxvaBlEp1_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1260},{\\\\\\"heightSize\\\\\\":1640,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN01qyR3LK1BsxvaBkAIE_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1260},{\\\\\\"heightSize\\\\\\":1672,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/2221269080002/O1CN01s5fwHf1BsxvZrrpru_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1260},{\\\\\\"heightSize\\\\\\":1124,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/2221269080002/O1CN01DGMqZw1BsxvZxSCVH_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1260}]\\", \\"picHeight\\": \\"792\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"2\\", \\"title\\": \\"辅导员模拟卷105套（2025+2026多家机构合集[闪亮]\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-12 13:31:51', '2026-06-14 00:06:43');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (18, 2, 2, '1047458047788', '中医规培医学电子书包！2026中医住培结业备考全套资料', '¥3.29', NULL, 1, '{"detail": "{\\"id\\": \\"1047458047788\\", \\"title\\": \\"中医规培医学电子书包！2026中医住培结业备考全套资料\\", \\"price\\": \\"3.29\\", \\"price_text\\": \\"¥3.29\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1047458047788&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1920, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i1/2221269080002/O1CN01Iid4dc1BsxvflGLlW_!!4611686018427385794-53-xy_item.heic\\", \\"width\\": 1140}, \\"detail_params\\": {\\"picWidth\\": \\"1140\\", \\"itemId\\": \\"1047458047788\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i1/2221269080002/O1CN01Iid4dc1BsxvflGLlW_!!4611686018427385794-53-xy_item.heic\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/2221269080002/O1CN01Iid4dc1BsxvflGLlW_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1140}]\\", \\"picHeight\\": \\"1920\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"3.29\\", \\"title\\": \\"中医规培医学电子书包！2026中医住培结业备考全套资料\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-12 13:31:51', '2026-06-14 00:02:04');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (19, 2, 2, '1047457311926', '南中地教研2026二轮课件+学历案+练习资课件，电子版，内容', '¥9', NULL, 1, '{"detail": "{\\"id\\": \\"1047457311926\\", \\"title\\": \\"南中地教研2026二轮课件+学历案+练习资课件，电子版，内容\\", \\"price\\": \\"9\\", \\"price_text\\": \\"¥9\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1047457311926&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1356, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN01zatelk1BsxvDzD6Gv_!!4611686018427385794-53-xy_item.heic\\", \\"width\\": 1260}, \\"detail_params\\": {\\"picWidth\\": \\"1260\\", \\"itemId\\": \\"1047457311926\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN01zatelk1BsxvDzD6Gv_!!4611686018427385794-53-xy_item.heic\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1356,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/2221269080002/O1CN01zatelk1BsxvDzD6Gv_!!4611686018427385794-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1260}]\\", \\"picHeight\\": \\"1356\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"9\\", \\"title\\": \\"南中地教研2026二轮课件+学历案+练习资课件，电子版，内容\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"1人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r3\\": {\\"tagList\\": [{\\"data\\": {\\"color\\": \\"#999999\\", \\"size\\": \\"11\\", \\"labelId\\": \\"9\\", \\"isStrikeThrough\\": \\"false\\", \\"lineHeight\\": \\"1.5\\", \\"bold\\": \\"false\\", \\"type\\": \\"text\\", \\"content\\": \\"1人想要\\", \\"marginLeft\\": \\"2\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"1人想要\\"}, \\"arg1\\": \\"46_tag_r3_9\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"false\\"}}, \\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"1人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-12 13:31:52', '2026-06-14 00:02:01');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (20, 2, 2, '1043037293522', '微信视频号无水印下载', '¥3', NULL, 1, '{"detail": "{\\"id\\": \\"1043037293522\\", \\"title\\": \\"微信视频号无水印下载\\", \\"price\\": \\"3\\", \\"price_text\\": \\"¥3\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1043037293522&hitNativeDetail=true&flutter=true&needNotPreGet=true&isSkill=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1920, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i1/783149128/O1CN01jW0mTo2HIgQ9oa5VB_!!4611686018427381832-0-xy_item.jpg\\", \\"width\\": 880}, \\"detail_params\\": {\\"picWidth\\": \\"880\\", \\"itemId\\": \\"1043037293522\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i1/783149128/O1CN01jW0mTo2HIgQ9oa5VB_!!4611686018427381832-0-xy_item.jpg\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/783149128/O1CN01jW0mTo2HIgQ9oa5VB_!!4611686018427381832-0-xy_item.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":880}]\\", \\"picHeight\\": \\"1920\\", \\"soldPrice\\": \\"3\\", \\"isSkillProductItem\\": \\"true\\", \\"title\\": \\"微信视频号无水印下载\\", \\"isSKU\\": \\"1\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {}, \\"serviceUtParams\\": \\"[]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-12 13:31:52', '2026-06-14 00:01:59');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (21, 2, 2, '989194432248', '磐镭LINK S-1显卡拓展坞，双雷电3高速接口，兼容USB', '¥555', NULL, 1, '{"detail": "{\\"id\\": \\"989194432248\\", \\"title\\": \\"磐镭LINK S-1显卡拓展坞，双雷电3高速接口，兼容USB\\", \\"price\\": \\"555\\", \\"price_text\\": \\"¥555\\", \\"category_id\\": 50025387, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=989194432248&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1920, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i2/O1CN01bZ5jR32HIgO478fTB_!!4611686018427381832-0-fleamarket.jpg\\", \\"width\\": 872}, \\"detail_params\\": {\\"picWidth\\": \\"872\\", \\"itemId\\": \\"989194432248\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i2/O1CN01bZ5jR32HIgO478fTB_!!4611686018427381832-0-fleamarket.jpg\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01bZ5jR32HIgO478fTB_!!4611686018427381832-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":872},{\\\\\\"heightSize\\\\\\":1440,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN01xbuCYK2HIgO5osBc2_!!4611686018427381832-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080},{\\\\\\"heightSize\\\\\\":1080,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN01v3SIIh2HIgO5MPsRT_!!4611686018427381832-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1440}]\\", \\"picHeight\\": \\"1920\\", \\"postInfo\\": \\"包邮或自提\\", \\"soldPrice\\": \\"555\\", \\"title\\": \\"磐镭LINK S-1显卡拓展坞，双雷电3高速接口，兼容USB\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_1017\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"可小刀\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"7人想要\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r3\\": {\\"tagList\\": [{\\"data\\": {\\"color\\": \\"#FF4444\\", \\"size\\": \\"12\\", \\"labelId\\": \\"1017\\", \\"borderPaddingLeft\\": \\"2\\", \\"lineHeight\\": \\"1.5\\", \\"type\\": \\"text\\", \\"content\\": \\"可小刀\\", \\"marginLeft\\": \\"2\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"可小刀\\"}, \\"arg1\\": \\"46_tag_r3_1017\\"}}, {\\"data\\": {\\"color\\": \\"#999999\\", \\"size\\": \\"11\\", \\"labelId\\": \\"9\\", \\"isStrikeThrough\\": \\"false\\", \\"lineHeight\\": \\"1.5\\", \\"bold\\": \\"false\\", \\"type\\": \\"text\\", \\"content\\": \\"7人想要\\", \\"marginLeft\\": \\"2\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"7人想要\\"}, \\"arg1\\": \\"46_tag_r3_9\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"false\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_1017\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"可小刀\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"7人想要\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50025387", "description": ""}', '2026-06-12 13:31:53', '2026-06-14 00:06:43');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (22, 2, 2, '904247951286', '索泰GTX960-2GD5显卡，双风扇设计，性能稳定。显存2', '¥245', NULL, 1, '{"detail": "{\\"id\\": \\"904247951286\\", \\"title\\": \\"索泰GTX960-2GD5显卡，双风扇设计，性能稳定。显存2\\", \\"price\\": \\"245\\", \\"price_text\\": \\"¥245\\", \\"category_id\\": 50025387, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=904247951286&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1440, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i3/O1CN01UnuDOF2HIgKiPWw1N_!!4611686018427381832-0-fleamarket.jpg\\", \\"width\\": 1080}, \\"detail_params\\": {\\"picWidth\\": \\"1080\\", \\"itemId\\": \\"904247951286\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i3/O1CN01UnuDOF2HIgKiPWw1N_!!4611686018427381832-0-fleamarket.jpg\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1440,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN01UnuDOF2HIgKiPWw1N_!!4611686018427381832-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080},{\\\\\\"heightSize\\\\\\":1440,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/O1CN01DMPCjY2HIgKkwf70f_!!4611686018427381832-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080}]\\", \\"picHeight\\": \\"1440\\", \\"postInfo\\": \\"包邮或自提\\", \\"soldPrice\\": \\"245\\", \\"title\\": \\"索泰GTX960-2GD5显卡，双风扇设计，性能稳定。显存2\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"is_xyMarket\\": \\"true\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_1943\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"行情价258元\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"6人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r5_664\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"nfrIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r3\\": {\\"tagList\\": [{\\"data\\": {\\"color\\": \\"#999999\\", \\"size\\": \\"12\\", \\"labelId\\": \\"1943\\", \\"lineHeight\\": \\"1.3\\", \\"type\\": \\"text\\", \\"content\\": \\"行情价258元\\", \\"marginLeft\\": \\"4\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"行情价258元\\"}, \\"arg1\\": \\"46_tag_r3_1943\\"}}, {\\"data\\": {\\"color\\": \\"#999999\\", \\"size\\": \\"11\\", \\"labelId\\": \\"9\\", \\"isStrikeThrough\\": \\"false\\", \\"lineHeight\\": \\"1.5\\", \\"bold\\": \\"false\\", \\"type\\": \\"text\\", \\"content\\": \\"6人想要\\", \\"marginLeft\\": \\"2\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"6人想要\\"}, \\"arg1\\": \\"46_tag_r3_9\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"false\\"}}, \\"r5\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"664\\", \\"width\\": \\"76\\", \\"type\\": \\"img\\", \\"content\\": \\"nfrIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN01IdADAH1ZMwenlz92N_!!6000000003181-2-tps-228-42.png\\", \\"height\\": \\"14\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"nfrIcon\\"}, \\"arg1\\": \\"46_tag_r5_664\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"false\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_1943\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"行情价258元\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"6人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r5_664\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"nfrIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50025387", "description": ""}', '2026-06-12 13:31:53', '2026-06-14 00:06:43');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (24, 2, 2, '1057135931133', '【2025社交软件玩法大全】Soul/陌陌/探探/世纪佳缘/', '¥1', NULL, 1, '{"detail": "{\\"id\\": \\"1057135931133\\", \\"title\\": \\"【2025社交软件玩法大全】Soul/陌陌/探探/世纪佳缘/\\", \\"price\\": \\"1\\", \\"price_text\\": \\"¥1\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": -9, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1057135931133&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1200, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/2814004881/O1CN01oYdNpm1lvYJSMxV9h_!!4611686018427383441-53-xy_item.heic\\", \\"width\\": 694}, \\"detail_params\\": {\\"picWidth\\": \\"694\\", \\"itemId\\": \\"1057135931133\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/2814004881/O1CN01oYdNpm1lvYJSMxV9h_!!4611686018427383441-53-xy_item.heic\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1200,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/2814004881/O1CN01oYdNpm1lvYJSMxV9h_!!4611686018427383441-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":694},{\\\\\\"heightSize\\\\\\":1200,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/2814004881/O1CN01eQ25zV1lvYJRcyG8q_!!4611686018427383441-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":900},{\\\\\\"heightSize\\\\\\":1200,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/2814004881/O1CN01qtGUpx1lvYJSTcVfi_!!4611686018427383441-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":800},{\\\\\\"heightSize\\\\\\":1200,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/2814004881/O1CN01MNdx7j1lvYJRcz43I_!!4611686018427383441-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":800},{\\\\\\"heightSize\\\\\\":1200,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/2814004881/O1CN01X3lV6L1lvYJS9jRvh_!!4611686018427383441-53-xy_item.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":800}]\\", \\"picHeight\\": \\"1200\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"1\\", \\"title\\": \\"【2025社交软件玩法大全】Soul/陌陌/探探/世纪佳缘/\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {}, \\"serviceUtParams\\": \\"[]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-13 09:44:13', '2026-06-14 00:06:43');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (25, 2, 2, '1058981109956', '星露谷物语', '¥0.50', NULL, 1, '{"detail": "{\\"id\\": \\"1058981109956\\", \\"title\\": \\"星露谷物语\\", \\"price\\": \\"0.50\\", \\"price_text\\": \\"¥0.50\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1058981109956&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 790, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i1/O1CN01A7ZJVZ2HIgR2MwDer_!!783149128-49-fleamarket.webp\\", \\"width\\": 790}, \\"detail_params\\": {\\"picWidth\\": \\"790\\", \\"itemId\\": \\"1058981109956\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i1/O1CN01A7ZJVZ2HIgR2MwDer_!!783149128-49-fleamarket.webp\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":790,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN01A7ZJVZ2HIgR2MwDer_!!783149128-49-fleamarket.webp\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":790},{\\\\\\"heightSize\\\\\\":355,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN01gu5o6J2HIgR2iWYlC_!!783149128-2-fleamarket.png\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1385},{\\\\\\"heightSize\\\\\\":412,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN01UB7EUg2HIgQy369Uc_!!783149128-2-fleamarket.png\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":975},{\\\\\\"heightSize\\\\\\":408,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/O1CN01Gt6sgy2HIgR2PdLsu_!!783149128-2-fleamarket.png\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":530},{\\\\\\"heightSize\\\\\\":447,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN012ApSqo2HIgR2PdYNH_!!783149128-2-fleamarket.png\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1001}]\\", \\"picHeight\\": \\"790\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"0.50\\", \\"title\\": \\"星露谷物语\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"5\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r2_492\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"24小时内发布\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"15\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"5\\", \\"labelData\\": {\\"r2\\": {\\"tagList\\": [{\\"data\\": {\\"color\\": \\"#3B3F49\\", \\"gradientDirection\\": \\"to right\\", \\"type\\": \\"gradientImageText\\", \\"content\\": \\"24小时内发布\\", \\"leftImage\\": {\\"marginRight\\": \\"2\\", \\"width\\": \\"14\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i3/O1CN01Z6BeDa1w4qA2xZLFJ_!!6000000006255-2-tps-42-42.png\\", \\"height\\": \\"14\\", \\"marginLeft\\": \\"2\\"}, \\"rightImage\\": {}, \\"gradientColors\\": [\\"#F7F7CC\\", \\"#FFFFFF\\"], \\"borderRadius\\": \\"9\\", \\"size\\": \\"12\\", \\"labelId\\": \\"492\\", \\"lineHeight\\": \\"1.2\\", \\"gradientType\\": \\"linear\\", \\"height\\": \\"18\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"24小时内发布\\"}, \\"arg1\\": \\"46_tag_r2_492\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"false\\"}}, \\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r2_492\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"24小时内发布\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"5\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"5\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-13 15:07:54', '2026-06-14 00:06:43');
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (26, 2, 3, '1053522271837', '【专注力训练】医疗级别训练工具 提升专注力', '¥19.89', NULL, 0, '{"detail": "{\\"id\\": \\"1053522271837\\", \\"title\\": \\"【专注力训练】医疗级别训练工具 提升专注力\\", \\"price\\": \\"19.89\\", \\"price_text\\": \\"¥19.89\\", \\"category_id\\": 50025418, \\"auction_type\\": \\"b\\", \\"item_status\\": -9, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1053522271837&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1918, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i2/O1CN01ZcgGjC29iJYTt4gBT_!!4611686018427384453-0-fleamarket.jpg\\", \\"width\\": 1280}, \\"detail_params\\": {\\"picWidth\\": \\"1280\\", \\"itemId\\": \\"1053522271837\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i2/O1CN01ZcgGjC29iJYTt4gBT_!!4611686018427384453-0-fleamarket.jpg\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1918,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01ZcgGjC29iJYTt4gBT_!!4611686018427384453-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1280},{\\\\\\"heightSize\\\\\\":984,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01nLRs5d29iJYTpTzJG_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080},{\\\\\\"heightSize\\\\\\":1743,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN01JOZhtZ29iJYQgiM0Q_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":941},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN01SaFeVp29iJYLeNMw9_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":818},{\\\\\\"heightSize\\\\\\":912,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01tGp2Rz29iJbowEyzh_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1920},{\\\\\\"heightSize\\\\\\":1444,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN01twt14Q29iJbtSXJnY_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080}]\\", \\"picHeight\\": \\"1918\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"19.89\\", \\"title\\": \\"【专注力训练】医疗级别训练工具 提升专注力\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"14\\", \\"serviceUtParams\\": \\"[]\\", \\"XyhBucketId\\": \\"18\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"14\\", \\"labelData\\": {}, \\"serviceUtParams\\": \\"[]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"14\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"14\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50025418", "description": ""}', '2026-06-13 15:21:16', NULL);
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (27, 2, 3, '1050401654785', '【专注力训练】中科院软件联合研发 五大维度训练系统 提升孩子', '¥19.89', NULL, 0, '{"detail": "{\\"id\\": \\"1050401654785\\", \\"title\\": \\"【专注力训练】中科院软件联合研发 五大维度训练系统 提升孩子\\", \\"price\\": \\"19.89\\", \\"price_text\\": \\"¥19.89\\", \\"category_id\\": 50025418, \\"auction_type\\": \\"b\\", \\"item_status\\": -9, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1050401654785&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1920, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/O1CN012Pa4DQ29iJYAjUg7w_!!4611686018427384453-53-fleamarket.heic\\", \\"width\\": 1440}, \\"detail_params\\": {\\"picWidth\\": \\"1440\\", \\"itemId\\": \\"1050401654785\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/O1CN012Pa4DQ29iJYAjUg7w_!!4611686018427384453-53-fleamarket.heic\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/O1CN012Pa4DQ29iJYAjUg7w_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1440},{\\\\\\"heightSize\\\\\\":357,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN019iAVrA29iJYByrAr7_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1059},{\\\\\\"heightSize\\\\\\":1512,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN01Jwu4BY29iJYCSMFz5_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN01q0RtkL29iJY5hFfXM_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":818},{\\\\\\"heightSize\\\\\\":1743,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN01c7VVka29iJYAjWQDw_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":941},{\\\\\\"heightSize\\\\\\":1918,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN014cUjRp29iJYCSNb9D_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1280}]\\", \\"picHeight\\": \\"1920\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"19.89\\", \\"title\\": \\"【专注力训练】中科院软件联合研发 五大维度训练系统 提升孩子\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"14\\", \\"serviceUtParams\\": \\"[]\\", \\"XyhBucketId\\": \\"18\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"14\\", \\"labelData\\": {}, \\"serviceUtParams\\": \\"[]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"14\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"14\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50025418", "description": ""}', '2026-06-13 15:21:17', NULL);
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (28, 2, 3, '1051038389990', '【专注力训练】智能训练App，帮助孩子提升专注力', '¥19.89', NULL, 0, '{"detail": "{\\"id\\": \\"1051038389990\\", \\"title\\": \\"【专注力训练】智能训练App，帮助孩子提升专注力\\", \\"price\\": \\"19.89\\", \\"price_text\\": \\"¥19.89\\", \\"category_id\\": 50025418, \\"auction_type\\": \\"b\\", \\"item_status\\": -9, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1051038389990&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1920, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i1/O1CN011Rw81x29iJYOjkde4_!!4611686018427384453-53-fleamarket.heic\\", \\"width\\": 1440}, \\"detail_params\\": {\\"picWidth\\": \\"1440\\", \\"itemId\\": \\"1051038389990\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i1/O1CN011Rw81x29iJYOjkde4_!!4611686018427384453-53-fleamarket.heic\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN011Rw81x29iJYOjkde4_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1440},{\\\\\\"heightSize\\\\\\":912,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN01l21AjS29iJYQwzso4_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1920},{\\\\\\"heightSize\\\\\\":1920,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/O1CN018q1mC629iJYRskymY_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1356},{\\\\\\"heightSize\\\\\\":1415,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN01VE5don29iJYPuppE4_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1078},{\\\\\\"heightSize\\\\\\":1329,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/O1CN01nVuZs029iJYQJWd6a_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080},{\\\\\\"heightSize\\\\\\":1657,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN01RDSK8c29iJYOtUBOA_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080}]\\", \\"picHeight\\": \\"1920\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"19.89\\", \\"title\\": \\"【专注力训练】智能训练App，帮助孩子提升专注力\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"14\\", \\"serviceUtParams\\": \\"[]\\", \\"XyhBucketId\\": \\"18\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"14\\", \\"labelData\\": {}, \\"serviceUtParams\\": \\"[]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"14\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"14\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50025418", "description": ""}', '2026-06-13 15:21:17', NULL);
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (29, 2, 3, '1057783578394', '高清起号原创短群大长腿素材', '¥1', NULL, 0, '{"detail": "{\\"id\\": \\"1057783578394\\", \\"title\\": \\"高清起号原创短群大长腿素材\\", \\"price\\": \\"1\\", \\"price_text\\": \\"¥1\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1057783578394&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 620, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/O1CN01drlbpq1XLSShf36wt_!!4611686018427387339-0-fleamarket.jpg\\", \\"width\\": 611}, \\"detail_params\\": {\\"picWidth\\": \\"611\\", \\"itemId\\": \\"1057783578394\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/O1CN01drlbpq1XLSShf36wt_!!4611686018427387339-0-fleamarket.jpg\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":620,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/O1CN01drlbpq1XLSShf36wt_!!4611686018427387339-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":611},{\\\\\\"heightSize\\\\\\":629,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN01hW3jrf1XLSSi2jHHn_!!4611686018427387339-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":697},{\\\\\\"heightSize\\\\\\":618,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN01y0ieke1XLSShmOsi1_!!4611686018427387339-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":648}]\\", \\"picHeight\\": \\"620\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"1\\", \\"title\\": \\"高清起号原创短群大长腿素材\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"14\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r2_492\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"24小时内发布\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"18\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"14\\", \\"labelData\\": {\\"r2\\": {\\"tagList\\": [{\\"data\\": {\\"color\\": \\"#3B3F49\\", \\"gradientDirection\\": \\"to right\\", \\"type\\": \\"gradientImageText\\", \\"content\\": \\"24小时内发布\\", \\"leftImage\\": {\\"marginRight\\": \\"2\\", \\"width\\": \\"14\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i3/O1CN01Z6BeDa1w4qA2xZLFJ_!!6000000006255-2-tps-42-42.png\\", \\"height\\": \\"14\\", \\"marginLeft\\": \\"2\\"}, \\"rightImage\\": {}, \\"gradientColors\\": [\\"#F7F7CC\\", \\"#FFFFFF\\"], \\"borderRadius\\": \\"9\\", \\"size\\": \\"12\\", \\"labelId\\": \\"492\\", \\"lineHeight\\": \\"1.2\\", \\"gradientType\\": \\"linear\\", \\"height\\": \\"18\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"24小时内发布\\"}, \\"arg1\\": \\"46_tag_r2_492\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"false\\"}}, \\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r2_492\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"24小时内发布\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"14\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"14\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-13 15:21:17', NULL);
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (30, 2, 3, '1052063702936', '【ADHD训练】注意力缺陷综合改善，智能系统训练', '¥19.89', NULL, 0, '{"detail": "{\\"id\\": \\"1052063702936\\", \\"title\\": \\"【ADHD训练】注意力缺陷综合改善，智能系统训练\\", \\"price\\": \\"19.89\\", \\"price_text\\": \\"¥19.89\\", \\"category_id\\": 50025418, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1052063702936&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1414, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i3/O1CN01tQ0who29iJYBV4cpt_!!4611686018427384453-53-fleamarket.heic\\", \\"width\\": 1080}, \\"detail_params\\": {\\"picWidth\\": \\"1080\\", \\"itemId\\": \\"1052063702936\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i3/O1CN01tQ0who29iJYBV4cpt_!!4611686018427384453-53-fleamarket.heic\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1414,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN01tQ0who29iJYBV4cpt_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080},{\\\\\\"heightSize\\\\\\":510,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN01yKeNQ629iJYEn6rU4_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":787},{\\\\\\"heightSize\\\\\\":1077,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/O1CN01UaNB1Y29iJYCD0PDc_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080},{\\\\\\"heightSize\\\\\\":1748,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01TJPjOz29iJYDvGFrc_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080},{\\\\\\"heightSize\\\\\\":1073,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01uvTYqk29iJYG2xEJo_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080},{\\\\\\"heightSize\\\\\\":1641,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN01YWoYVw29iJYCD35Wb_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080}]\\", \\"picHeight\\": \\"1414\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"19.89\\", \\"title\\": \\"【ADHD训练】注意力缺陷综合改善，智能系统训练\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"14\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"18\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"14\\", \\"labelData\\": {\\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"14\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"14\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50025418", "description": ""}', '2026-06-13 15:21:17', NULL);
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (31, 2, 3, '1049823711170', '【专注力训练】智能AI训练系统 刻意练习 提升孩子专注力', '¥19.89', NULL, 0, '{"detail": "{\\"id\\": \\"1049823711170\\", \\"title\\": \\"【专注力训练】智能AI训练系统 刻意练习 提升孩子专注力\\", \\"price\\": \\"19.89\\", \\"price_text\\": \\"¥19.89\\", \\"category_id\\": 50025418, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1049823711170&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1282, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i2/O1CN01cgpQMH29iJZ0BjwrQ_!!4611686018427384453-53-fleamarket.heic\\", \\"width\\": 1080}, \\"detail_params\\": {\\"picWidth\\": \\"1080\\", \\"itemId\\": \\"1049823711170\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i2/O1CN01cgpQMH29iJZ0BjwrQ_!!4611686018427384453-53-fleamarket.heic\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1282,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01cgpQMH29iJZ0BjwrQ_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080},{\\\\\\"heightSize\\\\\\":1290,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN01pUTI4429iJYxYQVJH_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080},{\\\\\\"heightSize\\\\\\":1918,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN01iWcdei29iJYzKFA84_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1280},{\\\\\\"heightSize\\\\\\":1443,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN019csxwU29iJYzKGEbt_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080},{\\\\\\"heightSize\\\\\\":1443,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01RSLmJa29iJYzKEco8_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080},{\\\\\\"heightSize\\\\\\":1443,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN017eDVNb29iJZ15Y4AA_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080},{\\\\\\"heightSize\\\\\\":1443,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN0117DvIv29iJZ0by4ts_!!4611686018427384453-53-fleamarket.heic\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080}]\\", \\"picHeight\\": \\"1282\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"19.89\\", \\"title\\": \\"【专注力训练】智能AI训练系统 刻意练习 提升孩子专注力\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"14\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"18\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"14\\", \\"labelData\\": {\\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"14\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"14\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50025418", "description": ""}', '2026-06-13 15:21:17', NULL);
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (32, 2, 3, '1050420945418', '【4位油管最牛知识付费博主合集】Dan Koe、Ali Ab', '¥1.87', NULL, 0, '{"detail": "{\\"id\\": \\"1050420945418\\", \\"title\\": \\"【4位油管最牛知识付费博主合集】Dan Koe、Ali Ab\\", \\"price\\": \\"1.87\\", \\"price_text\\": \\"¥1.87\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1050420945418&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1200, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/O1CN013NFEXD2KEy24yYsoI_!!4611686018427385478-0-fleamarket.jpg\\", \\"width\\": 1200}, \\"detail_params\\": {\\"picWidth\\": \\"1200\\", \\"itemId\\": \\"1050420945418\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i4/O1CN013NFEXD2KEy24yYsoI_!!4611686018427385478-0-fleamarket.jpg\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1200,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/O1CN013NFEXD2KEy24yYsoI_!!4611686018427385478-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1200},{\\\\\\"heightSize\\\\\\":664,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN01EUPWyM2KEy25MxMP5_!!4611686018427385478-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1200},{\\\\\\"heightSize\\\\\\":694,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN01vWAu2k2KEy2601oON_!!4611686018427385478-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1200},{\\\\\\"heightSize\\\\\\":696,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/O1CN015YaNkQ2KEy24l8fsN_!!4611686018427385478-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1200},{\\\\\\"heightSize\\\\\\":720,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01c80gcW2KEy24yWnvK_!!4611686018427385478-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1200},{\\\\\\"heightSize\\\\\\":1200,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN012K1yrN2KEy24yVrik_!!4611686018427385478-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1012},{\\\\\\"heightSize\\\\\\":668,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN01J3k2rt2KEy24zWdzP_!!4611686018427385478-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080}]\\", \\"picHeight\\": \\"1200\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"1.87\\", \\"title\\": \\"【4位油管最牛知识付费博主合集】Dan Koe、Ali Ab\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"14\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"18\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"14\\", \\"labelData\\": {\\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"14\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"14\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-13 15:21:17', NULL);
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (33, 2, 3, '1050420537262', 'PDF全能转换工具秒发【秒发】PDF转换工具全能word/p', '¥1.79', NULL, 0, '{"detail": "{\\"id\\": \\"1050420537262\\", \\"title\\": \\"PDF全能转换工具秒发【秒发】PDF转换工具全能word/p\\", \\"price\\": \\"1.79\\", \\"price_text\\": \\"¥1.79\\", \\"category_id\\": 50025461, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1050420537262&hitNativeDetail=true&flutter=true&needNotPreGet=true&isSkill=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 1004, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i3/O1CN01Qyv8eO2KEy26Wtlpg_!!4611686018427385478-0-fleamarket.jpg\\", \\"width\\": 1080}, \\"detail_params\\": {\\"picWidth\\": \\"1080\\", \\"itemId\\": \\"1050420537262\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i3/O1CN01Qyv8eO2KEy26Wtlpg_!!4611686018427385478-0-fleamarket.jpg\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":1004,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN01Qyv8eO2KEy26Wtlpg_!!4611686018427385478-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080},{\\\\\\"heightSize\\\\\\":208,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01YH8ZQD2KEy25tVNuj_!!4611686018427385478-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":638},{\\\\\\"heightSize\\\\\\":712,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN01iM7a2e2KEy26h1ikj_!!4611686018427385478-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080},{\\\\\\"heightSize\\\\\\":709,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01DG4iuT2KEy26h02o9_!!4611686018427385478-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080},{\\\\\\"heightSize\\\\\\":696,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01Pogae62KEy27Y1XZc_!!4611686018427385478-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080},{\\\\\\"heightSize\\\\\\":711,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01CL2TEj2KEy27D17Ai_!!4611686018427385478-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080},{\\\\\\"heightSize\\\\\\":1092,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01d3aHiR2KEy26Wv2pt_!!4611686018427385478-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1080}]\\", \\"picHeight\\": \\"1004\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"1.79\\", \\"isSkillProductItem\\": \\"true\\", \\"title\\": \\"PDF全能转换工具秒发【秒发】PDF转换工具全能word/p\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"14\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"18\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"14\\", \\"labelData\\": {\\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"14\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"14\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50025461", "description": ""}', '2026-06-13 15:21:17', NULL);
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (34, 2, 3, '1050310933267', '有趣的旅游研学手册研学手册合集大全辽宁博物馆上海博物馆龙||', '¥1', NULL, 0, '{"detail": "{\\"id\\": \\"1050310933267\\", \\"title\\": \\"有趣的旅游研学手册研学手册合集大全辽宁博物馆上海博物馆龙||\\", \\"price\\": \\"1\\", \\"price_text\\": \\"¥1\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1050310933267&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 980, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i2/O1CN01x3K9ND1yNk2h6Bk1Q_!!4611686018427385831-0-fleamarket.jpg\\", \\"width\\": 720}, \\"detail_params\\": {\\"picWidth\\": \\"720\\", \\"itemId\\": \\"1050310933267\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i2/O1CN01x3K9ND1yNk2h6Bk1Q_!!4611686018427385831-0-fleamarket.jpg\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":980,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01x3K9ND1yNk2h6Bk1Q_!!4611686018427385831-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":720},{\\\\\\"heightSize\\\\\\":1119,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN01tWBIpa1yNk2hr3OnX_!!4611686018427385831-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":718},{\\\\\\"heightSize\\\\\\":944,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN01j9XJbL1yNk2iim9Qp_!!4611686018427385831-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":720},{\\\\\\"heightSize\\\\\\":1016,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN01vNOWNy1yNk2iqqDGR_!!4611686018427385831-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":700},{\\\\\\"heightSize\\\\\\":1404,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01cp0CSO1yNk2hAo8aQ_!!4611686018427385831-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":716},{\\\\\\"heightSize\\\\\\":1368,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01E00XGK1yNk2geehv1_!!4611686018427385831-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":716}]\\", \\"picHeight\\": \\"980\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"1\\", \\"title\\": \\"有趣的旅游研学手册研学手册合集大全辽宁博物馆上海博物馆龙||\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"14\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_41\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"¥19.89\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"1人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"18\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"14\\", \\"labelData\\": {\\"r3\\": {\\"tagList\\": [{\\"data\\": {\\"color\\": \\"#999999\\", \\"size\\": \\"12\\", \\"labelId\\": \\"41\\", \\"isStrikeThrough\\": \\"true\\", \\"lineHeight\\": \\"1.3\\", \\"bold\\": \\"false\\", \\"type\\": \\"text\\", \\"content\\": \\"¥19.89\\", \\"marginLeft\\": \\"4\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"¥19.89\\"}, \\"arg1\\": \\"46_tag_r3_41\\"}}, {\\"data\\": {\\"color\\": \\"#999999\\", \\"size\\": \\"11\\", \\"labelId\\": \\"9\\", \\"isStrikeThrough\\": \\"false\\", \\"lineHeight\\": \\"1.5\\", \\"bold\\": \\"false\\", \\"type\\": \\"text\\", \\"content\\": \\"1人想要\\", \\"marginLeft\\": \\"2\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"1人想要\\"}, \\"arg1\\": \\"46_tag_r3_9\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"false\\"}}, \\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_41\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"¥19.89\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_9\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"1人想要\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"14\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"14\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-13 15:21:17', NULL);
INSERT INTO `xy_catalog_items` (`id`, `owner_id`, `account_id`, `item_id`, `title`, `price`, `ai_prompt`, `is_polished`, `metadata`, `created_at`, `updated_at`) VALUES (35, 2, 3, '1049347414774', '外企10年(英语口语)1000页+PDF文档！60套职场口语', '¥1', NULL, 0, '{"detail": "{\\"id\\": \\"1049347414774\\", \\"title\\": \\"外企10年(英语口语)1000页+PDF文档！60套职场口语\\", \\"price\\": \\"1\\", \\"price_text\\": \\"¥1\\", \\"category_id\\": 50023914, \\"auction_type\\": \\"b\\", \\"item_status\\": 0, \\"detail_url\\": \\"fleamarket://awesome_detail?itemId=1049347414774&hitNativeDetail=true&flutter=true&needNotPreGet=true\\", \\"pic_info\\": {\\"hasVideo\\": false, \\"height\\": 745, \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i2/O1CN01Sh8gRO1yNk2sQntjz_!!4611686018427385831-0-fleamarket.jpg\\", \\"width\\": 799}, \\"detail_params\\": {\\"picWidth\\": \\"799\\", \\"itemId\\": \\"1049347414774\\", \\"picUrl\\": \\"http://img.alicdn.com/bao/uploaded/i2/O1CN01Sh8gRO1yNk2sQntjz_!!4611686018427385831-0-fleamarket.jpg\\", \\"imageInfos\\": \\"[{\\\\\\"heightSize\\\\\\":745,\\\\\\"major\\\\\\":true,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01Sh8gRO1yNk2sQntjz_!!4611686018427385831-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":799},{\\\\\\"heightSize\\\\\\":1082,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i2/O1CN01XUCiCr1yNk2slCx15_!!4611686018427385831-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":1082},{\\\\\\"heightSize\\\\\\":682,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i3/O1CN01bXU0fu1yNk2rgSowi_!!4611686018427385831-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":531},{\\\\\\"heightSize\\\\\\":1200,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i4/O1CN01pWAkRV1yNk2ruGwPq_!!4611686018427385831-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":555},{\\\\\\"heightSize\\\\\\":1200,\\\\\\"major\\\\\\":false,\\\\\\"type\\\\\\":0,\\\\\\"url\\\\\\":\\\\\\"http://img.alicdn.com/bao/uploaded/i1/O1CN01x0l6iF1yNk2sLCiPs_!!4611686018427385831-0-fleamarket.jpg\\\\\\",\\\\\\"videoCover\\\\\\":false,\\\\\\"widthSize\\\\\\":695}]\\", \\"picHeight\\": \\"745\\", \\"postInfo\\": \\"包邮\\", \\"soldPrice\\": \\"1\\", \\"title\\": \\"外企10年(英语口语)1000页+PDF文档！60套职场口语\\"}, \\"track_params\\": {\\"isShopUser\\": \\"1\\", \\"XyhBucketInfo\\": \\"db\\", \\"labelBucketId\\": \\"14\\", \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_41\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"¥19.89\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"XyhBucketId\\": \\"18\\"}, \\"item_label_data\\": {\\"labelBucketId\\": \\"14\\", \\"labelData\\": {\\"r3\\": {\\"tagList\\": [{\\"data\\": {\\"color\\": \\"#999999\\", \\"size\\": \\"12\\", \\"labelId\\": \\"41\\", \\"isStrikeThrough\\": \\"true\\", \\"lineHeight\\": \\"1.3\\", \\"bold\\": \\"false\\", \\"type\\": \\"text\\", \\"content\\": \\"¥19.89\\", \\"marginLeft\\": \\"4\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"¥19.89\\"}, \\"arg1\\": \\"46_tag_r3_41\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"false\\"}}, \\"r1\\": {\\"tagList\\": [{\\"data\\": {\\"marginRight\\": \\"4\\", \\"labelId\\": \\"13\\", \\"width\\": \\"28\\", \\"type\\": \\"img\\", \\"alignment\\": \\"middle\\", \\"content\\": \\"freeShippingIcon\\", \\"url\\": \\"https://gw.alicdn.com/imgextra/i1/O1CN017BILHl1VNARooBnhe_!!6000000002640-2-tps-84-60.png\\", \\"height\\": \\"20\\"}, \\"utParams\\": {\\"args\\": {\\"LabelSystem2.0\\": \\"1\\", \\"content\\": \\"freeShippingIcon\\"}, \\"arg1\\": \\"46_tag_r1_13\\"}}], \\"config\\": {\\"mutualLabelBizGroup\\": \\"true\\"}}}, \\"serviceUtParams\\": \\"[{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r3_41\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"¥19.89\\\\\\"}},{\\\\\\"arg1\\\\\\":\\\\\\"46_tag_r1_13\\\\\\",\\\\\\"args\\\\\\":{\\\\\\"LabelSystem2.0\\\\\\":\\\\\\"1\\\\\\",\\\\\\"content\\\\\\":\\\\\\"freeShippingIcon\\\\\\"}}]\\", \\"trackParams\\": {\\"zhimaOffline\\": \\"false\\", \\"labelBucketId\\": \\"14\\", \\"oldZhima\\": \\"false\\", \\"zhimaLogBucketId\\": \\"14\\", \\"labId\\": \\"320\\"}, \\"unShowLabelUtParams\\": \\"{}\\"}, \\"card_type\\": 1003}", "category": "50023914", "description": ""}', '2026-06-13 15:21:17', NULL);


-- ----------------------------
-- 表结构: xy_chat_quick_phrases
-- ----------------------------
DROP TABLE IF EXISTS `xy_chat_quick_phrases`;
CREATE TABLE `xy_chat_quick_phrases` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `owner_id` bigint NOT NULL COMMENT 'å½’å±žç”¨æˆ·',
  `title` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŸ­è¯­æ ‡é¢˜',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŸ­è¯­å†…å®¹',
  `sort_order` int NOT NULL DEFAULT '0' COMMENT 'æŽ’åºå€¼',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `ix_xy_chat_quick_phrases_owner_id` (`owner_id`),
  KEY `idx_chat_quick_phrase_owner_sort` (`owner_id`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='åœ¨çº¿èŠå¤©å¿«æ·çŸ­è¯­';

-- 表数据: xy_chat_quick_phrases


-- ----------------------------
-- 表结构: xy_confirm_receipt_messages
-- ----------------------------
DROP TABLE IF EXISTS `xy_confirm_receipt_messages`;
CREATE TABLE `xy_confirm_receipt_messages` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `enabled` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦å¯ç”¨',
  `message_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'æ¶ˆæ¯æ–‡æœ¬å†…å®¹',
  `message_image` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ¶ˆæ¯å›¾ç‰‡URL',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç¡®è®¤æ”¶è´§æ¶ˆæ¯é…ç½®è¡¨';

-- 表数据: xy_confirm_receipt_messages


-- ----------------------------
-- 表结构: xy_cookie_refresh_schedules
-- ----------------------------
DROP TABLE IF EXISTS `xy_cookie_refresh_schedules`;
CREATE TABLE `xy_cookie_refresh_schedules` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `expire_at` datetime NOT NULL COMMENT 'å½“å‰Cookieç»­æœŸåˆ°æœŸæ—¶é—´',
  `last_refresh_at` datetime DEFAULT NULL COMMENT 'æœ€è¿‘ä¸€æ¬¡ç»­æœŸæˆåŠŸæ—¶é—´',
  `last_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æœ€è¿‘ä¸€æ¬¡çŠ¶æ€',
  `last_error_message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æœ€è¿‘ä¸€æ¬¡é”™è¯¯ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_account_id` (`account_id`),
  KEY `idx_expire_at` (`expire_at`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Cookieç»­æœŸè®¡åˆ’è¡¨';

-- 表数据: xy_cookie_refresh_schedules


-- ----------------------------
-- 表结构: xy_db_backup_log
-- ----------------------------
DROP TABLE IF EXISTS `xy_db_backup_log`;
CREATE TABLE `xy_db_backup_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŠ¶æ€',
  `file_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¤‡ä»½æ–‡ä»¶å',
  `file_path` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¤‡ä»½æ–‡ä»¶ç»å¯¹è·¯å¾„',
  `file_size` bigint DEFAULT NULL COMMENT 'å¤‡ä»½æ–‡ä»¶å¤§å°(å­—èŠ‚)',
  `table_count` int DEFAULT NULL COMMENT 'å¤‡ä»½çš„æ•°æ®è¡¨æ•°é‡',
  `total_rows` bigint DEFAULT NULL COMMENT 'å¤‡ä»½çš„æ•°æ®æ€»è¡Œæ•°',
  `duration_ms` int DEFAULT NULL COMMENT 'å¤‡ä»½è€—æ—¶(æ¯«ç§’)',
  `error_message` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æ•°æ®åº“å¤‡ä»½æ—¥å¿—è¡¨';

-- 表 xy_db_backup_log 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_default_replies
-- ----------------------------
DROP TABLE IF EXISTS `xy_default_replies`;
CREATE TABLE `xy_default_replies` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'å›žå¤ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·æ ‡è¯†',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“ID',
  `enabled` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦å¯ç”¨',
  `reply_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'text' COMMENT 'å›žå¤ç±»åž‹',
  `reply_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å›žå¤å†…å®¹',
  `reply_image` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å›žå¤å›¾ç‰‡URL',
  `api_url` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'APIåœ°å€',
  `api_timeout` int DEFAULT '80' COMMENT 'APIè¯·æ±‚è¶…æ—¶æ—¶é—´(ç§’)',
  `reply_once` tinyint(1) DEFAULT '0' COMMENT 'åªå›žå¤ä¸€æ¬¡',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_account_item` (`account_id`,`item_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_item_id` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='é»˜è®¤å›žå¤è¡¨';

-- 表数据: xy_default_replies


-- ----------------------------
-- 表结构: xy_default_reply_records
-- ----------------------------
DROP TABLE IF EXISTS `xy_default_reply_records`;
CREATE TABLE `xy_default_reply_records` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'è®°å½•ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·æ ‡è¯†',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“ID',
  `user_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è¢«å›žå¤ç”¨æˆ·ID',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_account_item_user` (`account_id`,`item_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='é»˜è®¤å›žå¤è®°å½•è¡¨';

-- 表数据: xy_default_reply_records


-- ----------------------------
-- 表结构: xy_delivery_block_rules
-- ----------------------------
DROP TABLE IF EXISTS `xy_delivery_block_rules`;
CREATE TABLE `xy_delivery_block_rules` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `account_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `rule_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è§„åˆ™ç¼–ç ',
  `enabled` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'è§„åˆ™å¼€å…³',
  `priority` int NOT NULL DEFAULT '0' COMMENT 'æ‰§è¡Œä¼˜å…ˆçº§',
  `block_reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ç¦æ­¢å‘è´§åŽŸå› ',
  `auto_close_order` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'å‘½ä¸­åŽä¸»åŠ¨å…³é—­è®¢å•',
  `only_card_after_close` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'å…³é—­è®¢å•åŽç»§ç»­å‘è´§(åªå‘å¡åˆ¸)',
  `excluded_item_ids` json DEFAULT NULL COMMENT 'æŽ’é™¤å•†å“åˆ—è¡¨',
  `config` json DEFAULT NULL COMMENT 'è§„åˆ™ä¸“å±žå‚æ•°',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_account_rule` (`account_id`,`rule_code`),
  KEY `idx_account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç¦æ­¢å‘è´§è§„åˆ™é…ç½®è¡¨';

-- 表数据: xy_delivery_block_rules


-- ----------------------------
-- 表结构: xy_dock_code_bindings
-- ----------------------------
DROP TABLE IF EXISTS `xy_dock_code_bindings`;
CREATE TABLE `xy_dock_code_bindings` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` bigint NOT NULL COMMENT 'ç»‘å®šç”¨æˆ·ID(åˆ†é”€å•†)',
  `dock_code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å¯¹æŽ¥ç ',
  `target_user_id` bigint NOT NULL COMMENT 'å¯¹æŽ¥ç æ‹¥æœ‰è€…ç”¨æˆ·ID(ä¾›åº”å•†)',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'ç»‘å®šæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_target` (`user_id`,`target_user_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_target_user_id` (`target_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å¯¹æŽ¥ç ç»‘å®šè¡¨';

-- 表数据: xy_dock_code_bindings


-- ----------------------------
-- 表结构: xy_dock_records
-- ----------------------------
DROP TABLE IF EXISTS `xy_dock_records`;
CREATE TABLE `xy_dock_records` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·ID',
  `card_id` bigint NOT NULL COMMENT 'æ¥æºå¡åˆ¸ID',
  `dock_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å¯¹æŽ¥åç§°',
  `markup_amount` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0.00' COMMENT 'åŠ ä»·é‡‘é¢',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å¤‡æ³¨',
  `delivery_count` int NOT NULL DEFAULT '0' COMMENT 'å‘è´§æ¬¡æ•°',
  `status` tinyint(1) DEFAULT '1' COMMENT 'å¯¹æŽ¥çŠ¶æ€ï¼š1å¯ç”¨ 0åœç”¨',
  `disable_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ç¦ç”¨åŽŸå› ',
  `level` int NOT NULL DEFAULT '1' COMMENT 'åˆ†é”€å±‚çº§ï¼š1=ä¸€çº§ï¼Œ2=äºŒçº§',
  `parent_dock_id` bigint DEFAULT NULL COMMENT 'ä¸Šçº§å¯¹æŽ¥è®°å½•ID',
  `source_user_id` bigint DEFAULT NULL COMMENT 'ä¸Šçº§åˆ†é”€å•†ç”¨æˆ·ID',
  `allow_sub_dock` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦å…è®¸ä¸‹çº§å¯¹æŽ¥',
  `sub_dock_price` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ç»™ä¸‹çº§çš„å¯¹æŽ¥ä»·æ ¼',
  `sub_dock_visibility` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¸‹çº§å¯¹æŽ¥å¯è§æ€§',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_card_id` (`card_id`),
  KEY `idx_parent_dock_id` (`parent_dock_id`),
  KEY `idx_dock_user_level` (`user_id`,`level`),
  KEY `idx_dock_source_level` (`source_user_id`,`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å¯¹æŽ¥è®°å½•è¡¨';

-- 表数据: xy_dock_records


-- ----------------------------
-- 表结构: xy_feedback_messages
-- ----------------------------
DROP TABLE IF EXISTS `xy_feedback_messages`;
CREATE TABLE `xy_feedback_messages` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'æ¶ˆæ¯ID',
  `feedback_id` bigint NOT NULL COMMENT 'å…³è”åé¦ˆID',
  `user_id` bigint NOT NULL COMMENT 'å‘é€è€…ç”¨æˆ·ID',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ¶ˆæ¯å†…å®¹',
  `is_admin` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦ä¸ºç®¡ç†å‘˜æ¶ˆæ¯',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_feedback_id` (`feedback_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æ„è§åé¦ˆæ¶ˆæ¯è¡¨';

-- 表数据: xy_feedback_messages


-- ----------------------------
-- 表结构: xy_feedbacks
-- ----------------------------
DROP TABLE IF EXISTS `xy_feedbacks`;
CREATE TABLE `xy_feedbacks` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'åé¦ˆID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·ID',
  `cookie_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å…³è”è´¦å·ID',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ ‡é¢˜',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å†…å®¹',
  `feedback_type` enum('FEATURE','BUG','OTHER') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'OTHER' COMMENT 'åé¦ˆç±»åž‹',
  `images` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å›¾ç‰‡URL(JSONæ•°ç»„)',
  `is_resolved` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦å·²è§£å†³',
  `resolved_at` datetime DEFAULT NULL COMMENT 'è§£å†³æ—¶é—´',
  `admin_reply` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'ç®¡ç†å‘˜å›žå¤',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_is_resolved` (`is_resolved`),
  KEY `idx_feedback_type` (`feedback_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æ„è§åé¦ˆè¡¨';

-- 表数据: xy_feedbacks


-- ----------------------------
-- 表结构: xy_fund_flows
-- ----------------------------
DROP TABLE IF EXISTS `xy_fund_flows`;
CREATE TABLE `xy_fund_flows` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·ID',
  `type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æµæ°´ç±»åž‹ï¼šincome/expense',
  `amount` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å‘ç”Ÿé¢',
  `balance_before` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å‘ç”Ÿå‰ä½™é¢',
  `balance_after` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å‘ç”ŸåŽä½™é¢',
  `order_id` bigint DEFAULT NULL COMMENT 'å…³è”è®¢å•ID',
  `dock_record_id` bigint DEFAULT NULL COMMENT 'å…³è”å¯¹æŽ¥è®°å½•ID',
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æµæ°´æè¿°',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'å‘ç”Ÿæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_dock_record_id` (`dock_record_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_ff_user_id_desc` (`user_id`,`id`),
  KEY `idx_ff_user_type_id_desc` (`user_id`,`type`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='èµ„é‡‘æµæ°´è¡¨';

-- 表数据: xy_fund_flows


-- ----------------------------
-- 表结构: xy_goofish_crawl_items
-- ----------------------------
DROP TABLE IF EXISTS `xy_goofish_crawl_items`;
CREATE TABLE `xy_goofish_crawl_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` bigint NOT NULL,
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `price` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seller_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `main_image` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `publish_time` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `want_count` int DEFAULT NULL,
  `view_count` int DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `detail_error` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `raw_json` json DEFAULT NULL,
  `fetched_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_job_item` (`job_id`,`item_id`),
  KEY `idx_job_id` (`job_id`),
  KEY `idx_fetched_at` (`fetched_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 表数据: xy_goofish_crawl_items


-- ----------------------------
-- 表结构: xy_goofish_crawl_jobs
-- ----------------------------
DROP TABLE IF EXISTS `xy_goofish_crawl_jobs`;
CREATE TABLE `xy_goofish_crawl_jobs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `owner_id` bigint NOT NULL,
  `cookie_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keyword` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `interval_seconds` int NOT NULL DEFAULT '900',
  `start_page` int NOT NULL DEFAULT '1',
  `pages` int NOT NULL DEFAULT '1',
  `page_size` int NOT NULL DEFAULT '20',
  `fetch_detail` tinyint(1) DEFAULT '1',
  `detail_limit` int NOT NULL DEFAULT '20',
  `enabled` tinyint(1) DEFAULT '1',
  `last_run_at` datetime DEFAULT NULL,
  `last_error` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_cookie_id` (`cookie_id`),
  KEY `idx_enabled` (`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 表数据: xy_goofish_crawl_jobs


-- ----------------------------
-- 表结构: xy_keyword_rules
-- ----------------------------
DROP TABLE IF EXISTS `xy_keyword_rules`;
CREATE TABLE `xy_keyword_rules` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'è§„åˆ™ID',
  `owner_id` bigint NOT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `account_id` bigint DEFAULT NULL COMMENT 'å…³è”è´¦å·ID',
  `keyword` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å…³é”®è¯',
  `reply_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å›žå¤å†…å®¹',
  `reply_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å›žå¤ç±»åž‹(text/image)',
  `image_url` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å›¾ç‰‡URL',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“ID',
  `priority` int DEFAULT '100' COMMENT 'ä¼˜å…ˆçº§',
  `is_active` tinyint(1) DEFAULT '1' COMMENT 'æ˜¯å¦å¯ç”¨',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_keyword` (`keyword`),
  KEY `idx_kw_account_item` (`account_id`,`item_id`),
  KEY `idx_kw_account_active` (`account_id`,`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å…³é”®è¯è§„åˆ™è¡¨';

-- 表数据: xy_keyword_rules


-- ----------------------------
-- 表结构: xy_message_filters
-- ----------------------------
DROP TABLE IF EXISTS `xy_message_filters`;
CREATE TABLE `xy_message_filters` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'è§„åˆ™ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·æ ‡è¯†',
  `keyword` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è¿‡æ»¤å…³é”®è¯',
  `filter_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è¿‡æ»¤ç±»åž‹',
  `enabled` tinyint(1) DEFAULT '1' COMMENT 'æ˜¯å¦å¯ç”¨',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_account_keyword_type` (`account_id`,`keyword`,`filter_type`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_keyword` (`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æ¶ˆæ¯è¿‡æ»¤è§„åˆ™è¡¨';

-- 表数据: xy_message_filters


-- ----------------------------
-- 表结构: xy_message_notifications
-- ----------------------------
DROP TABLE IF EXISTS `xy_message_notifications`;
CREATE TABLE `xy_message_notifications` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'é€šçŸ¥ID',
  `owner_id` bigint NOT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `account_pk` bigint NOT NULL COMMENT 'å…³è”è´¦å·ID',
  `account_identifier` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·æ ‡è¯†',
  `channel_id` bigint NOT NULL COMMENT 'æ¸ é“ID',
  `enabled` tinyint(1) DEFAULT '1' COMMENT 'æ˜¯å¦å¯ç”¨',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_account_pk` (`account_pk`),
  KEY `idx_channel_id` (`channel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æ¶ˆæ¯é€šçŸ¥è¡¨';

-- 表数据: xy_message_notifications


-- ----------------------------
-- 表结构: xy_notification_channels
-- ----------------------------
DROP TABLE IF EXISTS `xy_notification_channels`;
CREATE TABLE `xy_notification_channels` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'æ¸ é“ID',
  `owner_id` bigint NOT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ¸ é“åç§°',
  `channel_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ¸ é“ç±»åž‹',
  `config` json DEFAULT NULL COMMENT 'æ¸ é“é…ç½®',
  `enabled` tinyint(1) DEFAULT '1' COMMENT 'æ˜¯å¦å¯ç”¨',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_channel_type` (`channel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='é€šçŸ¥æ¸ é“è¡¨';

-- 表数据: xy_notification_channels


-- ----------------------------
-- 表结构: xy_orders
-- ----------------------------
DROP TABLE IF EXISTS `xy_orders`;
CREATE TABLE `xy_orders` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'è®¢å•ID',
  `owner_id` bigint NOT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `order_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•çŠ¶æ€',
  `buyer_nick` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¹°å®¶æ˜µç§°',
  `buyer_fish_nick` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¹°å®¶é—²é±¼æ˜µç§°',
  `buyer_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¹°å®¶ID',
  `chat_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'èŠå¤©ä¼šè¯ID',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“ID',
  `spec_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è§„æ ¼åç§°',
  `spec_value` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è§„æ ¼å€¼',
  `quantity` int DEFAULT '1' COMMENT 'æ•°é‡',
  `amount` decimal(12,2) DEFAULT NULL COMMENT 'é‡‘é¢',
  `currency` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'CNY' COMMENT 'è´§å¸',
  `account_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è´¦å·æ ‡è¯†',
  `account_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è´¦å·åç§°',
  `is_bargain` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦å°åˆ€',
  `receiver_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§äººå§“å',
  `receiver_phone` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§äººæ‰‹æœºå·',
  `receiver_address` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§åœ°å€',
  `is_rated` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦å·²è¯„ä»·',
  `is_red_flower` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦å·²æ±‚å°çº¢èŠ±',
  `delivery_method` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å‘è´§æ–¹å¼',
  `delivery_content` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å‘è´§å†…å®¹',
  `delivery_fail_reason` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å‘è´§å¤±è´¥åŽŸå› ',
  `item_snapshot` json DEFAULT NULL COMMENT 'å•†å“å¿«ç…§',
  `metadata` json DEFAULT NULL COMMENT 'å…ƒæ•°æ®',
  `source` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ•°æ®æ¥æº',
  `placed_at` datetime DEFAULT NULL COMMENT 'ä¸‹å•æ—¶é—´',
  `synced_at` datetime DEFAULT NULL COMMENT 'åŒæ­¥æ—¶é—´',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_account_no` (`account_id`,`order_no`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_order_created_at` (`created_at`),
  KEY `idx_order_placed_status` (`placed_at`,`status`),
  KEY `idx_order_created_status` (`created_at`,`status`),
  KEY `idx_order_owner_placed` (`owner_id`,`placed_at`),
  KEY `idx_order_owner_created` (`owner_id`,`created_at`),
  KEY `idx_order_owner_account_placed` (`owner_id`,`account_id`,`placed_at`),
  KEY `idx_order_owner_account_buyer_created` (`owner_id`,`account_id`,`buyer_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•è¡¨';

-- 表数据: xy_orders
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (1, 2, '5119898544739011110', 'shipped', '库库巴哈', NULL, '2220132772867', NULL, '1050068076391', NULL, NULL, 1, '5.60', 'CNY', '783149128', NULL, 0, '', '', '', 0, 0, NULL, NULL, NULL, NULL, NULL, 'fetch_xianyu', '2026-06-12 12:43:08', NULL, '2026-06-12 13:37:59', '2026-06-12 13:37:59');
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (2, 2, '5119412619104009431', 'shipped', '不吃香菜啊', NULL, '2214293904314', NULL, '1050068076391', NULL, NULL, 1, '5.60', 'CNY', '783149128', NULL, 0, '', '', '', 0, 0, NULL, NULL, NULL, NULL, NULL, 'fetch_xianyu', '2026-06-11 17:12:34', NULL, '2026-06-12 13:37:59', '2026-06-12 13:37:59');
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (3, 2, '5119441777843007728', 'shipped', 'x***7', NULL, '2220051822077', NULL, '1050068076391', NULL, NULL, 1, '4.89', 'CNY', '783149128', NULL, 0, '', '', '', 0, 0, NULL, NULL, NULL, NULL, NULL, 'fetch_xianyu', '2026-06-08 16:05:08', NULL, '2026-06-12 13:37:59', '2026-06-12 13:37:59');
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (4, 2, '3305935094439017188', 'shipped', 'x***5', NULL, '2218234895415', NULL, '1050068076391', NULL, NULL, 1, '5.60', 'CNY', '783149128', NULL, 0, '', '', '', 0, 0, NULL, NULL, NULL, NULL, NULL, 'fetch_xianyu', '2026-06-04 11:11:49', NULL, '2026-06-12 13:37:59', '2026-06-12 13:37:59');
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (5, 2, '3305888655393005471', 'completed', '雾都下棋的可乐', NULL, '2206669695282', NULL, '1048216690627', NULL, NULL, 1, '4.00', 'CNY', '783149128', NULL, 0, '', '', '', 1, 0, NULL, NULL, NULL, NULL, NULL, 'fetch_xianyu', '2026-06-04 08:19:32', NULL, '2026-06-12 13:37:59', '2026-06-12 13:37:59');
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (6, 2, '3306349021627016088', 'completed', '亦木1234', NULL, '2218350436652', NULL, '1050068076391', NULL, NULL, 1, '7.00', 'CNY', '783149128', NULL, 0, '', '', '', 1, 0, NULL, NULL, NULL, NULL, NULL, 'fetch_xianyu', '2026-06-03 23:36:23', NULL, '2026-06-12 13:38:00', '2026-06-12 13:38:00');
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (7, 2, '3305475624316019256', 'cancelled', '有你才完美2021', NULL, '318195916', NULL, '1052356021803', NULL, NULL, 1, '0.80', 'CNY', '783149128', NULL, 0, '', '', '', 0, 0, NULL, NULL, NULL, NULL, NULL, 'fetch_xianyu', '2026-05-29 01:50:06', NULL, '2026-06-12 13:38:00', '2026-06-12 13:38:00');
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (8, 2, '5118153338759027344', 'cancelled', '布;衣', NULL, '722352153', NULL, '1052356021803', NULL, NULL, 1, '0.80', 'CNY', '783149128', NULL, 0, '', '', '', 0, 0, NULL, NULL, NULL, NULL, NULL, 'fetch_xianyu', '2026-05-28 23:43:40', NULL, '2026-06-12 13:38:00', '2026-06-12 13:38:00');
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (9, 2, '5118371065510147943', 'completed', '青莲巷搓澡的蓝足海鸟', NULL, '23431099', NULL, '1052356021803', NULL, NULL, 1, '0.80', 'CNY', '783149128', NULL, 0, '', '', '', 0, 0, NULL, NULL, NULL, NULL, NULL, 'fetch_xianyu', '2026-05-28 23:12:54', NULL, '2026-06-12 13:38:00', '2026-06-12 13:38:00');
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (10, 2, '5118359617603084927', 'completed', '勇者弗兰克功业', NULL, '1859353085', NULL, '1052356021803', NULL, NULL, 1, '0.80', 'CNY', '783149128', NULL, 0, '', '', '', 0, 0, NULL, NULL, NULL, NULL, NULL, 'fetch_xianyu', '2026-05-28 20:44:22', NULL, '2026-06-12 13:38:00', '2026-06-12 13:38:00');
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (11, 2, '3304322148948027393', 'completed', '刘***爸', NULL, '2485258749', NULL, '1052356021803', NULL, NULL, 1, '1.00', 'CNY', '783149128', NULL, 0, '', '', '', 1, 0, NULL, NULL, NULL, NULL, NULL, 'fetch_xianyu', '2026-05-25 13:57:01', NULL, '2026-06-12 13:38:00', '2026-06-12 13:38:00');
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (12, 2, '5116612431293024034', 'completed', '用户_27063460', NULL, '3389940944', NULL, '1048216690627', NULL, NULL, 1, '3.82', 'CNY', '783149128', NULL, 0, '', '', '', 1, 0, NULL, NULL, NULL, NULL, NULL, 'fetch_xianyu', '2026-05-22 09:08:19', NULL, '2026-06-12 13:38:00', '2026-06-12 13:38:00');
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (13, 2, '3302648832567008771', 'completed', 'x***4', NULL, '2220985637971', NULL, '1050068076391', NULL, NULL, 1, '5.60', 'CNY', '783149128', NULL, 0, '', '', '', 1, 0, NULL, NULL, NULL, NULL, NULL, 'fetch_xianyu', '2026-05-17 14:36:38', NULL, '2026-06-12 13:38:00', '2026-06-12 13:38:00');
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (14, 2, '3302367925779002378', 'completed', '爱吃煎酿三宝的泡面烛天', NULL, '2939589455', NULL, '1048216690627', NULL, NULL, 1, '4.00', 'CNY', '783149128', NULL, 0, '', '', '', 1, 0, NULL, NULL, NULL, NULL, NULL, 'fetch_xianyu', '2026-05-16 15:31:23', NULL, '2026-06-12 13:38:00', '2026-06-12 13:38:00');
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (15, 2, '3301530566627122070', 'completed', '长樱路高级的海产红藻', NULL, '2221611389164', NULL, '1048216690627', NULL, NULL, 1, '4.00', 'CNY', '783149128', NULL, 0, '', '', '', 0, 0, NULL, NULL, NULL, NULL, NULL, 'fetch_xianyu', '2026-05-14 17:22:02', NULL, '2026-06-12 13:38:00', '2026-06-12 13:38:00');
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (16, 2, '3301971457510021687', 'cancelled', '长樱路高级的海产红藻', NULL, '2221611389164', NULL, '1048216690627', NULL, NULL, 1, '4.00', 'CNY', '783149128', NULL, 0, '', '', '', 0, 0, NULL, NULL, NULL, NULL, NULL, 'fetch_xianyu', '2026-05-14 15:48:17', NULL, '2026-06-12 13:38:00', '2026-06-12 13:38:00');
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (17, 2, '5115449918333021144', 'cancelled', 'tbNick_y0mrt', NULL, '4169261979', NULL, '1048216690627', NULL, NULL, 1, '1.87', 'CNY', '783149128', NULL, 0, '', '', '', 0, 0, NULL, NULL, NULL, NULL, NULL, 'fetch_xianyu', '2026-05-12 20:20:44', NULL, '2026-06-12 13:38:00', '2026-06-12 13:38:00');
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (18, 2, '5115234891718027239', 'completed', 'tbNick_or8c5', NULL, '3124761252', NULL, '1050068076391', NULL, NULL, 1, '5.60', 'CNY', '783149128', NULL, 0, '', '', '', 0, 0, NULL, NULL, NULL, NULL, NULL, 'fetch_xianyu', '2026-05-12 17:33:11', NULL, '2026-06-12 13:38:00', '2026-06-12 13:38:00');
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (19, 2, '3301731228459029988', 'completed', '我不是人才', NULL, '4293995555', NULL, '1050068076391', NULL, NULL, 1, '5.60', 'CNY', '783149128', NULL, 0, '', '', '', 1, 0, NULL, NULL, NULL, NULL, NULL, 'fetch_xianyu', '2026-05-12 16:50:54', NULL, '2026-06-12 13:38:00', '2026-06-12 13:38:00');
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (20, 2, '5115006290057026333', 'completed', '比格星好动的神仙鱼', NULL, '2215439834371', NULL, '1050068076391', NULL, NULL, 1, '7.00', 'CNY', '783149128', NULL, 0, '', '', '', 1, 0, NULL, NULL, NULL, NULL, NULL, 'fetch_xianyu', '2026-05-08 22:39:52', NULL, '2026-06-12 13:38:00', '2026-06-12 13:38:00');
INSERT INTO `xy_orders` (`id`, `owner_id`, `order_no`, `status`, `buyer_nick`, `buyer_fish_nick`, `buyer_id`, `chat_id`, `item_id`, `spec_name`, `spec_value`, `quantity`, `amount`, `currency`, `account_id`, `account_name`, `is_bargain`, `receiver_name`, `receiver_phone`, `receiver_address`, `is_rated`, `is_red_flower`, `delivery_method`, `delivery_content`, `delivery_fail_reason`, `item_snapshot`, `metadata`, `source`, `placed_at`, `synced_at`, `created_at`, `updated_at`) VALUES (21, 2, '5120010432693017547', 'shipped', '西琳柚', '西琳柚', '1014293303', '62368359322', '1059707364746', NULL, NULL, 1, '1.00', 'CNY', '783149128', NULL, 0, '小蝌蚪找妈妈', '18217201064', '上海上海市黄浦区五里桥街道上海市黄浦区 瑞金南路341号 溪颜门诊部', 0, 0, 'scheduled', '我用夸克网盘给你分享了「2023 广州国际车展」，点击链接或复制整段内容，打开「夸克APP」即可获取。\n/~f5df3Z1cx1~:/\n链接：https://pan.quark.cn/s/5219bc54049e?pwd=TnJU\n提取码：TnJU', NULL, NULL, NULL, 'fetch_xianyu', '2026-06-13 16:25:17', NULL, '2026-06-13 09:44:12', '2026-06-13 09:48:35');


-- ----------------------------
-- 表结构: xy_personal_blacklist
-- ----------------------------
DROP TABLE IF EXISTS `xy_personal_blacklist`;
CREATE TABLE `xy_personal_blacklist` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `owner_id` bigint NOT NULL COMMENT 'ç”¨æˆ·ID',
  `account_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è´¦å·ID',
  `buyer_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ä¹°å®¶ID',
  `buyer_nick` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¹°å®¶æ˜µç§°',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“ID',
  `reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‹‰é»‘åŽŸå› ',
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'æ˜¯å¦å¯ç”¨',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_pb_owner_id` (`owner_id`),
  KEY `idx_pb_owner_buyer` (`owner_id`,`buyer_id`),
  KEY `idx_pb_owner_account` (`owner_id`,`account_id`),
  KEY `idx_pb_owner_created` (`owner_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ä¸ªäººé»‘åå•è¡¨';

-- 表数据: xy_personal_blacklist


-- ----------------------------
-- 表结构: xy_platform_blacklist
-- ----------------------------
DROP TABLE IF EXISTS `xy_platform_blacklist`;
CREATE TABLE `xy_platform_blacklist` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `owner_id` bigint NOT NULL COMMENT 'æ‹‰é»‘ç”¨æˆ·(æœ¬ç³»ç»Ÿç”¨æˆ·ID)',
  `buyer_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ä¹°å®¶ID',
  `buyer_nick` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ä¹°å®¶æ˜µç§°',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_plb_owner_id` (`owner_id`),
  KEY `idx_plb_owner_buyer` (`owner_id`,`buyer_id`),
  KEY `idx_plb_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='é—²é±¼é»‘åå•è¡¨';

-- 表数据: xy_platform_blacklist


-- ----------------------------
-- 表结构: xy_product_materials
-- ----------------------------
DROP TABLE IF EXISTS `xy_product_materials`;
CREATE TABLE `xy_product_materials` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` bigint NOT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å•†å“æ ‡é¢˜',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å•†å“æè¿°',
  `price` decimal(12,2) NOT NULL COMMENT 'ä»·æ ¼',
  `original_price` decimal(12,2) DEFAULT NULL COMMENT 'åŽŸä»·(åˆ’çº¿ä»·)',
  `category` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å•†å“åˆ†ç±»',
  `images` json DEFAULT NULL COMMENT 'å›¾ç‰‡URLåˆ—è¡¨(æœ€å¤š9å¼ )',
  `delivery_method` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'express' COMMENT 'å‘è´§æ–¹å¼',
  `postage` decimal(8,2) DEFAULT '0.00' COMMENT 'é‚®è´¹',
  `address` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å®è´æ‰€åœ¨åœ°',
  `brand` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å“ç‰Œ',
  `condition` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'å…¨æ–°' COMMENT 'æˆè‰²',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¤‡æ³¨',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_pm_user_created` (`user_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å•†å“ç´ æåº“è¡¨';

-- 表数据: xy_product_materials
INSERT INTO `xy_product_materials` (`id`, `user_id`, `title`, `description`, `price`, `original_price`, `category`, `images`, `delivery_method`, `postage`, `address`, `brand`, `condition`, `remark`, `created_at`, `updated_at`) VALUES (1, 2, '2023广州国际车展4K高清合集 【2023广州车展盛宴】 全4K超清画质 2023广州国际车展4K高清合集 【2023广州车展盛宴】 全4K超清画质，臻藏版呈现 包含特写高清视频文件602部 总容量高达201GB 自动发货，仅支持度盘下载 独家手录素材，同行敬请止步 限时特惠，不容错过！', '2023广州国际车展4K高清合集 【2023广州车展盛宴】 全4K超清画质 2023广州国际车展4K高清合集 【2023广州车展盛宴】 全4K超清画质，臻藏版呈现 包含特写高清视频文件602部 总容量高达201GB 自动发货，仅支持度盘下载 独家手录素材，同行敬请止步 限时特惠，不容错过！', '7.13', NULL, NULL, '["http://img.alicdn.com/bao/uploaded/i3/O1CN01ZLy59P2ILicobqJ3O_!!4611686018427386950-0-fleamarket.jpg"]', 'express', '0.00', '广东', NULL, '全新', '采集导入 | item_id=982738418439', '2026-06-12 15:56:49', '2026-06-12 15:56:49');


-- ----------------------------
-- 表结构: xy_publish_addresses
-- ----------------------------
DROP TABLE IF EXISTS `xy_publish_addresses`;
CREATE TABLE `xy_publish_addresses` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'åœ°å€åç§°',
  `search_keyword` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'åœ°å€æœç´¢å…³é”®è¯',
  `expected_text` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æœŸæœ›å‘½ä¸­çš„å€™é€‰æ–‡æœ¬',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é™å®šä½¿ç”¨çš„é—²é±¼è´¦å·ID',
  `weight` int NOT NULL DEFAULT '1' COMMENT 'éšæœºæƒé‡',
  `sort_order` int NOT NULL DEFAULT '100' COMMENT 'æŽ’åºå€¼',
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'æ˜¯å¦å¯ç”¨',
  `use_count` int NOT NULL DEFAULT '0' COMMENT 'ä½¿ç”¨æ¬¡æ•°',
  `last_used_at` datetime DEFAULT NULL COMMENT 'æœ€åŽä½¿ç”¨æ—¶é—´',
  `created_by` bigint DEFAULT NULL COMMENT 'åˆ›å»ºäººç”¨æˆ·ID',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¤‡æ³¨',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_pa_enabled_account` (`is_enabled`,`account_id`),
  KEY `idx_pa_sort_created` (`sort_order`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=312 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å•†å“å‘å¸ƒéšæœºåœ°å€æ± è¡¨';

-- 表数据: xy_publish_addresses
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (156, '北京市朝阳区', '北京市朝阳区', NULL, NULL, 1, 1, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (157, '北京市海淀区', '北京市海淀区', NULL, NULL, 1, 2, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (158, '北京市丰台区', '北京市丰台区', NULL, NULL, 1, 3, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (159, '北京市通州区', '北京市通州区', NULL, NULL, 1, 4, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (160, '北京市大兴区', '北京市大兴区', NULL, NULL, 1, 5, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (161, '天津市和平区', '天津市和平区', NULL, NULL, 1, 6, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (162, '天津市河西区', '天津市河西区', NULL, NULL, 1, 7, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (163, '天津市南开区', '天津市南开区', NULL, NULL, 1, 8, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (164, '天津市西青区', '天津市西青区', NULL, NULL, 1, 9, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (165, '天津市滨海新区', '天津市滨海新区', NULL, NULL, 1, 10, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (166, '河北省石家庄市长安区', '河北省石家庄市长安区', NULL, NULL, 1, 11, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (167, '河北省唐山市路北区', '河北省唐山市路北区', NULL, NULL, 1, 12, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (168, '河北省保定市莲池区', '河北省保定市莲池区', NULL, NULL, 1, 13, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (169, '河北省廊坊市广阳区', '河北省廊坊市广阳区', NULL, NULL, 1, 14, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (170, '河北省沧州市运河区', '河北省沧州市运河区', NULL, NULL, 1, 15, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (171, '山西省太原市小店区', '山西省太原市小店区', NULL, NULL, 1, 16, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (172, '山西省大同市平城区', '山西省大同市平城区', NULL, NULL, 1, 17, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (173, '山西省晋中市榆次区', '山西省晋中市榆次区', NULL, NULL, 1, 18, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (174, '山西省运城市盐湖区', '山西省运城市盐湖区', NULL, NULL, 1, 19, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (175, '山西省临汾市尧都区', '山西省临汾市尧都区', NULL, NULL, 1, 20, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (176, '内蒙古自治区呼和浩特市赛罕区', '内蒙古自治区呼和浩特市赛罕区', NULL, NULL, 1, 21, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (177, '内蒙古自治区包头市昆都仑区', '内蒙古自治区包头市昆都仑区', NULL, NULL, 1, 22, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (178, '内蒙古自治区鄂尔多斯市东胜区', '内蒙古自治区鄂尔多斯市东胜区', NULL, NULL, 1, 23, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (179, '内蒙古自治区赤峰市红山区', '内蒙古自治区赤峰市红山区', NULL, NULL, 1, 24, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (180, '内蒙古自治区呼伦贝尔市海拉尔区', '内蒙古自治区呼伦贝尔市海拉尔区', NULL, NULL, 1, 25, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (181, '辽宁省沈阳市和平区', '辽宁省沈阳市和平区', NULL, NULL, 1, 26, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (182, '辽宁省大连市中山区', '辽宁省大连市中山区', NULL, NULL, 1, 27, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (183, '辽宁省鞍山市铁东区', '辽宁省鞍山市铁东区', NULL, NULL, 1, 28, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (184, '辽宁省锦州市太和区', '辽宁省锦州市太和区', NULL, NULL, 1, 29, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (185, '辽宁省营口市站前区', '辽宁省营口市站前区', NULL, NULL, 1, 30, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (186, '吉林省长春市南关区', '吉林省长春市南关区', NULL, NULL, 1, 31, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (187, '吉林省吉林市船营区', '吉林省吉林市船营区', NULL, NULL, 1, 32, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (188, '吉林省四平市铁西区', '吉林省四平市铁西区', NULL, NULL, 1, 33, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (189, '吉林省延边州延吉市', '吉林省延边州延吉市', NULL, NULL, 1, 34, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (190, '吉林省通化市东昌区', '吉林省通化市东昌区', NULL, NULL, 1, 35, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (191, '黑龙江省哈尔滨市南岗区', '黑龙江省哈尔滨市南岗区', NULL, NULL, 1, 36, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (192, '黑龙江省齐齐哈尔市龙沙区', '黑龙江省齐齐哈尔市龙沙区', NULL, NULL, 1, 37, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (193, '黑龙江省牡丹江市东安区', '黑龙江省牡丹江市东安区', NULL, NULL, 1, 38, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (194, '黑龙江省大庆市萨尔图区', '黑龙江省大庆市萨尔图区', NULL, NULL, 1, 39, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (195, '黑龙江省佳木斯市向阳区', '黑龙江省佳木斯市向阳区', NULL, NULL, 1, 40, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (196, '上海市浦东新区', '上海市浦东新区', NULL, NULL, 1, 41, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (197, '上海市闵行区', '上海市闵行区', NULL, NULL, 1, 42, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (198, '上海市徐汇区', '上海市徐汇区', NULL, NULL, 1, 43, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (199, '上海市宝山区', '上海市宝山区', NULL, NULL, 1, 44, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (200, '上海市松江区', '上海市松江区', NULL, NULL, 1, 45, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (201, '江苏省南京市建邺区', '江苏省南京市建邺区', NULL, NULL, 1, 46, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (202, '江苏省苏州市工业园区', '江苏省苏州市工业园区', NULL, NULL, 1, 47, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (203, '江苏省无锡市滨湖区', '江苏省无锡市滨湖区', NULL, NULL, 1, 48, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (204, '江苏省徐州市云龙区', '江苏省徐州市云龙区', NULL, NULL, 1, 49, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (205, '江苏省南通市崇川区', '江苏省南通市崇川区', NULL, NULL, 1, 50, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (206, '浙江省杭州市西湖区', '浙江省杭州市西湖区', NULL, NULL, 1, 51, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (207, '浙江省宁波市鄞州区', '浙江省宁波市鄞州区', NULL, NULL, 1, 52, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (208, '浙江省温州市鹿城区', '浙江省温州市鹿城区', NULL, NULL, 1, 53, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (209, '浙江省嘉兴市南湖区', '浙江省嘉兴市南湖区', NULL, NULL, 1, 54, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (210, '浙江省金华市义乌市', '浙江省金华市义乌市', NULL, NULL, 1, 55, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (211, '安徽省合肥市蜀山区', '安徽省合肥市蜀山区', NULL, NULL, 1, 56, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (212, '安徽省芜湖市镜湖区', '安徽省芜湖市镜湖区', NULL, NULL, 1, 57, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (213, '安徽省蚌埠市蚌山区', '安徽省蚌埠市蚌山区', NULL, NULL, 1, 58, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (214, '安徽省阜阳市颍州区', '安徽省阜阳市颍州区', NULL, NULL, 1, 59, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (215, '安徽省安庆市迎江区', '安徽省安庆市迎江区', NULL, NULL, 1, 60, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (216, '福建省福州市鼓楼区', '福建省福州市鼓楼区', NULL, NULL, 1, 61, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (217, '福建省厦门市思明区', '福建省厦门市思明区', NULL, NULL, 1, 62, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (218, '福建省泉州市丰泽区', '福建省泉州市丰泽区', NULL, NULL, 1, 63, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (219, '福建省漳州市芗城区', '福建省漳州市芗城区', NULL, NULL, 1, 64, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (220, '福建省莆田市城厢区', '福建省莆田市城厢区', NULL, NULL, 1, 65, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (221, '江西省南昌市红谷滩区', '江西省南昌市红谷滩区', NULL, NULL, 1, 66, 0, 1, '2026-06-13 23:05:45', NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:09:59');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (222, '江西省赣州市章贡区', '江西省赣州市章贡区', NULL, NULL, 1, 67, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (223, '江西省九江市濂溪区', '江西省九江市濂溪区', NULL, NULL, 1, 68, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (224, '江西省上饶市信州区', '江西省上饶市信州区', NULL, NULL, 1, 69, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (225, '江西省宜春市袁州区', '江西省宜春市袁州区', NULL, NULL, 1, 70, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (226, '山东省济南市历下区', '山东省济南市历下区', NULL, NULL, 1, 71, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (227, '山东省青岛市市南区', '山东省青岛市市南区', NULL, NULL, 1, 72, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (228, '山东省烟台市芝罘区', '山东省烟台市芝罘区', NULL, NULL, 1, 73, 0, 1, '2026-06-12 23:48:11', NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:09:59');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (229, '山东省潍坊市奎文区', '山东省潍坊市奎文区', NULL, NULL, 1, 74, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (230, '山东省临沂市兰山区', '山东省临沂市兰山区', NULL, NULL, 1, 75, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (231, '河南省郑州市金水区', '河南省郑州市金水区', NULL, NULL, 1, 76, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (232, '河南省洛阳市洛龙区', '河南省洛阳市洛龙区', NULL, NULL, 1, 77, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (233, '河南省南阳市宛城区', '河南省南阳市宛城区', NULL, NULL, 1, 78, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (234, '河南省新乡市红旗区', '河南省新乡市红旗区', NULL, NULL, 1, 79, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (235, '河南省商丘市睢阳区', '河南省商丘市睢阳区', NULL, NULL, 1, 80, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (236, '湖北省武汉市武昌区', '湖北省武汉市武昌区', NULL, NULL, 1, 81, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (237, '湖北省宜昌市西陵区', '湖北省宜昌市西陵区', NULL, NULL, 1, 82, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (238, '湖北省襄阳市樊城区', '湖北省襄阳市樊城区', NULL, NULL, 1, 83, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (239, '湖北省荆州市沙市区', '湖北省荆州市沙市区', NULL, NULL, 1, 84, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (240, '湖北省黄石市黄石港区', '湖北省黄石市黄石港区', NULL, NULL, 1, 85, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (241, '湖南省长沙市岳麓区', '湖南省长沙市岳麓区', NULL, NULL, 1, 86, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (242, '湖南省株洲市天元区', '湖南省株洲市天元区', NULL, NULL, 1, 87, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (243, '湖南省湘潭市岳塘区', '湖南省湘潭市岳塘区', NULL, NULL, 1, 88, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (244, '湖南省岳阳市岳阳楼区', '湖南省岳阳市岳阳楼区', NULL, NULL, 1, 89, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (245, '湖南省常德市武陵区', '湖南省常德市武陵区', NULL, NULL, 1, 90, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (246, '广东省广州市天河区', '广东省广州市天河区', NULL, NULL, 1, 91, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (247, '广东省深圳市南山区', '广东省深圳市南山区', NULL, NULL, 1, 92, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (248, '广东省佛山市南海区', '广东省佛山市南海区', NULL, NULL, 1, 93, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (249, '广东省东莞市南城街道', '广东省东莞市南城街道', NULL, NULL, 1, 94, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (250, '广东省珠海市香洲区', '广东省珠海市香洲区', NULL, NULL, 1, 95, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (251, '广西壮族自治区南宁市青秀区', '广西壮族自治区南宁市青秀区', NULL, NULL, 1, 96, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (252, '广西壮族自治区柳州市城中区', '广西壮族自治区柳州市城中区', NULL, NULL, 1, 97, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:17');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (253, '广西壮族自治区桂林市秀峰区', '广西壮族自治区桂林市秀峰区', NULL, NULL, 1, 98, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:08');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (254, '广西壮族自治区北海市海城区', '广西壮族自治区北海市海城区', NULL, NULL, 1, 99, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:08');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (255, '广西壮族自治区玉林市玉州区', '广西壮族自治区玉林市玉州区', NULL, NULL, 1, 100, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:08');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (256, '海南省海口市龙华区', '海南省海口市龙华区', NULL, NULL, 1, 101, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:08');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (257, '海南省三亚市吉阳区', '海南省三亚市吉阳区', NULL, NULL, 1, 102, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:08');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (258, '海南省儋州市那大镇', '海南省儋州市那大镇', NULL, NULL, 1, 103, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:08');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (259, '海南省琼海市嘉积镇', '海南省琼海市嘉积镇', NULL, NULL, 1, 104, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:08');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (260, '海南省文昌市文城镇', '海南省文昌市文城镇', NULL, NULL, 1, 105, 0, 1, '2026-06-14 00:09:15', NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:09:59');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (261, '重庆市渝中区', '重庆市渝中区', NULL, NULL, 1, 106, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:08');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (262, '重庆市江北区', '重庆市江北区', NULL, NULL, 1, 107, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:08');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (263, '重庆市南岸区', '重庆市南岸区', NULL, NULL, 1, 108, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:08');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (264, '重庆市渝北区', '重庆市渝北区', NULL, NULL, 1, 109, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:08');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (265, '重庆市九龙坡区', '重庆市九龙坡区', NULL, NULL, 1, 110, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:08');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (266, '四川省成都市武侯区', '四川省成都市武侯区', NULL, NULL, 1, 111, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:08');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (267, '四川省绵阳市涪城区', '四川省绵阳市涪城区', NULL, NULL, 1, 112, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:08');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (268, '四川省德阳市旌阳区', '四川省德阳市旌阳区', NULL, NULL, 1, 113, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:08');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (269, '四川省乐山市市中区', '四川省乐山市市中区', NULL, NULL, 1, 114, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:08');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (270, '四川省南充市顺庆区', '四川省南充市顺庆区', NULL, NULL, 1, 115, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:08');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (271, '贵州省贵阳市观山湖区', '贵州省贵阳市观山湖区', NULL, NULL, 1, 116, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:08');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (272, '贵州省遵义市汇川区', '贵州省遵义市汇川区', NULL, NULL, 1, 117, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:08');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (273, '贵州省六盘水市钟山区', '贵州省六盘水市钟山区', NULL, NULL, 1, 118, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:08');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (274, '贵州省毕节市七星关区', '贵州省毕节市七星关区', NULL, NULL, 1, 119, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (275, '贵州省安顺市西秀区', '贵州省安顺市西秀区', NULL, NULL, 1, 120, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (276, '云南省昆明市五华区', '云南省昆明市五华区', NULL, NULL, 1, 121, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (277, '云南省曲靖市麒麟区', '云南省曲靖市麒麟区', NULL, NULL, 1, 122, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (278, '云南省玉溪市红塔区', '云南省玉溪市红塔区', NULL, NULL, 1, 123, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (279, '云南省大理州大理市', '云南省大理州大理市', NULL, NULL, 1, 124, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (280, '云南省西双版纳州景洪市', '云南省西双版纳州景洪市', NULL, NULL, 1, 125, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (281, '西藏自治区拉萨市城关区', '西藏自治区拉萨市城关区', NULL, NULL, 1, 126, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (282, '西藏自治区日喀则市桑珠孜区', '西藏自治区日喀则市桑珠孜区', NULL, NULL, 1, 127, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (283, '西藏自治区林芝市巴宜区', '西藏自治区林芝市巴宜区', NULL, NULL, 1, 128, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (284, '西藏自治区昌都市卡若区', '西藏自治区昌都市卡若区', NULL, NULL, 1, 129, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (285, '西藏自治区山南市乃东区', '西藏自治区山南市乃东区', NULL, NULL, 1, 130, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (286, '陕西省西安市雁塔区', '陕西省西安市雁塔区', NULL, NULL, 1, 131, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (287, '陕西省咸阳市秦都区', '陕西省咸阳市秦都区', NULL, NULL, 1, 132, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (288, '陕西省宝鸡市金台区', '陕西省宝鸡市金台区', NULL, NULL, 1, 133, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (289, '陕西省榆林市榆阳区', '陕西省榆林市榆阳区', NULL, NULL, 1, 134, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (290, '陕西省渭南市临渭区', '陕西省渭南市临渭区', NULL, NULL, 1, 135, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (291, '甘肃省兰州市城关区', '甘肃省兰州市城关区', NULL, NULL, 1, 136, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (292, '甘肃省天水市秦州区', '甘肃省天水市秦州区', NULL, NULL, 1, 137, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (293, '甘肃省酒泉市肃州区', '甘肃省酒泉市肃州区', NULL, NULL, 1, 138, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:10:03');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (294, '甘肃省庆阳市西峰区', '甘肃省庆阳市西峰区', NULL, NULL, 1, 139, 0, 1, '2026-06-14 00:02:56', NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:09:59');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (295, '甘肃省张掖市甘州区', '甘肃省张掖市甘州区', NULL, NULL, 1, 140, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:09:59');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (296, '青海省西宁市城西区', '青海省西宁市城西区', NULL, NULL, 1, 141, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:09:59');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (297, '青海省海东市乐都区', '青海省海东市乐都区', NULL, NULL, 1, 142, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:09:59');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (298, '青海省海西州格尔木市', '青海省海西州格尔木市', NULL, NULL, 1, 143, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:09:59');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (299, '青海省海南州共和县', '青海省海南州共和县', NULL, NULL, 1, 144, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:09:59');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (300, '青海省玉树州玉树市', '青海省玉树州玉树市', NULL, NULL, 1, 145, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:09:59');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (301, '宁夏回族自治区银川市金凤区', '宁夏回族自治区银川市金凤区', NULL, NULL, 1, 146, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:09:59');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (302, '宁夏回族自治区石嘴山市大武口区', '宁夏回族自治区石嘴山市大武口区', NULL, NULL, 1, 147, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:09:59');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (303, '宁夏回族自治区吴忠市利通区', '宁夏回族自治区吴忠市利通区', NULL, NULL, 1, 148, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:09:59');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (304, '宁夏回族自治区固原市原州区', '宁夏回族自治区固原市原州区', NULL, NULL, 1, 149, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:09:59');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (305, '宁夏回族自治区中卫市沙坡头区', '宁夏回族自治区中卫市沙坡头区', NULL, NULL, 1, 150, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:09:59');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (306, '新疆维吾尔自治区乌鲁木齐市水磨沟区', '新疆维吾尔自治区乌鲁木齐市水磨沟区', NULL, NULL, 1, 151, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:09:59');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (307, '新疆维吾尔自治区克拉玛依市克拉玛依区', '新疆维吾尔自治区克拉玛依市克拉玛依区', NULL, NULL, 1, 152, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:09:59');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (308, '新疆维吾尔自治区喀什地区喀什市', '新疆维吾尔自治区喀什地区喀什市', NULL, NULL, 1, 153, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:09:59');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (309, '新疆维吾尔自治区伊犁州伊宁市', '新疆维吾尔自治区伊犁州伊宁市', NULL, NULL, 1, 154, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:09:59');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (310, '新疆维吾尔自治区巴音郭楞州库尔勒市', '新疆维吾尔自治区巴音郭楞州库尔勒市', NULL, NULL, 1, 155, 0, 0, NULL, NULL, '系统初始化默认地址', '2026-06-12 11:38:03', '2026-06-13 16:09:59');
INSERT INTO `xy_publish_addresses` (`id`, `name`, `search_keyword`, `expected_text`, `account_id`, `weight`, `sort_order`, `is_enabled`, `use_count`, `last_used_at`, `created_by`, `remark`, `created_at`, `updated_at`) VALUES (311, '上海浦东新区', '上海浦东新区', NULL, NULL, 1, 100, 1, 3, '2026-06-14 00:18:38', 2, NULL, '2026-06-13 16:10:33', '2026-06-13 16:18:38');


-- ----------------------------
-- 表结构: xy_publish_logs
-- ----------------------------
DROP TABLE IF EXISTS `xy_publish_logs`;
CREATE TABLE `xy_publish_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` bigint NOT NULL COMMENT 'æ“ä½œç”¨æˆ·ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'é—²é±¼è´¦å·ID',
  `title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å•†å“æ ‡é¢˜',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å•†å“æè¿°',
  `price` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å‘å¸ƒä»·æ ¼',
  `material_id` bigint DEFAULT NULL COMMENT 'å…³è”çš„ç´ æID',
  `batch_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‰¹æ¬¡ID',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending' COMMENT 'çŠ¶æ€',
  `item_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å‘å¸ƒæˆåŠŸåŽçš„å•†å“é“¾æŽ¥',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å‘å¸ƒæˆåŠŸåŽçš„å•†å“ID',
  `error_message` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¤±è´¥åŽŸå› ',
  `resolved_address_id` bigint DEFAULT NULL COMMENT 'æœ¬æ¬¡å‘å¸ƒå‘½ä¸­çš„åœ°å€æ± ID',
  `resolved_address_text` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æœ¬æ¬¡å‘å¸ƒå®žé™…ä½¿ç”¨çš„åœ°å€æœç´¢è¯',
  `address_source` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'åœ°å€æ¥æº',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_batch_id` (`batch_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_publish_user_created` (`user_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å•†å“å‘å¸ƒæ—¥å¿—è¡¨';

-- 表 xy_publish_logs 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_recharge_orders
-- ----------------------------
DROP TABLE IF EXISTS `xy_recharge_orders`;
CREATE TABLE `xy_recharge_orders` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `order_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å……å€¼è®¢å•å·',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·ID',
  `amount` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å……å€¼é‡‘é¢',
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending' COMMENT 'è®¢å•çŠ¶æ€',
  `trade_no` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¯ä»˜å®äº¤æ˜“å·',
  `qr_code` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¯ä»˜äºŒç»´ç å†…å®¹',
  `paid_at` datetime DEFAULT NULL COMMENT 'æ”¯ä»˜æ—¶é—´',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å……å€¼è®¢å•è¡¨';

-- 表数据: xy_recharge_orders


-- ----------------------------
-- 表结构: xy_risk_control_logs
-- ----------------------------
DROP TABLE IF EXISTS `xy_risk_control_logs`;
CREATE TABLE `xy_risk_control_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'æ—¥å¿—ID',
  `owner_id` bigint DEFAULT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `account_id` bigint DEFAULT NULL COMMENT 'å…³è”è´¦å·ID',
  `account_identifier` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è´¦å·æ ‡è¯†',
  `event_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'slider_captcha' COMMENT 'äº‹ä»¶ç±»åž‹',
  `event_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'äº‹ä»¶æè¿°',
  `processing_result` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å¤„ç†ç»“æžœ',
  `processing_status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'processing' COMMENT 'å¤„ç†çŠ¶æ€',
  `captcha_engine` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'éªŒè¯å¼•æ“Ž',
  `error_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_event_type` (`event_type`),
  KEY `idx_rcl_account_status` (`account_id`,`processing_status`),
  KEY `idx_rcl_identifier_status_created` (`account_identifier`,`processing_status`,`created_at`),
  KEY `idx_rcl_owner_created` (`owner_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='é£ŽæŽ§æ—¥å¿—è¡¨';

-- 表 xy_risk_control_logs 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_scheduled_api_cookie_renew_log
-- ----------------------------
DROP TABLE IF EXISTS `xy_scheduled_api_cookie_renew_log`;
CREATE TABLE `xy_scheduled_api_cookie_renew_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `batch_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ‰¹æ¬¡ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `status` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŠ¶æ€',
  `updated_cookie_count` int NOT NULL DEFAULT '0' COMMENT 'æ›´æ–°çš„Cookieå­—æ®µæ•°é‡',
  `updated_cookie_names` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'æ›´æ–°çš„Cookieå­—æ®µååˆ—è¡¨',
  `response_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'æŽ¥å£è¿”å›žå†…å®¹',
  `error_message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_batch_id` (`batch_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æŽ¥å£ç»­æœŸCookiesæ—¥å¿—è¡¨';

-- 表 xy_scheduled_api_cookie_renew_log 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_scheduled_close_notice_log
-- ----------------------------
DROP TABLE IF EXISTS `xy_scheduled_close_notice_log`;
CREATE TABLE `xy_scheduled_close_notice_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `batch_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ‰¹æ¬¡ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŠ¶æ€',
  `error_message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_batch_id` (`batch_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å…³é—­é€šçŸ¥æ—¥å¿—è¡¨';

-- 表 xy_scheduled_close_notice_log 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_scheduled_cookies_refresh_log
-- ----------------------------
DROP TABLE IF EXISTS `xy_scheduled_cookies_refresh_log`;
CREATE TABLE `xy_scheduled_cookies_refresh_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `batch_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ‰¹æ¬¡ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŠ¶æ€',
  `updated_cookie_count` int NOT NULL DEFAULT '0' COMMENT 'å¢žé‡æ›´æ–°çš„Cookieå­—æ®µæ•°é‡',
  `next_expire_at` datetime DEFAULT NULL COMMENT 'ä¸‹æ¬¡åˆ°æœŸæ—¶é—´',
  `error_message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_batch_id` (`batch_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='COOKIESåˆ·æ–°æ—¥å¿—è¡¨';

-- 表 xy_scheduled_cookies_refresh_log 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_scheduled_login_renew_log
-- ----------------------------
DROP TABLE IF EXISTS `xy_scheduled_login_renew_log`;
CREATE TABLE `xy_scheduled_login_renew_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `batch_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ‰¹æ¬¡ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŠ¶æ€',
  `error_message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_batch_id` (`batch_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç™»å½•ç»­æœŸæ—¥å¿—è¡¨';

-- 表 xy_scheduled_login_renew_log 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_scheduled_polish_log
-- ----------------------------
DROP TABLE IF EXISTS `xy_scheduled_polish_log`;
CREATE TABLE `xy_scheduled_polish_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `batch_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ‰¹æ¬¡ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `item_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å•†å“ID',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŠ¶æ€',
  `error_message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_batch_id` (`batch_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_spol_created_batch` (`created_at`,`batch_id`),
  KEY `idx_spol_batch_created_status` (`batch_id`,`created_at`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æ“¦äº®æ—¥å¿—è¡¨';

-- 表 xy_scheduled_polish_log 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_scheduled_rate_log
-- ----------------------------
DROP TABLE IF EXISTS `xy_scheduled_rate_log`;
CREATE TABLE `xy_scheduled_rate_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `batch_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ‰¹æ¬¡ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `order_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŠ¶æ€',
  `error_message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_batch_id` (`batch_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_srate_created_batch` (`created_at`,`batch_id`),
  KEY `idx_srate_batch_created_status` (`batch_id`,`created_at`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è¡¥è¯„ä»·æ—¥å¿—è¡¨';

-- 表 xy_scheduled_rate_log 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_scheduled_red_flower_log
-- ----------------------------
DROP TABLE IF EXISTS `xy_scheduled_red_flower_log`;
CREATE TABLE `xy_scheduled_red_flower_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `batch_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ‰¹æ¬¡ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `order_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŠ¶æ€',
  `error_message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_batch_id` (`batch_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_srf_created_batch` (`created_at`,`batch_id`),
  KEY `idx_srf_batch_created_status` (`batch_id`,`created_at`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æ±‚å°çº¢èŠ±æ—¥å¿—è¡¨';

-- 表 xy_scheduled_red_flower_log 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_scheduled_redelivery_log
-- ----------------------------
DROP TABLE IF EXISTS `xy_scheduled_redelivery_log`;
CREATE TABLE `xy_scheduled_redelivery_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `batch_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ‰¹æ¬¡ID',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è´¦å·ID',
  `order_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'çŠ¶æ€',
  `error_message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_batch_id` (`batch_id`),
  KEY `idx_account_id` (`account_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_srl_created_batch` (`created_at`,`batch_id`),
  KEY `idx_srl_batch_created_status` (`batch_id`,`created_at`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è¡¥å‘è´§æ—¥å¿—è¡¨';

-- 表 xy_scheduled_redelivery_log 为日志表，仅备份结构，跳过数据


-- ----------------------------
-- 表结构: xy_scheduled_tasks
-- ----------------------------
DROP TABLE IF EXISTS `xy_scheduled_tasks`;
CREATE TABLE `xy_scheduled_tasks` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `task_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ä»»åŠ¡ä»£ç ',
  `task_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ä»»åŠ¡åç§°',
  `interval_seconds` int NOT NULL DEFAULT '60' COMMENT 'æ‰§è¡Œé—´éš”(ç§’)',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'æ˜¯å¦å¯ç”¨',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'ä»»åŠ¡æè¿°',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_task_code` (`task_code`)
) ENGINE=InnoDB AUTO_INCREMENT=323 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å®šæ—¶ä»»åŠ¡é…ç½®è¡¨';

-- 表数据: xy_scheduled_tasks
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (15, 'redelivery', '补发货任务', 5, 1, '定时补发货任务', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (16, 'rate', '补评价任务', 20, 1, '定时补评价任务', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (17, 'polish', '擦亮任务', 60, 1, '定时擦亮商品任务', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (18, 'day_switch', '平台日切换任务', 60, 1, '定时执行平台日切换任务', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (19, 'cleanup_browser_data', '清理被禁用账号浏览器数据任务', 600, 0, '定时清理被禁用账号的浏览器数据', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (20, 'fetch_orders', '获取闲鱼订单任务', 600, 1, '定时获取闲鱼订单数据', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (21, 'fetch_pending_orders', '获取待发货订单任务', 60, 1, '定时获取待发货订单并同步收货人姓名/手机号/地址等信息', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (22, 'fetch_items', '获取闲鱼商品任务', 1200, 1, '定时获取所有启用账号的闲鱼在售商品并入库（新增或更新）', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (23, 'login_renew', '登录续期任务', 600, 0, '定时执行闲鱼账号登录续期', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (24, 'cookies_refresh', 'COOKIES续期任务', 600, 0, '定时执行闲鱼账号浏览器COOKIES续期', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (25, 'api_cookie_renew', '接口续期Cookies任务', 3600, 1, '定时通过 hasLogin.do 接口为启用账号续期Cookies并同步Set-Cookie', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (26, 'close_notice', '关闭账号消息通知任务', 600, 0, '定时关闭账号消息通知', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (27, 'red_flower', '求小红花任务', 300, 1, '定时自动求小红花', '2026-06-12 11:38:03', '2026-06-12 11:38:03');
INSERT INTO `xy_scheduled_tasks` (`id`, `task_code`, `task_name`, `interval_seconds`, `enabled`, `description`, `created_at`, `updated_at`) VALUES (28, 'db_backup', '数据库备份任务', 3600, 1, '定时备份数据库所有表结构与数据到文件', '2026-06-12 11:38:03', '2026-06-12 11:38:03');


-- ----------------------------
-- 表结构: xy_settlement_records
-- ----------------------------
DROP TABLE IF EXISTS `xy_settlement_records`;
CREATE TABLE `xy_settlement_records` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·ID',
  `alipay_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ”¯ä»˜å®ID',
  `payment_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶æ¬¾æ–¹å¼',
  `payment_qrcode` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶æ¬¾ç å›¾ç‰‡è·¯å¾„',
  `amount` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æçŽ°é‡‘é¢',
  `status` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending_review' COMMENT 'çŠ¶æ€',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'å¤‡æ³¨',
  `reject_reason` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‹’ç»åŽŸå› ',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_sr_user_created_id` (`user_id`,`created_at`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç»“ç®—è®°å½•è¡¨';

-- 表数据: xy_settlement_records


-- ----------------------------
-- 表结构: xy_shared_scan_sessions
-- ----------------------------
DROP TABLE IF EXISTS `xy_shared_scan_sessions`;
CREATE TABLE `xy_shared_scan_sessions` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `session_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ä¼šè¯å”¯ä¸€ID(UUID)',
  `owner_id` bigint NOT NULL COMMENT 'åˆ›å»ºè€…ç”¨æˆ·ID',
  `owner_username` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'åˆ›å»ºè€…ç”¨æˆ·å',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active' COMMENT 'ä¼šè¯çŠ¶æ€',
  `expires_at` datetime NOT NULL COMMENT 'è¿‡æœŸæ—¶é—´(é»˜è®¤72å°æ—¶)',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_id` (`session_id`),
  KEY `idx_session_id` (`session_id`),
  KEY `idx_owner_id` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å…±äº«æ‰«ç ç™»å½•ä¼šè¯è¡¨';

-- 表数据: xy_shared_scan_sessions


-- ----------------------------
-- 表结构: xy_shared_scan_workers
-- ----------------------------
DROP TABLE IF EXISTS `xy_shared_scan_workers`;
CREATE TABLE `xy_shared_scan_workers` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `shared_session_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å…³è”çš„å…±äº«ä¼šè¯ID',
  `sub_session_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å…¼èŒå­ä¼šè¯å”¯ä¸€ID(UUID)',
  `xianyu_session_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å…³è”çš„é—²é±¼QRç™»å½•ä¼šè¯ID',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'qrcode_ready' COMMENT 'çŠ¶æ€',
  `qr_code_url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'äºŒç»´ç å›¾ç‰‡base64 data URL',
  `account_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‰«ç æˆåŠŸåŽçš„é—²é±¼è´¦å·ID(unb)',
  `cookie_saved` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Cookieæ˜¯å¦å·²ä¿å­˜',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sub_session_id` (`sub_session_id`),
  KEY `idx_shared_session_id` (`shared_session_id`),
  KEY `idx_sub_session_id` (`sub_session_id`),
  KEY `idx_account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='å…±äº«æ‰«ç å…¼èŒå·¥ä½œè€…è¡¨';

-- 表数据: xy_shared_scan_workers


-- ----------------------------
-- 表结构: xy_system_settings
-- ----------------------------
DROP TABLE IF EXISTS `xy_system_settings`;
CREATE TABLE `xy_system_settings` (
  `key` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¾ç½®é”®',
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¾ç½®å€¼',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'è®¾ç½®æè¿°',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç³»ç»Ÿè®¾ç½®è¡¨';

-- 表数据: xy_system_settings
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('account.face_verify_timeout_disable', 'true', '人脸验证超时是否自动禁用账号', '2026-06-12 12:35:18');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('auth.footer_ad_html', '© 2026 划算云服务器 ·<a href="http://www.hsykj.com" target="_BLANK">www.hsykj.com</a>', '登录页和注册页底部广告 HTML', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('disclaimer.agree_button_text', '同意并继续', '免责声明同意按钮文案', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('disclaimer.checkbox_text', '我已阅读并同意以上免责声明', '免责声明勾选提示文案', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('disclaimer.content', '数据存储说明\n1. 本系统在运行过程中，为保障服务正常运行，会存储用户账号密码、登录 Cookie、商品信息、卡券信息等业务数据。\n2. 上述数据仅用于系统功能运行、自动化处理和业务管理，不作为其他用途。\n3. 请您自行确认服务器环境、账号权限和数据保管措施的安全性。\n\n用户须知\n1. 用户应确保使用本系统的行为符合相关平台规则和法律法规。\n2. 因用户自身违规操作、账号共享、密码泄露、服务器安全问题导致的损失，由用户自行承担。\n3. 建议用户定期备份重要数据，因系统故障、第三方平台变更、不可抗力等导致的异常或损失，本系统不承担责任。\n4. 本系统依赖第三方平台接口和网络环境，无法保证服务始终连续、稳定、无中断。\n\n隐私与风险提示\n1. 请勿在未充分评估风险的情况下接入生产环境或敏感账号。\n2. 使用本系统即表示您已充分理解并接受相关风险，并愿意自行承担相应责任。', '系统免责声明正文', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('disclaimer.disagree_button_text', '不同意', '免责声明不同意按钮文案', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('disclaimer.title', '免责声明', '系统免责声明标题', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('log.retention_days', '7', '日志保留天数（所有模块生效，修改后重启服务生效）', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('login.system_description', '自动回复、智能客服、订单管理、数据分析，一站式解决闲鱼运营难题', '登录页系统描述', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('login.system_name', '闲鱼管理系统', '登录页系统名称', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('login.system_title', '高效专业的\n闲鱼自动化管理平台', '登录页系统标题', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('proxy.api_url', '', '代理 API 的 URL（可能较长，用于配置外部代理服务）', '2026-06-12 12:35:18');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('proxy.enabled', 'false', '是否启用代理（true/false）', '2026-06-12 12:35:18');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('security.jwt_secret_key', 'f44e01dfba71c904a3e248eda1c119d0087fe927265ca2580786da9e123cd86f', '系统 JWT 密钥（由数据库统一托管，自动生成，请勿泄露）', '2026-06-12 11:38:04');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('show_default_login_info', 'true', '登录页是否展示默认账号密码提示', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('theme.color_preset', 'ocean', '系统主题颜色预设', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('theme.effect', 'solid', '系统主题效果（solid-纯色，gradient-炫彩）', '2026-06-12 11:38:03');
INSERT INTO `xy_system_settings` (`key`, `value`, `description`, `updated_at`) VALUES ('theme.font_family', 'system', '系统主题字体预设', '2026-06-12 12:35:18');


-- ----------------------------
-- 表结构: xy_token_cache
-- ----------------------------
DROP TABLE IF EXISTS `xy_token_cache`;
CREATE TABLE `xy_token_cache` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `user_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ç”¨æˆ·ID(myid)',
  `token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'IM Token',
  `device_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¾å¤‡ID',
  `expire_at` datetime NOT NULL COMMENT 'è¿‡æœŸæ—¶é—´',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tokenç¼“å­˜è¡¨';

-- 表数据: xy_token_cache
INSERT INTO `xy_token_cache` (`id`, `user_id`, `token`, `device_id`, `expire_at`, `created_at`, `updated_at`) VALUES (6, '783149128', 'oauth_k1:jnu+VmMg1YBS/MBnwIQQWSYYj+VGohqTz0Xn1kSpFYZ8WGZyIxfc+1ezNbkYFPRUKeFDfphI6F2JPIXrwmq1xw==', '04634C35-EE20-4413-BC17-5BF892498223-783149128', '2026-06-14 03:23:13', '2026-06-13 09:44:32', '2026-06-13 09:44:32');
INSERT INTO `xy_token_cache` (`id`, `user_id`, `token`, `device_id`, `expire_at`, `created_at`, `updated_at`) VALUES (7, '2221611389164', 'oauth_k1:FuGMA68pQ17rLq46unxQqix8F3SaoIBa2pcUQ3NdCvmKS90OvFbViGhCRyXF5iCwPrJZ5OmU3Krfni88KmQocHceJ+ehuSMU2H4oWE5BYl8=', 'CE2A709A-A5EF-44D0-A50A-32D7C9B43AEA-2221611389164', '2026-06-14 08:00:11', '2026-06-13 15:19:18', '2026-06-13 15:19:18');


-- ----------------------------
-- 表结构: xy_user_settings
-- ----------------------------
DROP TABLE IF EXISTS `xy_user_settings`;
CREATE TABLE `xy_user_settings` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'è®¾ç½®ID',
  `user_id` int NOT NULL COMMENT 'ç”¨æˆ·ID',
  `key` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¾ç½®é”®',
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¾ç½®å€¼',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'è®¾ç½®æè¿°',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_key` (`user_id`,`key`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç”¨æˆ·è®¾ç½®è¡¨';

-- 表数据: xy_user_settings
INSERT INTO `xy_user_settings` (`id`, `user_id`, `key`, `value`, `description`, `created_at`, `updated_at`) VALUES (2, 2, 'disclaimer_agreed', 'true', '用户已同意免责声明', '2026-06-12 13:12:18', '2026-06-12 13:12:18');


-- ----------------------------
-- 表结构: xy_users
-- ----------------------------
DROP TABLE IF EXISTS `xy_users`;
CREATE TABLE `xy_users` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ç”¨æˆ·ID',
  `external_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¤–éƒ¨ID',
  `username` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ç”¨æˆ·å',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'é‚®ç®±',
  `phone` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ‰‹æœºå·',
  `password_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å¯†ç å“ˆå¸Œ',
  `status` enum('ACTIVE','INACTIVE','SUSPENDED','DELETED') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'ACTIVE' COMMENT 'ç”¨æˆ·çŠ¶æ€',
  `role` enum('ADMIN','OPERATOR','MEMBER') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'MEMBER' COMMENT 'ç”¨æˆ·è§’è‰²',
  `account_limit` int DEFAULT NULL COMMENT 'å¯æ·»åŠ è´¦å·æ•°é‡',
  `last_login_at` datetime DEFAULT NULL COMMENT 'æœ€åŽç™»å½•æ—¶é—´',
  `login_fail_count` int DEFAULT '0' COMMENT 'ç™»å½•å¤±è´¥æ¬¡æ•°',
  `login_locked_until` datetime DEFAULT NULL COMMENT 'ç™»å½•é”å®šæˆªæ­¢æ—¶é—´',
  `dock_code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'å¯¹æŽ¥ç ',
  `secret_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'åˆ†é”€ç§˜é’¥',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `dock_code` (`dock_code`),
  UNIQUE KEY `secret_key` (`secret_key`),
  KEY `idx_external_id` (`external_id`),
  KEY `idx_username` (`username`),
  KEY `idx_email` (`email`),
  KEY `idx_user_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ç”¨æˆ·è¡¨';

-- 表数据: xy_users
INSERT INTO `xy_users` (`id`, `external_id`, `username`, `email`, `phone`, `password_hash`, `status`, `role`, `account_limit`, `last_login_at`, `login_fail_count`, `login_locked_until`, `dock_code`, `secret_key`, `created_at`, `updated_at`) VALUES (2, NULL, 'admin', 'admin@example.com', NULL, '$pbkdf2-sha256$29000$pLRW6t37P8fYe0.JcU5J6Q$Z4DS49fCH9gDpLksTfagjrPbupPrwiUe5i9VylxG.Do', 'ACTIVE', 'ADMIN', NULL, '2026-06-13 17:45:40', 0, NULL, 'YXDA0LNB', 'UmkYCfXzro9Qwwk8PLdedw1TSVrmU8Z8', '2026-06-12 11:38:03', '2026-06-13 09:45:40');


SET FOREIGN_KEY_CHECKS=1;
